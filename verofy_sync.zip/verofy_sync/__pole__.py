# -*- coding: utf-8 -*-
"""
Created on Monday, August 25, 2025
Vero QC LLD
@author: Marie Payne
"""

import sys
import os
import re

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea, QgsCoordinateTransform
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime
import psycopg2
import psycopg2.extras

from .json_to_geojson import json_to_geojson
from . import globals_module
import subprocess
import json
class Pole:
        global  config, python_exe, parent_dir, CREATE_NO_WINDOW

        config = globals_module.config
        python_exe = globals_module.python_exe
        parent_dir = globals_module.parent_dir
        CREATE_NO_WINDOW = globals_module.CREATE_NO_WINDOW

        def _getPermits_(map_id):
            subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\get_permits.py', str(map_id)])
            with open(f'{str(map_id)}_permits.json', 'r') as f:
                data = json.load(f)
            permits = {}
            for feature in data:
                permits[feature['name']] = feature['id']
            return permits    
        def _upload_(dbox, map_id, schema_name, selectionType, segment_id, lyr): #create
            conn = psycopg2.connect(**config)
            curr = conn.cursor()
            if selectionType == 'zone':
                query = f"""
                SELECT f.pole_tag, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.pole f
                WHERE
                    ST_Within(f.geom, (SELECT ST_Union(p.geom) FROM {schema_name}.cabinet_boundary p where p.segment_id in ('{segment_id}') and f.attach = 'Yes'));
                """
            elif selectionType == 'map':
                query = f"""
                SELECT f.pole_tag, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.pole f;
                """
            elif selectionType == 'selected':
                uuid_list = [f["uuid"] for f in lyr.getSelectedFeatures()]
                if not uuid_list:
                    raise ValueError("No UUIDs selected")
                uuid_str = ', '.join(f"'{uuid}'" for uuid in uuid_list)
                query = f"""
                    SELECT f.pole_tag, ST_AsGeoJSON(ST_Transform(f.geom, 4326)) AS geometry
                    FROM {schema_name}.pole f
                    WHERE f.uuid IN ({uuid_str});
                """
            
            curr.execute(query)
            for row in curr.fetchall():
                geojson = json.loads(row[1])
                lon, lat = geojson["coordinates"]
                subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\create_pole.py',
                '--map_id', str(map_id),
                '--latitude', f'{lat}',
                '--longitude', f'{lon}',
                '--name', f'{row[0]}'],  #Pole ID
                creationflags=CREATE_NO_WINDOW)

            curr.close()
            conn.close()
            dbox.append('Success! Features uploaded!')

        
        def _download_(dbox, map_id, schema_name, selectionType, segment_id, lyr): #get
            conn = psycopg2.connect(**config)
            curr = conn.cursor()
            dbox.append(selectionType)
            if selectionType == 'zone':
                query = f"""
                SELECT ST_AsText(geom) AS bbox
                FROM {schema_name}.cabinet_boundary
                WHERE segment_id = '{segment_id}';
                """
            elif selectionType == 'map':
                pass
            elif selectionType == 'selected':
                uuid_list = [f["uuid"] for f in lyr.getSelectedFeatures()]
                count_selected = lyr.selectedFeatureCount()
                dbox.append(f'{str(count_selected)} features selected.')
                if not uuid_list:
                    raise ValueError("No UUIDs selected")
                uuid_str = ', '.join(f"'{uuid}'" for uuid in uuid_list)
                query = f"""
                    SELECT ST_AsText(ST_Union(ST_Buffer(geom, 1)))

                    FROM {schema_name}.pole f
                    WHERE f.uuid IN ({uuid_str}) and geom is not null;
                """
            else:
                print('error')


            #"get" retrieves the entire verofy map, there is no way to pre-filter it, "get"returns a .json file
            dbox.append(str(map_id))
            dbox.append(f'{parent_dir}\\verofy_api\\get_poles.py')
            result = subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\get_poles.py',str(map_id)],
                                       capture_output=True, text=True,
                                       creationflags=CREATE_NO_WINDOW)
            # returns json file that gets sent to "Documents", as "map_id"_"layer".json, i.e. "12234_poles.json"
            if result.stdout.strip():
                dbox.append(result.stdout)
            safe_dir = os.path.expanduser("~/Downloads")  # or use tempfile.gettempdir()
            file = os.path.join(safe_dir, f"{str(map_id)}_poles.json")
            newfile = json_to_geojson(file)
            layer = QgsVectorLayer(newfile, "verofy_pole", "ogr")
            QgsProject.instance().addMapLayer(layer)
            if not layer.isValid():
                dbox.append("Layer failed to load.")
                return
            elif layer.geometryType() != QgsWkbTypes.PointGeometry:
                dbox.append("Layer loaded, but it's not recognized as a point layer. No poles found on verofy map.")
                return

            if selectionType in ['zone', 'selected']:
                curr.execute(query)
                results = curr.fetchone()
                if results and results[0]:
                    dbox.append(str(results))
                    wkt = results[0]
                    verofy_pole = QgsProject.instance().mapLayersByName('verofy_pole')[0]
                    pole = QgsProject.instance().mapLayersByName('Pole')[0]
                    extent_geom = QgsGeometry.fromWkt(wkt)
                    transform = QgsCoordinateTransform(pole.crs(), verofy_pole.crs(), QgsProject.instance())

                    extent_geom.transform(transform)
                    wkt = extent_geom.asWkt()
                    expression = f"intersects($geometry, geom_from_wkt('{wkt}'))"
                    dbox.append(expression)
                    verofy_pole.selectByExpression(expression, QgsVectorLayer.SetSelection)
                    verofy_pole.invertSelection()
                    verofy_pole.startEditing()
                    for fid in verofy_pole.selectedFeatureIds():
                        verofy_pole.deleteFeature(fid)
                    verofy_pole.commitChanges()
                    count_remaining = verofy_pole.featureCount()
                    dbox.append(f'{str(count_remaining)} matching features found in verofy.')

            curr.close()
            conn.close()
            
        def _update_(dbox, map_id, schema_name, selectionType, segment_id, lyr):
            conn = psycopg2.connect(**config)
            curr = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
            if selectionType == 'zone':
                query = f"""
                SELECT f.pole_tag, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.pole f
                WHERE
                    ST_Within(f.geom, (SELECT ST_Union(p.geom) FROM {schema_name}.cabinet_boundary p where p.segment_id in ('{segment_id}') and f.attach = 'Yes'));
                """
            elif selectionType == 'map':
                query = f"""
                SELECT f.pole_tag, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.pole f;
                """
            elif selectionType == 'selected':
                uuid_list = [f["uuid"] for f in lyr.getSelectedFeatures()]
                if not uuid_list:
                    raise ValueError("No UUIDs selected")
                uuid_str = ', '.join(f"'{uuid}'" for uuid in uuid_list)
                query = f"""
                    SELECT f.pole_tag, f.pole_owner, f.pole_height, f.comms_mr, f.power_mr, f.pole_group, f.group_2, f.low_power_attachment, f.mr_notes, f.permit,  ST_AsGeoJSON(ST_Transform(f.geom, 4326)) AS geometry
                    FROM {schema_name}.pole f
                    WHERE f.uuid IN ({uuid_str});
                """
            curr.execute(query)
            permits = Pole._getPermits_(map_id)
            #pole_id vs name
            #tags vs pole_tag
            for index, row in enumerate(curr.fetchall()):
                #dbox.append(", ".join(row.keys()))
                if row['permit'] is None:
                    permit_id = ""
                    pass #check if permit is a requirement
                elif row['permit'] in permits:
                    permit_id = permits[row['permit']]
                else:
                    dbox.append('Could not locate permit.')
                    permit_id = ""
                geojson = json.loads(row[-1])
                lon, lat = geojson["coordinates"]
                #dbox.append(f"{str(row['low_power_attachment'])}" if row['low_power_attachment'] not in [None, 'nan'] else '')
                result = subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\update_pole.py',
                '--pole_id', row['external_id'], #
                '--name', '99999',
                '--tags', row['pole_tag'] if row['pole_tag'] is not None else '',
                '--group1',row['pole_group'] if row['pole_group'] is not None else '',
                '--group2', row['group_2'] if row['group_2'] is not None else '',
                '--mr_state_id',str(1), #int #No MR
                '--comms_mr_choice_id', str(2), #int
                '--power_mr_choice_id', str(3), #int 
                #'--pole_height', str(row['pole_height']) if row['pole_height'] is not None else '', #float
                #'--attachment_height',f'{row['low_power_attachment']}' if row['low_power_attachment'] not in [None] else '', #float
                '--mr_notes', row['mr_notes'] if row['mr_notes'] is not None else '',
                '--owner', row['pole_owner'] if row['pole_owner'] is not None else '',
                '--latitude', f'{lat}', #float
                '--longitude', f'{lon}', #float
                '--mappermitId', str(permit_id)
                ], capture_output=True, text=True,creationflags=CREATE_NO_WINDOW)

                if result.stdout.strip():
                    dbox.append(result.stdout.strip())
                if result.stderr.strip():
                    dbox.append(result.stderr.strip())

            curr.close()
            conn.close()
            dbox.append('Success! Features updated!')