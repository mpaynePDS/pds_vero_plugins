import json
def json_to_geojson(file):
    if 'pole' in file:
        # Load your raw JSON
        with open(file, "r") as f:
            data = json.load(f)

        # Convert to GeoJSON FeatureCollection
        geojson = {
            "type": "FeatureCollection",
            "features": []
        }

        for item in data:
            lat = float(item["latitude"])
            lon = float(item["longitude"])
            props = {k: v for k, v in item.items() if k not in ["latitude", "longitude"]}

            feature = {
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [lon, lat]
                },
                "properties": props
            }

            geojson["features"].append(feature)

        # Save as GeoJSON
        newfile = file.split('.json')[0]+'.geojson'
        with open(newfile, "w") as f:
            json.dump(geojson, f, indent=2)

        return newfile
    if 'segments' in file:
        with open(file, "r") as f:
            data = json.load(f)    
        # Convert to GeoJSON FeatureCollection
        geojson = {
            "type": "FeatureCollection",
            "features": []
        }

        for line in data:
            props = {k: v for k, v in line.items() if k not in ["poly"]}
            coords = line["poly"]
    # Convert from {"lat": ..., "lng": ...} to [lng, lat]


            feature = {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[point["lng"], point["lat"]] for point in coords]
                },
                "properties": props
            }
            geojson["features"].append(feature)

        # Save as GeoJSON
        newfile = file.split('.json')[0]+'.geojson'
        with open(newfile, "w") as f:
            json.dump(geojson, f, indent=2)

        return newfile
