import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Ensure a map ID is provided as a command-line argument
if len(sys.argv) < 2:
    print("❌ Usage: python create_site.py <MAP_PROJECT_ID>")
    exit(1)

MAP_PROJECT_ID = sys.argv[1]  # Get map ID from command line

# Step 1: Get a new access token dynamically before creating a site
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Create a new site
def create_site(map_project_id, access_token):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Define site details
    site_data = {
        "mapProjectId": int(map_project_id),  # Ensure it's an integer
        "name": "TEST SITE ALPHA",
        "latitude": str(34.0578),  # Convert to string
        "longitude": str(-118.2451),  # Convert to string
        "iconTypeId": 20
    }

    # Send the request
    response = requests.post(f"{API_URL}/map-site/create", headers=headers, json=site_data)

    if response.status_code == 201:
        print("\n✅ Site Created Successfully!")
        print(json.dumps(response.json(), indent=4))
    else:
        print(f"❌ Failed to create site. Status: {response.status_code}, Response: {response.text}")

# Run the process
if __name__ == "__main__":
    access_token = get_access_token()
    if access_token:
        create_site(MAP_PROJECT_ID, access_token)