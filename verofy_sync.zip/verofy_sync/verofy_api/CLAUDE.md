# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Environment Setup

This is a Python project using `uv` for dependency management. Set up the environment:

```bash
uv sync  # Install dependencies and create virtual environment
```

## Required Environment Variables

All API scripts require authentication credentials:

```bash
export VEROFY_USER="your_username"
export VEROFY_PASS="your_password"
```

Optional for some scripts:
```bash
export VEROFY_API_KEY="your_api_key"  # For key-based authentication
```

## Common Development Commands

### Running Scripts
```bash
uv run login.py                    # Test authentication setup
uv run get_map.py <MAP_PROJECT_ID> # Fetch map project data
uv run reference.py [REF_TYPE]     # Fetch API references
uv run projects.py                 # List available projects
```

### Testing Authentication
```bash
uv run test_auth_methods.py        # Test different auth methods
uv run test_download_manual.py     # Test document download
```

## Project Architecture

### Core Components

**Authentication Module (login.py)**
- Handles token-based authentication flow
- Manages refresh token → access token exchange
- Performs health checks and access validation

**Reference System (reference.py)**
- Fetches enum-like reference data from API
- Supports caching with hash-based validation
- Saves references to JSON files for offline use

**Data Fetching Scripts**
- Individual scripts for different API resources (get_*.py)
- Common pattern: authenticate → fetch → display/save data
- Support command-line parameters for resource IDs

**CRUD Operations**
- create_*.py: Create new resources
- update_*.py: Update existing resources
- get_*.py: Retrieve resource data

### API Structure

The Verofy API follows a semi-RESTful design with versioned endpoints:
```
<api_url>/<version>/<model>/<id>
```

**Base URL**: `https://api.verofy.veronetworks.com/v1`

**Authentication Types**:
- Token Auth: User credentials → refresh token → access token (for user-facing apps)  
- Key Auth: Direct API key authentication (for automated services)

**Key Models**:
- map-project: Container for mapping elements
- map-segment: Network segments
- map-site: Physical locations
- map-pole: Utility poles
- map-access-point: Network access points
- references: Enum-like lookup data

### File Organization

- Root level: Individual API interaction scripts
- `icons/`: UI icons organized by type/status
- JSON files: Cached reference data from API
- Documentation files: API specs and tutorials

### Common Patterns

**Script Structure**:
1. Load credentials from environment
2. Get access token via login flow  
3. Make authenticated API requests
4. Process and display/save results

**Error Handling**:
- Check for required environment variables
- Validate API responses and status codes
- Provide user-friendly error messages with emojis

**Data Management**:
- Save API responses to JSON files
- Use reference data for enum lookups
- Support filtering and pagination where available