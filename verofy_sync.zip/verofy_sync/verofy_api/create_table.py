import os
import json
import sys
from dotenv import load_dotenv
import psycopg2
from psycopg2 import Error

def determine_pg_type(value):
    """Map Python/JSON types to PostgreSQL types"""
    if value is None:
        return 'TEXT'
    if isinstance(value, bool):
        return 'BOOLEAN'
    if isinstance(value, int):
        return 'INTEGER'
    if isinstance(value, float):
        return 'NUMERIC'
    if isinstance(value, str):
        return 'TEXT'  # Always keep strings as TEXT
    return 'TEXT'  # default type

def create_table(table_name, json_file, geom_type='POINT'):
    # Validate geometry type
    valid_geom_types = ['POINT', 'LINESTRING', 'POLYGON', 'MULTIPOINT', 'MULTILINESTRING', 'MULTIPOLYGON']
    if geom_type.upper() not in valid_geom_types:
        raise ValueError(f"Invalid geometry type. Must be one of: {', '.join(valid_geom_types)}")
    
    # Load environment variables
    load_dotenv()

    # Initialize connection as None
    conn = None
    cur = None

    try:
        # Database connection parameters
        db_params = {
            "host": os.getenv("POSTGRES_HOST"),
            "port": int(os.getenv("POSTGRES_PORT", 5432)),
            "database": os.getenv("POSTGRES_DB"),
            "user": os.getenv("POSTGRES_USER"),
            "password": os.getenv("POSTGRES_PASSWORD")
        }

        # Validate connection parameters
        missing_params = [k for k, v in db_params.items() if not v]
        if missing_params:
            raise ValueError(f"Missing required database parameters: {', '.join(missing_params)}")

        # Load and validate JSON file
        print(f"📄 Reading JSON file: {json_file}")
        with open(json_file, 'r') as f:
            data = json.load(f)
            
        if not data or not isinstance(data, list) or len(data) == 0:
            raise ValueError("JSON file must contain at least one object")

        # Get the first object for structure
        first_object = data[0]

        # Build CREATE TABLE statement
        columns = ["gid SERIAL PRIMARY KEY"]  # Start with gid as primary key
        for key, value in first_object.items():
            pg_type = determine_pg_type(value)
            columns.append(f"{key} {pg_type}")

        create_table_sql = f"""
        CREATE TABLE IF NOT EXISTS verofy.{table_name} (
            {','.join(columns)}
        );
        """

        # Connect and execute
        print("📡 Connecting to PostgreSQL database...")
        conn = psycopg2.connect(**db_params)
        cur = conn.cursor()

        print(f"🔧 Creating table '{table_name}' in schema 'verofy'...")
        print("\nSQL Statement:")
        print(create_table_sql)
        
        # Execute table creation
        cur.execute(create_table_sql)

        # Add geometry column
        print(f"📍 Adding geometry column of type {geom_type}...")
        add_geometry_sql = f"""
        SELECT AddGeometryColumn('verofy', '{table_name}', 'geom', 4326, '{geom_type}', 2);
        """
        cur.execute(add_geometry_sql)

        # Create spatial index
        print("🔍 Creating spatial index...")
        create_index_sql = f"""
        CREATE INDEX {table_name}_geom_idx 
        ON verofy.{table_name} 
        USING GIST (geom);
        """
        cur.execute(create_index_sql)

        conn.commit()
        print(f"✅ Table '{table_name}' created successfully with geometry column and spatial index!")

    except ValueError as ve:
        print(f"❌ Configuration error: {ve}")
    except json.JSONDecodeError as je:
        print(f"❌ JSON parsing error: {je}")
    except (Exception, Error) as error:
        print(f"❌ Error while working with PostgreSQL: {error}")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()
            print("🔌 Database connection closed.")

if __name__ == "__main__":
    if len(sys.argv) not in [3, 4]:
        print("❌ Usage: python create_table.py <table_name> <json_file> [geometry_type]")
        print("   geometry_type can be: POINT, LINESTRING, POLYGON (default: POINT)")
        sys.exit(1)
    
    table_name = sys.argv[1]
    json_file = sys.argv[2]
    geom_type = sys.argv[3].upper() if len(sys.argv) > 3 else 'POINT'
    create_table(table_name, json_file, geom_type)