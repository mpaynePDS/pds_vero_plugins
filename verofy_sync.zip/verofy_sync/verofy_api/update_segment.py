import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Update a segment on a map')
    parser.add_argument('segment_id', help='Segment ID to update')
    parser.add_argument('--name', help='Name for the segment')
    parser.add_argument('--type_id', type=int, help='Segment type ID')
    parser.add_argument('--status_id', type=int, help='Segment status ID')
    parser.add_argument('--color', help='Segment color (hex format, e.g., #FF0000)')
    parser.add_argument('--style_width', type=int, help='Style width')
    parser.add_argument('--exclude', type=int, choices=[0, 1], help='Exclude flag (0 or 1)')
    parser.add_argument('--custom', type=int, choices=[0, 1], help='Custom flag (0 or 1)')
    parser.add_argument('--fiber_count', type=int, help='Fiber count')
    parser.add_argument('--fibers_utilized', type=int, help='Fibers utilized')
    parser.add_argument('--conduit', help='Conduit information')
    parser.add_argument('--construction_method_id', type=int, help='Construction method ID')
    parser.add_argument('--cable_override', type=int, choices=[0, 1], help='Cable override flag (0 or 1)')
    parser.add_argument('--segment_protection_status_id', type=int, help='Segment protection status ID')
    parser.add_argument('--poly', help='Polygon coordinates as CSV string (lat1,lng1,lat2,lng2,...)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    return parser.parse_args()

def parse_poly_csv(poly_csv):
    """Parse CSV coordinate string into polygon array"""
    if not poly_csv:
        return None
    
    try:
        coords = [float(x.strip()) for x in poly_csv.split(',')]
        if len(coords) % 2 != 0:
            raise ValueError("Coordinates must be in pairs (lat,lng)")
        
        poly_array = []
        for i in range(0, len(coords), 2):
            lat = round(coords[i], 6)  # 6 decimal precision
            lng = round(coords[i + 1], 6)  # 6 decimal precision
            poly_array.append({"lat": lat, "lng": lng})
        
        return poly_array
    except ValueError as e:
        print(f"❌ Error parsing polygon coordinates: {e}")
        print("Format should be: lat1,lng1,lat2,lng2,lat3,lng3,...")
        sys.exit(1)

def get_access_token(verbose=False):
    # Read credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    if verbose:
        print(f"🔑 Attempting login with email: {EMAIL}")

    # Get refresh token
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if verbose:
        print(f"📡 Login response status: {response.status_code}")
        print(f"📡 Login response: {response.text[:200]}...")
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        if verbose:
            print(f"🔄 Got refresh token: {refresh_token[:20]}...")
            
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if verbose:
            print(f"📡 Token refresh response status: {token_response.status_code}")
            print(f"📡 Token refresh response: {token_response.text[:200]}...")

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                if verbose:
                    print(f"🔓 Access token: {access_token[:20]}...")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    sys.exit(1)

def update_segment(access_token, args):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Build update data with only provided fields
    segment_data = {}
    
    if args.name is not None:
        segment_data["name"] = args.name
    if args.type_id is not None:
        segment_data["typeId"] = args.type_id
    if args.status_id is not None:
        segment_data["statusId"] = args.status_id
    if args.color is not None:
        segment_data["color"] = args.color
    if args.style_width is not None:
        segment_data["styleWidth"] = args.style_width
    if args.exclude is not None:
        segment_data["exclude"] = args.exclude
    if args.custom is not None:
        segment_data["custom"] = args.custom
    if args.fiber_count is not None:
        segment_data["fiberCount"] = args.fiber_count
    if args.fibers_utilized is not None:
        segment_data["fibersUtilized"] = args.fibers_utilized
    if args.conduit is not None:
        segment_data["conduit"] = args.conduit
    if args.construction_method_id is not None:
        segment_data["constructionMethodId"] = args.construction_method_id
    if args.cable_override is not None:
        segment_data["cableOverride"] = args.cable_override
    if args.segment_protection_status_id is not None:
        segment_data["segmentProtectionStatusId"] = args.segment_protection_status_id
    if args.poly is not None:
        segment_data["poly"] = parse_poly_csv(args.poly)

    if not segment_data:
        print("❌ No update data provided! Please specify at least one field to update.")
        sys.exit(1)

    if args.verbose:
        print(f"🚀 Updating segment {args.segment_id} with data:")
        print(json.dumps(segment_data, indent=2))
        print(f"📡 PATCH URL: {API_URL}/map-segments/{args.segment_id}")
        print(f"📡 Headers: {headers}")

    # Update segment using PATCH request
    response = requests.patch(
        f"{API_URL}/map-segments/{args.segment_id}",
        headers=headers,
        json=segment_data
    )

    if args.verbose:
        print(f"📡 Update segment response status: {response.status_code}")
        print(f"📡 Update segment response headers: {dict(response.headers)}")
        print(f"📡 Update segment response body: {response.text}")

    if response.status_code == 200:
        print("✅ Segment updated successfully!")
        try:
            response_data = response.json()
            print(f"🆔 Segment ID: {response_data.get('id', 'Not found')}")
            print("📄 Updated segment data:")
            print(json.dumps(response_data, indent=2))
        except json.JSONDecodeError:
            print("📄 Response was not JSON format")
            print(f"Response text: {response.text}")
        return True
    else:
        print(f"❌ Failed to update segment! Status: {response.status_code}")
        print(f"📄 Error response: {response.text}")
        
        # Try to parse error details if JSON
        try:
            error_data = response.json()
            print("📄 Parsed error details:")
            print(json.dumps(error_data, indent=2))
        except:
            pass
            
        sys.exit(1)

def main():
    args = parse_arguments()
    
    if args.verbose:
        print(f"🎯 Target segment ID: {args.segment_id}")
        if args.name:
            print(f"📝 New name: {args.name}")
        if args.poly:
            print(f"📍 New coordinates: {args.poly}")
        print("="*50)
    
    access_token = get_access_token(args.verbose)
    update_segment(access_token, args)

if __name__ == "__main__":
    main()