# verofy_api

Documentation and test scripts for the Verofy API

## Setup Instructions

1. **Install dependencies**  
   Run the following command to create a virtual environment and install dependencies:
   ```sh
   uv sync
   ```

2. **Set environment variables**  
   Before running the login script, set your Verofy API credentials as environment variables:
   ```sh
   export VEROFY_USER="your_username"
   export VEROFY_PASS="your_password"
   ```

3. **Run the login script**  
   Test your setup by running:
   ```sh
   uv run login.py
   ```