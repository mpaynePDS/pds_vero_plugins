import requests
import json
import os
import sys
import argparse
import psycopg2
from psycopg2.extras import RealDictCursor

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Load poles from PostGIS table into map')
    parser.add_argument('--map_id', required=True, help='Map Project ID where poles will be created')
    parser.add_argument('--table', required=True, help='PostGIS table in schema.table format')
    return parser.parse_args()

def get_db_connection():
    # Read database credentials from environment variables
    DB_HOST = os.getenv("VEROFY_DB_HOST")
    DB_NAME = os.getenv("VEROFY_DB_NAME")
    DB_PORT = os.getenv("VEROFY_DB_PORT")
    DB_USER = os.getenv("VEROFY_DB_USER")
    DB_PASS = os.getenv("VEROFY_DB_PASS")

    if not all([DB_HOST, DB_NAME, DB_PORT, DB_USER, DB_PASS]):
        print("❌ Missing database environment variables. Please set:")
        print("  VEROFY_DB_HOST: Database host")
        print("  VEROFY_DB_NAME: Database name")
        print("  VEROFY_DB_PORT: Database port")
        print("  VEROFY_DB_USER: Database username")
        print("  VEROFY_DB_PASS: Database password")
        sys.exit(1)

    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASS,
            cursor_factory=RealDictCursor
        )
        return conn
    except Exception as e:
        print(f"❌ Database connection failed: {str(e)}")
        sys.exit(1)

def get_access_token():
    # Read API credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing API environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    # Get refresh token
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        if not refresh_token:
            print("❌ No refresh token in response")
            sys.exit(1)
            
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
            print("❌ No access token in refresh response")
            sys.exit(1)
        print(f"❌ Failed to refresh token! Status: {token_response.status_code}")
        sys.exit(1)
    
    print(f"❌ Failed to login! Status: {response.status_code}")
    sys.exit(1)

def create_pole(access_token, map_id, pole_data):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    api_pole_data = {
        "mapProjectId": int(map_id),
        "name": pole_data['scid'],
        "latitude": str(pole_data['lat']),
        "longitude": str(pole_data['lng']),
        "mrStateId": 11
    }

    response = requests.post(
        f"{API_URL}/map-pole/create",
        headers=headers,
        json=api_pole_data
    )

    if response.status_code == 401:
        # Token expired, get a new one and retry
        print("🔄 Access token expired. Getting new token...")
        new_token = get_access_token()
        if new_token:
            return create_pole(new_token, map_id, pole_data)
        return False

    if response.status_code == 201:
        print(f"✅ Created pole {pole_data['scid']}")
        return True
    else:
        print(f"❌ Failed to create pole {pole_data['scid']}! Status: {response.status_code}")
        print(f"Response: {response.text}")
        return False

def load_poles(map_id, table_name, access_token):
    conn = get_db_connection()
    cur = conn.cursor()

    try:
        # Split schema.table
        schema, table = table_name.split('.')
        
        # Query the PostGIS table
        query = f"""
            SELECT scid, lat, lng 
            FROM {schema}.{table}
            WHERE scid IS NOT NULL 
              AND lat IS NOT NULL 
              AND lng IS NOT NULL
              AND nodetype = 'pole'
        """
        
        cur.execute(query)
        poles = cur.fetchall()
        
        print(f"📊 Found {len(poles)} poles to process")
        
        success_count = 0
        for pole in poles:
            if create_pole(access_token, map_id, pole):
                success_count += 1
        
        print(f"\n✅ Successfully created {success_count} out of {len(poles)} poles")

    except Exception as e:
        print(f"❌ Error processing poles: {str(e)}")
        sys.exit(1)
    finally:
        cur.close()
        conn.close()

def main():
    args = parse_arguments()
    access_token = get_access_token()
    load_poles(args.map_id, args.table, access_token)

if __name__ == "__main__":
    main()