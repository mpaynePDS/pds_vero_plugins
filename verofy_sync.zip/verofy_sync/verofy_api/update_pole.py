import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Update a pole properties')
    # Required pole ID
    parser.add_argument('--pole_id', required=True, help='Pole ID to update')
    
    # Optional location parameters
    parser.add_argument('--latitude', type=float, help='Pole latitude')
    parser.add_argument('--longitude', type=float, help='Pole longitude')
    
    # Optional visual parameters
    parser.add_argument('--custom', type=int, choices=[0, 1], help='Custom flag (0 or 1)')
    parser.add_argument('--color', help='Color value')
    parser.add_argument('--shape_id', type=int, help='Shape ID')
    parser.add_argument('--style_size', help='Style size')
    parser.add_argument('--opacity', type=float, help='Opacity value')
    
    # Optional identification parameters
    parser.add_argument('--name', help='Pole name')
    parser.add_argument('--tags', help='Tags')
    parser.add_argument('--group1', help='Group 1')
    parser.add_argument('--group2', help='Group 2')
    
    # Optional MR parameters
    parser.add_argument('--mr_state_id', type=int, help='MR State ID')
    parser.add_argument('--comms_mr_choice_id', type=int, help='Communications MR Choice ID')
    parser.add_argument('--power_mr_choice_id', type=int, help='Power MR Choice ID')
    
    # Optional physical parameters
    parser.add_argument('--pole_height', type=float, help='Pole height')
    parser.add_argument('--attachment_height', type=float, help='Attachment height')
    parser.add_argument('--mr_notes', help='MR Notes')
    parser.add_argument('--owner', help='Pole owner')
    
    # Permit association parameter
    parser.add_argument('--mappermitId', help='Map permit ID to associate with this pole (use "none" or "" to remove association)')
    
    args = parser.parse_args()
    
    # Show usage if only pole_id is provided with no other arguments
    if len(sys.argv) <= 2:
        parser.print_help()
        sys.exit(1)
        
    return args

def get_access_token():
    # Read credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    sys.exit(1)

def update_pole(pole_id, access_token, args):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Build update data dictionary from provided arguments
    update_data = {}
    
    # Map CLI arguments to API fields, converting types as needed
    field_mappings = {
        'latitude': ('latitude', str),
        'longitude': ('longitude', str),
        'custom': ('custom', int),
        'color': ('color', str),
        'shape_id': ('shapeId', int),
        'style_size': ('styleSize', str),
        'opacity': ('opacity', float),
        'name': ('name', str),
        'tags': ('tags', str),
        'group1': ('group1', str),
        'group2': ('group2', str),
        'mr_state_id': ('mrStateId', int),
        'comms_mr_choice_id': ('commsMrChoiceId', int),
        'power_mr_choice_id': ('powerMrChoiceId', int),
        'pole_height': ('poleHeight', float),
        'attachment_height': ('attachmentHeight', float),
        'mr_notes': ('mrNotes', str),
        'owner': ('owner', str),
        'mappermitId': ('mappermitId', 'special')
    }

    # Add non-None values to update_data
    for arg_name, (api_name, type_conv) in field_mappings.items():
        value = getattr(args, arg_name)
        if value is not None:
            # Special handling for mappermitId
            if arg_name == 'mappermitId':
                if value.lower() in ['none', '', '0', 'null']:
                    update_data[api_name] = ""  # Empty string to remove association
                else:
                    try:
                        update_data[api_name] = int(value)  # Convert to int for valid permit ID
                    except ValueError:
                        print(f"❌ Invalid permit ID: {value}. Use a number, 'none', or '' to remove association.")
                        sys.exit(1)
            else:
                update_data[api_name] = type_conv(value)

    # Send PATCH request
    response = requests.patch(
        f"{API_URL}/map-pole/update?id={pole_id}",
        headers=headers,
        json=update_data
    )

    if response.status_code == 200:
        print("✅ Pole Updated Successfully!")
        print(json.dumps(response.json(), indent=2))
        return response.json()
    else:
        print(f"❌ Failed to update pole! Status: {response.status_code}")
        print(f"Response: {response.text}")
        sys.exit(1)

def main():
    args = parse_arguments()
    access_token = get_access_token()
    updated_pole = update_pole(args.pole_id, access_token, args)

if __name__ == "__main__":
    main()