import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust this value to increase/decrease page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL documents for a specific map project, handling pagination efficiently
def list_documents(map_project_id, access_token):
    headers = {"Authorization": f"Bearer {access_token}"}
    documents = []
    
    # First request to determine total pages and documents
    response = requests.get(
        f"{API_URL}/map-documents?filter[mapProjectId]={map_project_id}&page=1&per-page={PER_PAGE}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve documents. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total pages & total documents from metadata
    total_documents = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Documents: {total_documents}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        documents.extend(data["items"])
        print(f"✅ Page 1 retrieved with {len(data['items'])} documents.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        response = requests.get(
            f"{API_URL}/map-documents?filter[mapProjectId]={map_project_id}&page={page}&per-page={PER_PAGE}",
            headers=headers
        )

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                documents.extend(data["items"])
                print(f"✅ Page {page} retrieved with {len(data['items'])} documents.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file
    filename = f"{map_project_id}_documents.json"
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(documents, json_file, indent=4)

    print(f"\n✅ Successfully saved {len(documents)} documents to `{filename}`.")

def get_single_document(document_id, access_token):
    """Fetch a single document by its ID"""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Try the singular form first (as documented)
    response = requests.get(
        f"{API_URL}/map-document/{document_id}",
        headers=headers
    )
    
    # If that fails, try filtering from the collection
    if response.status_code == 404:
        print("🔄 Trying alternative endpoint...")
        response = requests.get(
            f"{API_URL}/map-documents?filter[id]={document_id}",
            headers=headers
        )
        
        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                print(json.dumps(data["items"][0], indent=2))
                return data["items"][0]
            else:
                print(f"❌ Document with ID {document_id} not found in results")
                return None

    if response.status_code != 200:
        print(f"❌ Failed to retrieve document. Status: {response.status_code}, Response: {response.text}")
        return None

    # Print formatted JSON to terminal
    print(json.dumps(response.json(), indent=2))
    return response.json()

def download_document(document_id, access_token):
    """Download a document file by its ID using the URL provided in document metadata"""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # First get document metadata which includes the download URL
    print(f"🔍 Getting document metadata for ID: {document_id}")
    doc_response = requests.get(
        f"{API_URL}/map-documents?filter[id]={document_id}",
        headers=headers
    )
    
    if doc_response.status_code != 200:
        print(f"❌ Failed to retrieve document metadata. Status: {doc_response.status_code}")
        return None
        
    data = doc_response.json()
    if "items" not in data or len(data["items"]) == 0:
        print(f"❌ Document with ID {document_id} not found")
        return None
    
    doc_data = data["items"][0]
    filename = doc_data.get('name', f'document_{document_id}')
    download_url = doc_data.get('download', None)
    
    if not download_url:
        print("❌ No download URL found in document metadata")
        return None
        
    print(f"📄 Document: {filename}")
    print(f"🔗 Using download URL: {download_url}")
    
    # Use the exact download URL provided in the document metadata
    download_response = requests.get(download_url, headers=headers)

    if download_response.status_code != 200:
        print(f"❌ Failed to download document. Status: {download_response.status_code}")
        if download_response.status_code == 404:
            print("💡 This might be an API limitation or permission issue")
        return None

    # Save the file using the original filename
    file_path = filename
    with open(file_path, 'wb') as f:
        f.write(download_response.content)
    
    print(f"✅ Document downloaded successfully as: {file_path}")
    return file_path

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ Usage:")
        print("  Get all documents: python get_documents.py <MAP_PROJECT_ID>")
        print("  Get single document: python get_documents.py --doc <DOCUMENT_ID>")
        print("  Download document: python get_documents.py --download <DOCUMENT_ID>")
        exit(1)

    access_token = get_access_token()
    if not access_token:
        exit(1)

    if sys.argv[1] == "--doc" and len(sys.argv) == 3:
        # Get single document metadata
        get_single_document(sys.argv[2], access_token)
    elif sys.argv[1] == "--download" and len(sys.argv) == 3:
        # Download document file
        download_document(sys.argv[2], access_token)
    else:
        # Get all documents for map project
        list_documents(sys.argv[1], access_token)