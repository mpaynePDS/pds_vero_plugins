import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

def get_access_token():
    """Get a new access token using login credentials"""
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    return None

def get_references(ref_type=None, version_hash=None):
    """Fetch references - can be called without parameters"""
    access_token = get_access_token()
    if not access_token:
        return None

    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Build URL based on parameters
    url = f"{API_URL}/references"
    if ref_type:
        url += f"/{ref_type}"
        if version_hash:
            url += f"?hash={version_hash}"

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        print(f"✅ Successfully retrieved references")
        return data
    elif response.status_code == 410:
        print(f"❌ Reference type does not exist (410 Gone)")
    elif response.status_code == 401:
        print("❌ Unauthorized access (401)")
    else:
        print(f"❌ Error retrieving references. Status: {response.status_code}")
    return None

def save_references(ref_type, data):
    """Save references to a JSON file"""
    if data:
        filename = f"{ref_type}_references.json"
        with open(filename, "w", encoding="utf-8") as json_file:
            json.dump(data, json_file, indent=4)
        print(f"✅ References saved to {filename}")

if __name__ == "__main__":
    # Parse command line arguments
    ref_type = sys.argv[1] if len(sys.argv) > 1 else None
    version_hash = sys.argv[2] if len(sys.argv) > 2 else None

    # Get references
    references = get_references(ref_type, version_hash)
    if references:
        if ref_type:
            # If specific reference type requested, save to type-specific file
            save_references(ref_type, references)
            if "_hash" in references:
                print(f"🔒 Reference Hash: {references['_hash']}")
        else:
            # Save full reference response to all_references.json
            filename = "all_references.json"
            with open(filename, "w", encoding="utf-8") as json_file:
                json.dump(references, json_file, indent=2)
            print(f"✅ All references saved to {filename}")