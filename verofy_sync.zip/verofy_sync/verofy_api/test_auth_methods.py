import requests
import os

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")
API_KEY = os.getenv("VEROFY_API_KEY")  # You might need to get this from admin

def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            return token_response.json().get("access-token")
    return None

def test_auth_methods():
    """Test different authentication methods for document download"""
    
    # Test with Access Token
    access_token = get_access_token()
    if access_token:
        print("🔑 Testing with Access Token...")
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(
            "https://api.verofy.veronetworks.com/v1/map-documents/download/73402", 
            headers=headers
        )
        print(f"   Access Token Result: {response.status_code}")
        if response.status_code != 200:
            print(f"   Response: {response.text[:100]}...")
    else:
        print("❌ Could not get access token")
    
    # Test with API Key (if available)
    if API_KEY:
        print("\n🔑 Testing with API Key...")
        headers = {"Authorization": f"Bearer {API_KEY}"}
        response = requests.get(
            "https://api.verofy.veronetworks.com/v1/map-documents/download/73402", 
            headers=headers
        )
        print(f"   API Key Result: {response.status_code}")
        if response.status_code == 200:
            print(f"   ✅ Success with API Key!")
            print(f"   Content-Type: {response.headers.get('Content-Type', 'unknown')}")
            return response.content
        else:
            print(f"   Response: {response.text[:100]}...")
    else:
        print("\n⚠️  No API Key found in environment (VEROFY_API_KEY)")
    
    # Test without any authentication
    print("\n🔑 Testing without authentication...")
    response = requests.get(
        "https://api.verofy.veronetworks.com/v1/map-documents/download/73402"
    )
    print(f"   No Auth Result: {response.status_code}")
    if response.status_code != 200:
        print(f"   Response: {response.text[:100]}...")
    
    return None

if __name__ == "__main__":
    print("🧪 Testing different authentication methods for document download...")
    print("=" * 60)
    
    content = test_auth_methods()
    if content:
        with open("downloaded_with_api_key.pdf", "wb") as f:
            f.write(content)
        print(f"\n🎉 Successfully downloaded document!")
    else:
        print(f"\n❌ Document download failed with all authentication methods")
        print(f"\n💡 Possible reasons:")
        print(f"   1. Download functionality not implemented in API")
        print(f"   2. Requires API Key authentication (ask admin)")
        print(f"   3. Files stored elsewhere (not through API)")
        print(f"   4. Special permissions required")