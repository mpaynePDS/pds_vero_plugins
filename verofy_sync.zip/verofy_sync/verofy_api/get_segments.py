import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust to maximize API efficiency

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Ensure a map project ID is provided as a command-line argument
if len(sys.argv) < 2:
    print("❌ Usage: python get_segments.py <MAP_PROJECT_ID>")
    exit(1)

MAP_PROJECT_ID = sys.argv[1]  # Get map ID from command line

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL segments for a specific map project, handling pagination
def list_segments(map_project_id, access_token):
    headers = {"Authorization": f"Bearer {access_token}"}
    segments = []
    
    # First request to determine total pages and segments
    response = requests.get(
        f"{API_URL}/map-segment?filter%5BmapProjectId%5D={map_project_id}&page=1&per-page={PER_PAGE}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve segments. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total segments and pages from metadata
    total_segments = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Segments: {total_segments}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        segments.extend(data["items"])
        print(f"✅ Page 1 retrieved with {len(data['items'])} segments.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        response = requests.get(
            f"{API_URL}/map-segment?filter%5BmapProjectId%5D={map_project_id}&page={page}&per-page={PER_PAGE}",
            headers=headers
        )

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                segments.extend(data["items"])
                print(f"✅ Page {page} retrieved with {len(data['items'])} segments.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file
    filename = f"{map_project_id}_segments.json"
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(segments, json_file, indent=4)

    print(f"\n✅ Successfully saved {len(segments)} segments to `{filename}`.")

# Run the process
if __name__ == "__main__":
    access_token = get_access_token()
    if access_token:
        list_segments(MAP_PROJECT_ID, access_token)