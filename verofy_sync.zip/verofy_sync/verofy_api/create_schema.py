import os
from dotenv import load_dotenv
import psycopg2
from psycopg2 import Error

def create_schema():
    # Load environment variables
    load_dotenv()

    # Initialize connection as None
    conn = None
    cur = None

    try:
        # Database connection parameters
        db_params = {
            "host": os.getenv("POSTGRES_HOST"),
            "port": int(os.getenv("POSTGRES_PORT", 5432)),  # Convert port to integer
            "database": os.getenv("POSTGRES_DB"),
            "user": os.getenv("POSTGRES_USER"),
            "password": os.getenv("POSTGRES_PASSWORD")
        }

        # Validate connection parameters
        missing_params = [k for k, v in db_params.items() if not v]
        if missing_params:
            raise ValueError(f"Missing required database parameters: {', '.join(missing_params)}")

        # Establish connection
        print("📡 Connecting to PostgreSQL database...")
        print(f"   Host: {db_params['host']}")
        print(f"   Database: {db_params['database']}")
        print(f"   User: {db_params['user']}")
        
        conn = psycopg2.connect(**db_params)
        
        # Create a cursor object
        cur = conn.cursor()
        
        # Create schema if it doesn't exist
        print("🔧 Creating schema 'verofy'...")
        cur.execute("CREATE SCHEMA IF NOT EXISTS verofy;")
        
        # Commit the transaction
        conn.commit()
        print("✅ Schema created successfully!")

    except ValueError as ve:
        print(f"❌ Configuration error: {ve}")
    except (Exception, Error) as error:
        print(f"❌ Error while connecting to PostgreSQL: {error}")
    
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()
            print("🔌 Database connection closed.")

if __name__ == "__main__":
    create_schema()