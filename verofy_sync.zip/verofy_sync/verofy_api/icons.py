import json
import base64
import os
import sys
from pathlib import Path

def extract_icons(json_data, output_dir="."):
    """Extract icons from JSON data and save them to folders"""
    
    # Check if this is a single reference type file
    if isinstance(json_data, dict) and not any(k.startswith('_') for k in json_data.keys()):
        # Wrap single reference type in dict to match full references format
        ref_type = Path(sys.argv[1]).stem.replace('_references', '')
        json_data = {ref_type: json_data}
    
    for ref_type, content in json_data.items():
        # Skip special keys like _hash
        if ref_type.startswith('_'):
            continue
            
        # Look for items with icons
        for item_id, item_data in content.items():
            if isinstance(item_data, dict) and 'icon' in item_data and item_data['icon']:
                # Create folder for this reference type
                folder = Path(output_dir) / ref_type
                folder.mkdir(exist_ok=True)
                
                # Get filename from name field, fallback to ID if no name
                # Ensure .png extension is properly added
                base_filename = f"{item_data.get('name', item_id)}"
                # Clean filename of invalid characters
                base_filename = "".join(c for c in base_filename if c.isalnum() or c in (' ', '-', '_')).rstrip()
                filepath = folder / f"{base_filename}.png"
                
                try:
                    # Decode and save icon
                    icon_data = base64.b64decode(item_data['icon'])
                    with open(filepath, 'wb') as f:
                        f.write(icon_data)
                    print(f"✅ Saved icon: {filepath}")
                except Exception as e:
                    print(f"❌ Error saving {filepath}: {str(e)}")

def main():
    if len(sys.argv) != 2:
        print("❌ Usage: python icons.py <json_file>")
        sys.exit(1)
    
    json_file = Path(sys.argv[1])
    if not json_file.exists():
        print(f"❌ File not found: {json_file}")
        sys.exit(1)
        
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except json.JSONDecodeError:
        print(f"❌ Invalid JSON file: {json_file}")
        sys.exit(1)
    
    # Create output directory next to the script
    script_dir = Path(__file__).parent
    output_dir = script_dir / "icons"
    output_dir.mkdir(exist_ok=True)
    
    extract_icons(data, output_dir)
    print("✅ Icon extraction complete!")

if __name__ == "__main__":
    main()