import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Create a permit on a map')
    parser.add_argument('--map_id', required=True, help='Map Project ID where the permit will be created')
    parser.add_argument('--name', default='Test Permit', help='Name for the permit')
    parser.add_argument('--mappermitstatusId', type=int, default=1, help='Map permit status ID (default: 1)')
    parser.add_argument('--mappermitentitytypeId', type=int, default=1, help='Map permit entity type ID (default: 1)')
    parser.add_argument('--mappermitulrtypeId', type=int, default=1, help='Map permit ULR type ID (default: 1)')
    parser.add_argument('--mappermitentitymeetId', type=int, default=1, help='Map permit entity meet ID (default: 1)')
    parser.add_argument('--mappermitrequirementsId', type=int, default=1, help='Map permit requirements ID (default: 1)')
    parser.add_argument('--owner', default='Default Owner', help='Permit owner')
    parser.add_argument('--permitnumber', help='Permit number')
    parser.add_argument('--permitgroup', help='Permit group')
    parser.add_argument('--permitgroup2', help='Permit group 2')
    parser.add_argument('--submita', help='Submit date (e.g., 06-02-25)')
    parser.add_argument('--receiveda', help='Received date (e.g., 06-02-25)')
    parser.add_argument('--expiration', help='Expiration date')
    parser.add_argument('--poly', help='Polygon coordinates as CSV string for outer ring (lat1,lng1,lat2,lng2,...)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    return parser.parse_args()

def parse_poly_csv(poly_csv):
    """Parse CSV coordinate string into polygon array with nested structure"""
    if not poly_csv:
        return None
    
    try:
        coords = [float(x.strip()) for x in poly_csv.split(',')]
        if len(coords) % 2 != 0:
            raise ValueError("Coordinates must be in pairs (lat,lng)")
        
        poly_ring = []
        for i in range(0, len(coords), 2):
            lat = round(coords[i], 6)  # 6 decimal precision
            lng = round(coords[i + 1], 6)  # 6 decimal precision
            poly_ring.append({"lat": lat, "lng": lng})
        
        # Permits use nested array structure [[{lat, lng}, ...]]
        return [poly_ring]
    except ValueError as e:
        print(f"❌ Error parsing polygon coordinates: {e}")
        print("Format should be: lat1,lng1,lat2,lng2,lat3,lng3,...")
        sys.exit(1)

def get_access_token(verbose=False):
    # Read credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    if verbose:
        print(f"🔑 Attempting login with email: {EMAIL}")

    # Get refresh token
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if verbose:
        print(f"📡 Login response status: {response.status_code}")
        print(f"📡 Login response: {response.text[:200]}...")
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        if verbose:
            print(f"🔄 Got refresh token: {refresh_token[:20]}...")
            
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if verbose:
            print(f"📡 Token refresh response status: {token_response.status_code}")
            print(f"📡 Token refresh response: {token_response.text[:200]}...")

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                if verbose:
                    print(f"🔓 Access token: {access_token[:20]}...")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    sys.exit(1)

def create_permit(access_token, args):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Create permit using the correct format from API documentation
    # Default polygon if none provided
    default_poly = [
        [
            {
                "lat": 32.090733,
                "lng": -96.487830
            },
            {
                "lat": 32.090764,
                "lng": -96.487763
            },
            {
                "lat": 32.090804,
                "lng": -96.487792
            },
            {
                "lat": 32.090733,
                "lng": -96.487830
            }
        ]
    ]
    
    permit_data = {
        "mapProjectId": args.map_id,
        "name": args.name,
        "mappermitstatusId": args.mappermitstatusId,
        "mappermitentitytypeId": args.mappermitentitytypeId,
        "mappermitulrtypeId": args.mappermitulrtypeId,
        "mappermitentitymeetId": args.mappermitentitymeetId,
        "mappermitrequirementsId": args.mappermitrequirementsId,
        "owner": args.owner,
        "poly": parse_poly_csv(args.poly) if args.poly else default_poly
    }
    
    # Add optional fields only if provided
    if args.permitnumber is not None:
        permit_data["permitnumber"] = args.permitnumber
    if args.permitgroup is not None:
        permit_data["permitgroup"] = args.permitgroup
    if args.permitgroup2 is not None:
        permit_data["permitgroup2"] = args.permitgroup2
    if args.submita is not None:
        permit_data["submita"] = args.submita
    if args.receiveda is not None:
        permit_data["receiveda"] = args.receiveda
    if args.expiration is not None:
        permit_data["expiration"] = args.expiration

    if args.verbose:
        print(f"🚀 Creating permit with data:")
        print(json.dumps(permit_data, indent=2))
        print(f"📡 Will try multiple POST endpoints")
        print(f"📡 Headers: {headers}")

    # Use the correct endpoint - matches other create patterns  
    endpoint = f"{API_URL}/map-permit/create"
    
    
    print(f"🌐 Using correct endpoint: {endpoint}")
    print(f"📤 Request payload:")
    print(json.dumps(permit_data, indent=2))
    
    response = requests.post(endpoint, headers=headers, json=permit_data)
    
    print(f"📥 Response status: {response.status_code}")
    if response.status_code != 201:
        print(f"📥 Response headers:")
        print(json.dumps(dict(response.headers), indent=2))
        print(f"📥 Full response body:")
        print(response.text)

    if response.status_code == 201:
        print("✅ Permit created successfully!")
        response_data = response.json()
        print(f"🆔 Permit ID: {response_data.get('id', 'Not found')}")
        print("📄 Full response:")
        print(json.dumps(response_data, indent=2))
        return response_data
    else:
        print(f"❌ Failed to create permit! Status: {response.status_code}")
        print(f"📄 Error response: {response.text}")
        
        # Try to parse error details if JSON
        try:
            error_data = response.json()
            print("📄 Parsed error details:")
            print(json.dumps(error_data, indent=2))
        except:
            pass
            
        sys.exit(1)

def main():
    args = parse_arguments()
    
    if args.verbose:
        print(f"🎯 Target map ID: {args.map_id}")
        print(f"📝 Permit name: {args.name}")
        print(f"👤 Owner: {args.owner}")
        if args.poly:
            print(f"📍 Coordinates: {args.poly}")
        print("="*50)
    
    access_token = get_access_token(args.verbose)
    created_permit = create_permit(access_token, args)

if __name__ == "__main__":
    main()