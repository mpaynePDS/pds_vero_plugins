import requests
import json
import os

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Perform Health Check
def health_check():
    response = requests.get(f"{API_URL}/health-check")
    if response.status_code == 200 and "api_v1" in response.json():
        print("✅ Health Check: SUCCESS")
        return True
    else:
        print("❌ Health Check: FAIL")
        return False

# Perform Login and Retrieve Refresh Token
def login():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        if refresh_token:
            print("✅ Login: SUCCESS")
            print(f"🔑 Refresh Token: {refresh_token}")
            return refresh_token
    print(f"❌ Login Failed! Status: {response.status_code}, Response: {response.text}")
    return None

# Exchange Refresh Token for Access Token
def get_access_token(refresh_token):
    headers = {"Authorization": f"Bearer {refresh_token}"}
    
    response = requests.get(f"{API_URL}/refresh-token", headers=headers)

    if response.status_code == 200:
        data = response.json()
        access_token = data.get("access-token")

        if access_token:
            print("✅ Access Token Retrieved Successfully!")
            print(f"🔓 Access Token: {access_token}")
            return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Perform Access Check
def access_check(access_token):
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(f"{API_URL}/access-check", headers=headers)
    
    if response.status_code == 200 and "api_v1_access" in response.json():
        print("✅ Access Check: SUCCESS")
    else:
        print("❌ Access Check: FAIL")

# Run the sequence
if __name__ == "__main__":
    if health_check():
        refresh_token = login()
        if refresh_token:
            access_token = get_access_token(refresh_token)
            if access_token:
                access_check(access_token)