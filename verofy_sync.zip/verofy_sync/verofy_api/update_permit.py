import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Update a permit on a map')
    parser.add_argument('--permit_id', required=True, help='Permit ID to update')
    parser.add_argument('--name', help='Name for the permit')
    parser.add_argument('--mappermitstatusId', type=int, help='Map permit status ID')
    parser.add_argument('--mappermitentitytypeId', type=int, help='Map permit entity type ID')
    parser.add_argument('--mappermitulrtypeId', type=int, help='Map permit ULR type ID')
    parser.add_argument('--mappermitentitymeetId', type=int, help='Map permit entity meet ID')
    parser.add_argument('--mappermitrequirementsId', type=int, help='Map permit requirements ID')
    parser.add_argument('--owner', help='Permit owner')
    parser.add_argument('--permitnumber', help='Permit number')
    parser.add_argument('--permitgroup', help='Permit group')
    parser.add_argument('--permitgroup2', help='Permit group 2')
    parser.add_argument('--submita', help='Submit date (e.g., 06-02-25)')
    parser.add_argument('--receiveda', help='Received date (e.g., 06-02-25)')
    parser.add_argument('--expiration', help='Expiration date')
    parser.add_argument('--poly', help='Polygon coordinates as CSV string for outer ring (lat1,lng1,lat2,lng2,...)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    return parser.parse_args()

def parse_poly_csv(poly_csv):
    """Parse CSV coordinate string into polygon array with nested structure"""
    if not poly_csv:
        return None
    
    try:
        coords = [float(x.strip()) for x in poly_csv.split(',')]
        if len(coords) % 2 != 0:
            raise ValueError("Coordinates must be in pairs (lat,lng)")
        
        poly_ring = []
        for i in range(0, len(coords), 2):
            lat = round(coords[i], 6)  # 6 decimal precision
            lng = round(coords[i + 1], 6)  # 6 decimal precision
            poly_ring.append({"lat": lat, "lng": lng})
        
        # Permits use nested array structure [[{lat, lng}, ...]]
        return [poly_ring]
    except ValueError as e:
        print(f"❌ Error parsing polygon coordinates: {e}")
        print("Format should be: lat1,lng1,lat2,lng2,lat3,lng3,...")
        sys.exit(1)

def get_access_token(verbose=False):
    # Read credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    if verbose:
        print(f"🔑 Attempting login with email: {EMAIL}")

    # Get refresh token
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if verbose:
        print(f"📡 Login response status: {response.status_code}")
        print(f"📡 Login response: {response.text[:200]}...")
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        if verbose:
            print(f"🔄 Got refresh token: {refresh_token[:20]}...")
            
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if verbose:
            print(f"📡 Token refresh response status: {token_response.status_code}")
            print(f"📡 Token refresh response: {token_response.text[:200]}...")

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                if verbose:
                    print(f"🔓 Access token: {access_token[:20]}...")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    sys.exit(1)

def update_permit(access_token, args):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Build update data with only provided fields
    permit_data = {}
    
    if args.name is not None:
        permit_data["name"] = args.name
    if args.mappermitstatusId is not None:
        permit_data["mappermitstatusId"] = args.mappermitstatusId
    if args.mappermitentitytypeId is not None:
        permit_data["mappermitentitytypeId"] = args.mappermitentitytypeId
    if args.mappermitulrtypeId is not None:
        permit_data["mappermitulrtypeId"] = args.mappermitulrtypeId
    if args.mappermitentitymeetId is not None:
        permit_data["mappermitentitymeetId"] = args.mappermitentitymeetId
    if args.mappermitrequirementsId is not None:
        permit_data["mappermitrequirementsId"] = args.mappermitrequirementsId
    if args.owner is not None:
        permit_data["owner"] = args.owner
    if args.permitnumber is not None:
        permit_data["permitnumber"] = args.permitnumber
    if args.permitgroup is not None:
        permit_data["permitgroup"] = args.permitgroup
    if args.permitgroup2 is not None:
        permit_data["permitgroup2"] = args.permitgroup2
    if args.submita is not None:
        permit_data["submita"] = args.submita
    if args.receiveda is not None:
        permit_data["receiveda"] = args.receiveda
    if args.expiration is not None:
        permit_data["expiration"] = args.expiration
    if args.poly is not None:
        permit_data["poly"] = parse_poly_csv(args.poly)

    if not permit_data:
        print("❌ No update data provided! Please specify at least one field to update.")
        sys.exit(1)

    if args.verbose:
        print(f"🚀 Updating permit {args.permit_id} with data:")
        print(json.dumps(permit_data, indent=2))
        print(f"📡 PATCH URL: {API_URL}/map-permits/{args.permit_id}")
        print(f"📡 Headers: {headers}")

    # Update permit using PATCH request
    response = requests.patch(
        f"{API_URL}/map-permits/{args.permit_id}",
        headers=headers,
        json=permit_data
    )

    if args.verbose:
        print(f"📡 Update permit response status: {response.status_code}")
        print(f"📡 Update permit response headers: {dict(response.headers)}")
        print(f"📡 Update permit response body: {response.text}")

    if response.status_code == 200:
        print("✅ Permit updated successfully!")
        try:
            response_data = response.json()
            print(f"🆔 Permit ID: {response_data.get('id', 'Not found')}")
            print("📄 Updated permit data:")
            print(json.dumps(response_data, indent=2))
        except json.JSONDecodeError:
            print("📄 Response was not JSON format")
            print(f"Response text: {response.text}")
        return True
    else:
        print(f"❌ Failed to update permit! Status: {response.status_code}")
        print(f"📄 Error response: {response.text}")
        
        # Try to parse error details if JSON
        try:
            error_data = response.json()
            print("📄 Parsed error details:")
            print(json.dumps(error_data, indent=2))
        except:
            pass
            
        sys.exit(1)

def main():
    args = parse_arguments()
    
    if args.verbose:
        print(f"🎯 Target permit ID: {args.permit_id}")
        if args.name:
            print(f"📝 New name: {args.name}")
        if args.poly:
            print(f"📍 New coordinates: {args.poly}")
        if args.owner:
            print(f"👤 New owner: {args.owner}")
        print("="*50)
    
    access_token = get_access_token(args.verbose)
    update_permit(access_token, args)

if __name__ == "__main__":
    main()