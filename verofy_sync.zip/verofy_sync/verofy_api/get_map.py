import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Ensure a map ID is provided as a command-line argument
if len(sys.argv) < 2:
    print("❌ Usage: python get_map.py <MAP_PROJECT_ID>")
    exit(1)

MAP_PROJECT_ID = sys.argv[1]  # Get map ID from command line

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch Map Project Details
def get_map_project(map_project_id, access_token):
    headers = {"Authorization": f"Bearer {access_token}"}
    
    response = requests.get(f"{API_URL}/map-project/{map_project_id}", headers=headers)

    if response.status_code == 200:
        data = response.json()
        print("\n✅ Map Project Details:")
        print(json.dumps(data, indent=4))  # Pretty-print JSON response
    else:
        print(f"❌ Failed to retrieve map project. Status: {response.status_code}, Response: {response.text}")

# Run the process
if __name__ == "__main__":
    access_token = get_access_token()
    if access_token:
        get_map_project(MAP_PROJECT_ID, access_token)