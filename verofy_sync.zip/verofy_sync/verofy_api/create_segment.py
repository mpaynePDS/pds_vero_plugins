import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Create a segment on a map')
    parser.add_argument('--map_id', required=True, help='Map Project ID where the segment will be created')
    parser.add_argument('--name', default='Test Segment', help='Name for the segment')
    parser.add_argument('--type_id', type=int, default=5, help='Segment type ID (default: 5=Underground)')
    parser.add_argument('--status_id', type=int, default=1, help='Segment status ID (default: 1=Working)')
    parser.add_argument('--poly_coordinates', type=str, required=True)
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    return parser.parse_args()

def get_access_token(verbose=False):
    # Read credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    if verbose:
        print(f"🔑 Attempting login with email: {EMAIL}")

    # Get refresh token
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if verbose:
        print(f"📡 Login response status: {response.status_code}")
        print(f"📡 Login response: {response.text[:200]}...")
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        if verbose:
            print(f"🔄 Got refresh token: {refresh_token[:20]}...")
            
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if verbose:
            print(f"📡 Token refresh response status: {token_response.status_code}")
            print(f"📡 Token refresh response: {token_response.text[:200]}...")

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                if verbose:
                    print(f"🔓 Access token: {access_token[:20]}...")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    sys.exit(1)

def create_segment(access_token, args):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Create segment using the correct format from API documentation
    # Based on the update example, poly should be an array of coordinate objects
    # Using 6 decimal point precision for coordinates
    '''poly_coordinates = [
        {
            "lat": 32.771417,
            "lng": -96.121682
        },
        {
            "lat": 32.771380,
            "lng": -97.122870
        },
        {
            "lat": 32.770140,
            "lng": -97.122880
        },
        {
            "lat": 32.770150,
            "lng": -97.121300
        },
        {
            "lat": 32.770136,
            "lng": -97.119013
        },
        {
            "lat": 32.769635,
            "lng": -97.119000
        }
    ]'''
    try:
        poly_coordinates = json.loads(args.poly_coordinates)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON for poly_coordinates: {e}")

    segment_data = {
        "mapProjectId": int(args.map_id),
        "name": args.name,
        "typeId": args.type_id,
        "statusId": args.status_id,
        "poly": poly_coordinates,
        "color": "#000000",
        "styleWidth": 1,
        "exclude": 0,
        "custom": 0
    }

    if args.verbose:
        print(f"🚀 Creating segment with data:")
        print(json.dumps(segment_data, indent=2))
        print(f"📡 POST URL: {API_URL}/map-segment/create")
        print(f"📡 Headers: {headers}")

    # Create segment using POST request
    response = requests.post(
        f"{API_URL}/map-segment/create",
        headers=headers,
        json=segment_data
    )

    if args.verbose:
        print(f"📡 Create segment response status: {response.status_code}")
        print(f"📡 Create segment response headers: {dict(response.headers)}")
        print(f"📡 Create segment response body: {response.text}")

    if response.status_code == 201:
        print("✅ Segment created successfully!")
        response_data = response.json()
        print(f"🆔 Verofy ID: {response_data.get('id', 'Not found')}")
        print("📄 Full response:")
        print(json.dumps(response_data, indent=2))
        return response_data
    else:
        print(f"❌ Failed to create segment! Status: {response.status_code}")
        print(f"📄 Error response: {response.text}")
        
        # Try to parse error details if JSON
        try:
            error_data = response.json()
            print("📄 Parsed error details:")
            print(json.dumps(error_data, indent=2))
        except:
            pass
            
        sys.exit(1)

def main():
    args = parse_arguments()
    print('parsed args')
    if args.verbose:
        print(f"🎯 Target map ID: {args.map_id}")
        print(f"📝 Segment name: {args.name}")
        print(f"🔢 Type ID: {args.type_id}")
        print(f"📊 Status ID: {args.status_id}")
        print("="*50)
    
    access_token = get_access_token(args.verbose)
    created_segment = create_segment(access_token, args)

if __name__ == "__main__":
    main()