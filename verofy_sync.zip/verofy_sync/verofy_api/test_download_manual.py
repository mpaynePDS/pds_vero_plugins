import requests
import os

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            return token_response.json().get("access-token")
    return None

def test_download_direct():
    """Test downloading using the exact URL from document metadata"""
    access_token = get_access_token()
    if not access_token:
        print("❌ Failed to get access token")
        return
        
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Test different URL patterns for document 73402
    test_urls = [
        "https://api.verofy.veronetworks.com/v1/map-documents/download/73402",
        "https://api.verofy.veronetworks.com/v1/map-document/download/73402", 
        f"{API_URL}/map-documents/download/73402",
        f"{API_URL}/map-document/download/73402"
    ]
    
    for url in test_urls:
        print(f"\n🔗 Testing URL: {url}")
        response = requests.get(url, headers=headers)
        print(f"   Status: {response.status_code}")
        if response.status_code != 200:
            print(f"   Response: {response.text[:200]}...")
        else:
            print(f"   ✅ Success! Content-Type: {response.headers.get('Content-Type', 'unknown')}")
            print(f"   📦 Content-Length: {len(response.content)} bytes")
            return response.content, url
    
    return None, None

if __name__ == "__main__":
    content, working_url = test_download_direct()
    if content:
        with open("test_download.pdf", "wb") as f:
            f.write(content)
        print(f"\n🎉 Successfully downloaded using: {working_url}")
    else:
        print("\n❌ All download URLs failed")