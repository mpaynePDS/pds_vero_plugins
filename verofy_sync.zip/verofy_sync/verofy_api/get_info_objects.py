import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust this value to increase/decrease page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL info objects for a specific map project, handling pagination efficiently
def list_info_objects(map_project_id, access_token):
    headers = {"Authorization": f"Bearer {access_token}"}
    info_objects = []
    
    # First request to determine total pages and info objects
    response = requests.get(
        f"{API_URL}/map-info-objects?filter[mapProjectId]={map_project_id}&page=1&per-page={PER_PAGE}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve info objects. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total pages & total info objects from metadata
    total_info_objects = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Info Objects: {total_info_objects}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        info_objects.extend(data["items"])
        print(f"✅ Page 1 retrieved with {len(data['items'])} info objects.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        response = requests.get(
            f"{API_URL}/map-info-objects?filter[mapProjectId]={map_project_id}&page={page}&per-page={PER_PAGE}",
            headers=headers
        )

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                info_objects.extend(data["items"])
                print(f"✅ Page {page} retrieved with {len(data['items'])} info objects.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file
    filename = f"{map_project_id}_info_objects.json"
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(info_objects, json_file, indent=4)

    print(f"\n✅ Successfully saved {len(info_objects)} info objects to `{filename}`.")

def get_single_info_object(info_object_id, access_token):
    """Fetch a single info object by its ID"""
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(
        f"{API_URL}/map-info-object/{info_object_id}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve info object. Status: {response.status_code}, Response: {response.text}")
        return None

    # Print formatted JSON to terminal
    print(json.dumps(response.json(), indent=2))
    return response.json()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ Usage:")
        print("  Get all info objects: python get_info_objects.py <MAP_PROJECT_ID>")
        print("  Get single info object: python get_info_objects.py --info <INFO_OBJECT_ID>")
        exit(1)

    access_token = get_access_token()
    if not access_token:
        exit(1)

    if sys.argv[1] == "--info" and len(sys.argv) == 3:
        # Get single info object
        get_single_info_object(sys.argv[2], access_token)
    else:
        # Get all info objects for map project
        list_info_objects(sys.argv[1], access_token)