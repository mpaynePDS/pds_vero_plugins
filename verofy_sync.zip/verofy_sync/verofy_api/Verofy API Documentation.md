# Verofy API Documentation

## Getting Started

The Verofy API is semi-RESTful. If you are not familiar with interacting with REST API's please consider some preparatory research into RESTful API's. Note that this API does stray from RESTful design in some key places.

[REST API Introduction](https://www.geeksforgeeks.org/rest-api-introduction/)

Nearly any language and environment with web access can interact with REST API's, and the technology is well documented. For the purposes of this guide Python 3.10 will be used for examples as it is easy to understand and should be refactorable to many languages.

## API Structure

The API is implemented using Yii Modules to provide compatible support for multiple releases simultaneously. Every API call will have the API version as part of the endpoint URL to identify which release the client application will interact with. 

The Verofy API is RESTful, meaning endpoints may be addressed following the usual REST way. Most actions will be accessed by sending an HTTP request to the api in the form of:

```
<api_url>/<version>/<model>/<id>
```

Where:
- `<api_url>` is the baseurl of the api, such as "https://www.example.com"
- `<version>` is the API version you are using, such as "v1"
- `<model>` is the object type you are interacting with, such as "segments"
- `<id>` is the object id for actions which need a specified id

However it is important to note that different endpoints require different types of http requests, and some endpoints share the same URL between two types of request. It's usually best to reference the Endpoint documentation for an API version to make sure of how to reach a specific endpoint.

## Models

The API exists to provide a method of operating on models where a model is a discrete unit of data. In RESTful terms, each model is an object or record. This API additionally draws a distinction between Data-Driven and Enum-Like models.

### Data-Driven Models

These models represent editable and relatable data for an application. These are the models which should be regularly accessed and carry the bulk of the meaningful data. Some example models: segments, access-points, etc.

When accessing these models a RESTful VIEW endpoint will access an individual record for the specified model, and an INDEX endpoint will return a collection of records instead.

### Enum-Like Models

These models are not truly enums, as they are managed in the db and can occasionally be changed, but are intended as id lookups not configurable data. An Enum-Like should only relate an id with an option, or a name. They should be the same for all projects and not include data beyond that which is expected to be static.

Since these models are often referenced by Data-Driven models and are not large they are sent to a client by a single endpoint: references, which comes in a VIEW and INDEX variant. The references VIEW endpoint returns a collection of every entry for the specified enum-like, and the INDEX endpoint returns a collection of collections. For more information see References (VIEW) and References (INDEX).

## Endpoints

Endpoints may be generally divided into one of several categories:

- **Data-Driven Endpoints**: These compose the bulk of the API and are the most RESTful
- **Reference Endpoints**: These include those for Enum-Likes and getting Labels, and operate on collections as if they were records
- **Misc Endpoints**: These include endpoints used to login and authenticate, and other miscellaneous endpoints

### Health Check

This first endpoint is a useful as a sanity check to see if the API as a whole, or a specific API version is available, and make sure your application is using the correct URL.

There are multiple health-check endpoints: one which is not tied to a specific API version, and one for each API version. This allows for clients to test if the API service is available, and which versions of the API are available.

## Connect to the API

### Prerequisites (Optional: Python & Pip)

All guides, examples, and tutorials in this documentation will use Python 3.10 for portability and simplicity's sake. It is absolutely possible to follow along in another environment, as any language which can send and receive HTTP requests formatted as JSON should be compatible with the API.

Install Python 3 and Pip for your system:
- [How to install Python on Windows](https://www.geeksforgeeks.org/how-to-install-python-on-windows/)
- [How to install Pip on Windows](https://www.geeksforgeeks.org/how-to-install-pip-on-windows/)
- [Install Pip on Debian 12](https://phoenixnap.com/kb/install-pip-debian-12)

Install the requests package via pip:
[Requests Package](https://pypi.org/project/requests/)

### Access the Health Check Endpoint

Create a new python file (.py extension) and paste the following into it:

**example.py**

```python
import requests

# Check if API service is available
response = requests.get("https://api.example.com/health-check")

if (response.status_code == 200):
    print("API status: " + response.text)
    # Expected output: {"api_service":"OK"}

# Check if specific API version is available
response = requests.get("https://api.example.com/v1/health-check")

if (response.status_code == 200):
    print("API v1 status: " + response.text)
    # Expected output: {"api_v1":"OK"}
```

Remember to replace "api.example.com" in the example code with the url of the API instance you have access to.

Run the script and if the url is correct and the API service is accessible then expect the following response:

```
API status: {"api_service":"OK"}
API v1 status: {"api_v1":"OK"}
```

If the response looks correct then lets proceed to the Authentication Tutorial.

## Authentication Tutorial

### Authentication Types

There are two methods of authentication with the Verofy API:

**Token Authentication**: For user facing clients such as mobile apps or user written scripts
- Login process takes multiple steps
- Balances security with user convenience
- Users login with their email and password

**Key Authentication**: For automated clients such as back-end scripts or services
- Login process is one step
- Requires an Administrator to manage keys
- Only available for systems that cant handle complex interactions.

This tutorial will walk through logging in using the Token Auth method.

### Login using Token Auth

#### Understanding Refresh and Access Tokens

There are two types of tokens:

**Refresh Token**
- Long Lived
- May be used only once
- Can be invalidated by the server at any time
- Used to get a new Access Token

**Access Token**
- Short Lived
- May be used unlimited times until it expires
- Used to authenticate the user with most endpoints
- Cannot be used to issue new tokens

#### Send User Credentials to the "login" Endpoint

The next steps will require a Verofy account to proceed. If you do not have a user contact your administrator to create one for you.

The login endpoint is reached with a POST request sent to the path `<api_url>/<version>/login`, and expects the "email" and "password" body params. If the provided credentials are valid then the endpoint will respond with a refresh-token.

> **WARNING**: DO NOT SEND USER CREDENTIALS WITHOUT HTTPS! Consider using the health-check endpoint to check if you are using https…

```python
import requests
import json
import getpass

# Don't hard-code or store user credentials! Always ask user...
ident = {
    "email": getpass.getuser(),
    "password": getpass.getpass() 
}

response = requests.post("https://www.example.com/v1/login", json=ident)

if (response.status_code == 200):
    refresh_token = response.json()["refresh-token"]
    print("Got new refresh token:\t" + refresh_token)
else:
    print("Failed to login!")
```

## Endpoint Documentation

## Miscellaneous Endpoints

### Health Check (MISC)

Check if the API is accessible, or if a particular version of the api is available.

There are two variants of this endpoint; one for checking if the API service is available (regardless of version), and one for checking if a specific API version is available.

Will respond with a status 200: OK if the requested service is available, or a 404: Not Found if not.

#### Ex. 1: Service Health Check

```python
import requests

response = requests.get("https://www.example.com/health-check")
print(response.status_code)  # 200 expected
print(response.text)         # {"api_service": "OK"} expected
```

#### Ex. 2: Version Health Check

```python
import requests

response = requests.get("https://www.example.com/v1/health-check")
print(response.status_code)  # 200 expected
print(response.text)         # {"api_v1": "OK"} expected
```

### Access Check (MISC)

Check if authentication has been successful. Allows for authentication with either an access-token or an api-key.

Will respond with a status 200: OK if authentication was successful, or a 401: Unauthorized if not.

#### Ex. 3: Failed Access Check

```python
import requests

response = requests.get("https://www.example.com/v1/access-check")
print(response.status_code)  # 401 expected
```

#### Ex. 4: Successful Access Check

```python
import requests

headers = {
    "Authorization": "Bearer n20usc92gb2_not_a_real_access_token_1v51r8jmrtfc"
}
response = requests.get(
    "https://www.example.com/v1/references/MapSegmentType", 
    headers=headers
)
print(response.status_code)  # 200 expected
print(response.text)         # {"api_v1_access": "OK"} expected
```

### Login (MISC)

Provide user credentials to retrieve a refresh-token.

Intended to be used by user-facing clients. Clients should store the retrieved refresh-token for later use.

> **WARNING**: DO NOT STORE USER CREDENTIALS IN A CLIENT APP, ASK USER TO PROVIDE ON EACH LOGIN!

Will respond with a freshly minted refresh-token if credentials were valid, or a 401: Unauthorized if not.

> **WARNING**: DO NOT SEND USER CREDENTIALS WITHOUT HTTPS!!!

#### Ex. 5: Get Refresh-Token with Login

```python
import requests
import getpass

# Don't hard-code or store user credentials! Always ask user...
ident = {
    "email": getpass.getuser(),
    "password": getpass.getpass() 
}

response = requests.post("https://www.example.com/v1/login", json=ident)
print(response.status_code)     # 200 expected
print(response.text)         
# {
#    "username": "example@example.com",
#    "first-name": "John",
#    "last-name": "Doe",
#    "refresh-token": "tq290v0190n1oe290_not_a_real_refresh_token_2901bg02g81"
# } expected
```

### Refresh Token (MISC)

Exchange a refresh-token for a new refresh-token and a freshly minted access-token.

Intended to be used by user-facing clients. Clients should store both the retrieved refresh-token and access-token for later use.

Note that refresh-tokens may be only used once, and once used will be invalidated. To avoid requiring users to re-login every time clients should store the new refresh-token returned by a successful call for future use.

Will respond with a new refresh-token and a new access-token if provided refresh-token is valid, or a 401: Unauthorized if not.

#### Ex. 6: Get Access-Token with Refresh-Token

```python
import requests

# Use the "login" endpoint to exchange user credentials for a refresh-token
headers = {
    "Authorization": "Bearer tq290v0190n1oe290_not_a_real_refresh_token_2901bg02g81"
}

response = requests.get("https://www.example.com/v1/refresh-access", headers=headers)
print(response.status_code)     # 200 expected
print(response.text) 
# {
#    "username": "example@example.com",
#    "access-token": "n20usc92gb2_not_a_real_access_token_1v51r8jmrtfc",
#    "refresh-token": "8b1w1sx5gfwgwg_new_refresh_token_qn2n7ed2f22bn5ed"
# } expected
```

## Reference Endpoints

### References (VIEW)

Retrieve the specified complete collection of reference models as a single resource.

Optionally clients may provide the "hash" param and the server will compare against its own hash for the collection. If they differ the collection will be returned, else an empty response. If the "hash" param is not supplied then the full collection will be returned.

If a ref-type is specified which does not exist on the server then it will respond with 410: Gone and client should remove its copies of the resource and not request that ref-type again.

Will respond with a collection-as-resource for the specified reference model type, 410: Gone if the ref-type doesn't exist, or a 401: Unauthorized if not authorized.

## Endpoints

### Projects

#### Map Project (map-project)

A Map Project groups multiple mapping elements, such as segments, sites, and access points.

**Attributes:**
- `id` (int) - Unique identifier
- `name` (string) - Project name
- `description` (string) - Detailed project description
- `status` (string) - Project status (active, completed, archived)
- `created_at` (datetime) - Creation timestamp
- `updated_at` (datetime) - Last update timestamp

**Endpoints for Projects:**

| Action | Method | Endpoint |
|--------|--------|----------|
| Read | GET | `{api_url}/{version}/map-project/{id}` |
| Create | POST | `{api_url}/{version}/map-project` |
| Update | PATCH | `{api_url}/{version}/map-project/{id}` |
| Upload Document | POST | `{api_url}/{version}/map-document/upload` |
| Download Document | GET | `{api_url}/{version}/map-document/download/{id}` |

#### Project Permissions

Permissions can be managed at the project level to restrict or allow access to users.

- `GET {api_url}/{version}/map-project/permission/{mapProjectId}` - Check user access to a project
- `POST {api_url}/{version}/map-project/bookmark/{mapProjectId}` - Bookmark a project for quick access

#### Miscellaneous Actions

Additional operations related to Map Projects that provide extended functionality.

**Check User Permissions**

Retrieve the access permissions for a specific project.

`GET {api_url}/{version}/map-project/permission/{mapProjectId}` - Check user access to a project

Example: `GET https://api.veronetworks.com/v1/map-project/permission/12345`

**Bookmark a Project**

Mark a project for quick access.

`POST {api_url}/{version}/map-project/bookmark/{mapProjectId}`

Example: `POST https://api.veronetworks.com/v1/map-project/bookmark/12345`

## Models

The Verofy API is RESTful, and most actions can be accessed by sending HTTP requests to the API in the following format:

```
<api_url>/<version>/<model>/<id>
```

Where:
- `<api_url>` is the base URL of the API, e.g., https://api.veronetworks.com
- `<version>` is the API version you're using, e.g., v1
- `<model>` is the object type you're interacting with, e.g., map-segment
- `<id>` is the object id for actions that require a specific object

### Action Types

The following actions are supported:

**Read:**
- Method: GET
- Endpoint: `{api_url}/{version}/{model}/{id}`

**Create:**
- Method: POST
- Endpoint: `{api_url}/{version}/{model}/create`

**Update:**
- Method: PATCH
- Endpoint: `{api_url}/{version}/{model}/update?id={id}`

### Modules and Endpoints

Below is a list of modules along with their available actions:

#### Map Access Point
- **Read**: `GET {api_url}/{version}/map-access-point/{id}`
- **Read All**: `GET {api_url}/{version}/map-access-points`
- **Create**: `POST {api_url}/{version}/map-access-point/create`
- **Update**: `PATCH {api_url}/{version}/map-access-point/update?id={id}`

#### Map Cable
- **Read**: `GET {api_url}/{version}/map-cable/{id}`
- **Read All**: `GET {api_url}/{version}/map-cables`
- **Create**: `POST {api_url}/{version}/map-cable/create`
- **Update**: `PATCH {api_url}/{version}/map-cable/update?id={id}`

#### Map Document
- **Read**: `GET {api_url}/{version}/map-document/{id}`
- **Read All**: `GET {api_url}/{version}/map-documents`
- **Create**: `POST {api_url}/{version}/map-document/create`
- **Update**: `PATCH {api_url}/{version}/map-document/update?id={id}`

#### Map Element
- **Read**: `GET {api_url}/{version}/map-element/{id}`
- **Read All**: `GET {api_url}/{version}/map-elements`
- **Create**: `POST {api_url}/{version}/map-element/create`
- **Update**: `PATCH {api_url}/{version}/map-element/update?id={id}`

#### Map Info Object
- **Read**: `GET {api_url}/{version}/map-info-object/{id}`
- **Read All**: `GET {api_url}/{version}/map-info-objects`
- **Create**: `POST {api_url}/{version}/map-info-object/create`
- **Update**: `PATCH {api_url}/{version}/map-info-object/update?id={id}`

#### Map Note
- **Read**: `GET {api_url}/{version}/map-note/{id}`
- **Read All**: `GET {api_url}/{version}/map-notes`
- **Create**: `POST {api_url}/{version}/map-note/create`
- **Update**: `PATCH {api_url}/{version}/map-note/update?id={id}`

#### Map Permit
- **Read**: `GET {api_url}/{version}/map-permits/{id}`
- **Read All**: `GET {api_url}/{version}/map-permits`
- **Create**: `POST {api_url}/{version}/map-permit/create`
- **Update**: `PATCH {api_url}/{version}/map-permits/{id}`

**Example Update:**
```
PATCH https://api.veronetworks.com/v1/map-permits/30768
BODY:
{
  "mapProjectId": "11572",
  "poly": [
    [
      {
        "lat": "37.129198",
        "lng": "-87.791584"
      },
      {
        "lat": "36.127619",
        "lng": "-88.790082"
      }
    ],
    [
      {
        "lat": "35.126390",
        "lng": "-89.792399"
      },
      {
        "lat": "35.124500",
        "lng": "-89.794000"
      }
    ]
  ]
}
```

#### Map Pole
- **Read**: `GET {api_url}/{version}/map-pole/{id}`
- **Read All**: `GET {api_url}/{version}/map-poles`
- **Create**: `POST {api_url}/{version}/map-pole/create`
- **Update**: `PATCH {api_url}/{version}/map-pole/update?id={id}`

#### Map Segment
- **Read**: `GET {api_url}/{version}/map-segments/{id}`
- **Read All**: `GET {api_url}/{version}/map-segments`
- **Create**: `POST {api_url}/{version}/map-segment/create`
- **Update**: `PATCH {api_url}/{version}/map-segments/{id}`

**Example Update:**
```
PATCH https://api.veronetworks.com/v1/map-segments/1177
BODY:
{
    "mapProjectId": 41,
    "poly": [
        {
            "lat": 32.7714169834758,
            "lng": -96.12168230422975
        },
        {
            "lat": 32.77138,
            "lng": -97.12287
        },
        {
            "lat": 32.770140000000005,
            "lng": -97.12288000000001
        },
        {
            "lat": 32.77015,
            "lng": -97.1213
        },
        {
            "lat": 32.77013598463115,
            "lng": -97.11901284516131
        },
        {
            "lat": 32.769634804144374,
            "lng": -97.11900020370484
        }
    ]
}
```

#### Map Site
- **Read**: `GET {api_url}/{version}/map-site/{id}`
- **Read All**: `GET {api_url}/{version}/map-sites`
- **Create**: `POST {api_url}/{version}/map-site/create`
- **Update**: `PATCH {api_url}/{version}/map-site/update?id={id}`

#### Map Splice
- **Read**: `GET {api_url}/{version}/map-splice/{id}`
- **Read All**: `GET {api_url}/{version}/map-splices`
- **Create**: `POST {api_url}/{version}/map-splice/create`
- **Update**: `PATCH {api_url}/{version}/map-splice/update?id={id}`

### Expanding Tags

Some models support retrieving related tags directly in the response using the expand query parameter.

**Usage:**
```
GET {api_url}/{version}/{model}/{id}?expand=tags
```

This returns the base model plus its associated tags.

Only models that extend MapItem and define the tags relation will support this.

**Example:**
```
GET https://api.veronetworks.com/v1/map-permit/9540?expand=tags
```

**Response (snippet):**
```json
{
  "id": 9540,
  "name": "Lower - Woodruff Rd S-417 (2) PH2",
  "tags": [
    {
      "id": 857,
      "name": "Lower",
      "mapprojectId": 216
    }
  ]
}
```

To expand multiple fields, separate them with commas.
Example: `?expand=tags,owner`

### Filters

The Verofy API supports filters for more refined queries. Filters can be applied directly in the URL as query parameters. For example:

To filter map poles by mapProjectId, you can use the following endpoint:

```
GET {api_url}/{version}/map-pole?filter%5BmapProjectId%5D=38
```

In this case, the filter `%5BmapProjectId%5D=38` applies a filter to retrieve all map poles associated with the mapProjectId 38.

## CRM Endpoints

### Authentication

All CRM endpoints require an API Key to authenticate requests.
Include the API Key in the Authorization header of your request:

### GET /v1/crm-vendors

**Description**
Retrieve a list of CRM vendors.

**Request Example**
```bash
curl -X GET "https://api.veronetworks.com/v1/crm-vendors" \
  -H "Authorization: YOUR-API-KEY"
```

**Response Example**
```json
{
  "items": [
    {
      "id": 1001,
      "name": "Vendor One",
      "email": "vendor1@example.com",
      "layout": "Standard",
      "primaryContactId": null,
      "backupContactId": null,
      "ownerId": 1
    },
    {
      "id": 1002,
      "name": "Vendor Two",
      "email": "vendor2@example.com",
      "layout": "Advanced",
      "primaryContactId": null,
      "backupContactId": null,
      "ownerId": 2
    }
  ],
  "_links": {
    "self": {
      "href": "https://api.veronetworks.com/v1/crm-vendors?page=1"
    },
    "first": {
      "href": "https://api.veronetworks.com/v1/crm-vendors?page=1"
    },
    "last": {
      "href": "https://api.veronetworks.com/v1/crm-vendors?page=10"
    },
    "next": {
      "href": "https://api.veronetworks.com/v1/crm-vendors?page=2"
    }
  },
  "_meta": {
    "totalCount": 200,
    "pageCount": 10,
    "currentPage": 1,
    "perPage": 20
  }
}
```

### List of Other CRM Endpoints

All other CRM endpoints follow the same authentication and response format.

#### GET /v1/crm-contacts
Retrieve a list of CRM contacts.

#### GET /v1/crm-accounts
Retrieve a list of CRM accounts.

#### GET /v1/crm-services
Retrieve a list of CRM services.

#### GET /v1/crm-capital-projects
Retrieve a list of CRM capital projects.

#### GET /v1/crm-billing-items
Retrieve a list of CRM billing items.

### Notes
- All responses follow the same structure as crm-vendors
- Pagination is supported using query parameters like `?page=2`
- Ensure you replace YOUR-API-KEY in the examples with a valid API Key

## Code Examples

### PHP Example

```php
<?php

use yii\httpclient\Client;

$client = new Client([
    'baseUrl' => "https://apidev.verofy.veronetworks.com/v1",
]);

$refreshToken = getRefreshToken($client);
$accessToken = getAccessToken($client, $refreshToken);

// Example #1. Get a list of map sites filtering by externalId
$externalId = 1002;
$mapPointId = null;

$rs = $this->client->createRequest()
    ->setMethod('GET')
    ->setUrl('/map-site?filter[externalId]=' . $externalId)
    ->setHeaders(['Authorization' => 'Bearer ' . $accessToken])
    ->send();

foreach ($rs->data['items'] as $item) {
    if (isset($item['externalId']) && $item['externalId'] == $externalId) {
        // We found specific map site by it external Id
        $mapPointId = $item['id'];
    }
}

// Example #2. Update map point by its id
$request = $client->createRequest()
    ->setMethod('PATCH')
    ->setUrl("map-site/update?id={$mapPointId}")
    ->setFormat(Client::FORMAT_JSON)
    ->setHeaders([
        'Authorization' => 'Bearer ' . $accessToken,
        'Accept' => 'application/json',
    ])
    ->setData([
        'latitude' => 34.00,
        'longitude' => 33.00,
        'name' => 'John Doe',
        'address1' => '3551 Poppi Ave, Evans, CO 80620',
        // Some other attributes
    ]);

    // Do actual request
    $response = $request->send();
?>
```

## API URLs

- **Development API URL**: https://apidev.verofy.veronetworks.com/
- **Production API URL**: https://api.verofy.veronetworks.com/