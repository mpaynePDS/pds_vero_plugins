import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust this value to increase/decrease page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL permits for a specific map project, handling pagination efficiently
def list_permits(map_project_id, access_token, owner_filter=None):
    headers = {"Authorization": f"Bearer {access_token}"}
    permits = []
    
    # Build URL with filters
    base_url = f"{API_URL}/map-permits?filter[mapProjectId]={map_project_id}"
    if owner_filter:
        base_url += f"&filter[owner]={owner_filter}"
    
    # First request to determine total pages and permits
    response = requests.get(
        f"{base_url}&page=1&per-page={PER_PAGE}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve permits. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total pages & total permits from metadata
    total_permits = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Permits: {total_permits}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        permits.extend(data["items"])
        print(f"✅ Page 1 retrieved with {len(data['items'])} permits.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        response = requests.get(
            f"{base_url}&page={page}&per-page={PER_PAGE}",
            headers=headers
        )

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                permits.extend(data["items"])
                print(f"✅ Page {page} retrieved with {len(data['items'])} permits.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file
    filename_suffix = f"_owner_{owner_filter}" if owner_filter else ""
    filename = f"{map_project_id}_permits{filename_suffix}.json"
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(permits, json_file, indent=4)

    filter_info = f" (filtered by owner: {owner_filter})" if owner_filter else ""
    print(f"\n✅ Successfully saved {len(permits)} permits{filter_info} to `{filename}`.")

def get_single_permit(permit_id, access_token):
    """Fetch a single permit by its ID"""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Try different endpoint patterns since the API seems inconsistent
    endpoints_to_try = [
        f"{API_URL}/map-permit/{permit_id}",
        f"{API_URL}/map-permits/{permit_id}",
        f"{API_URL}/map-permit?filter[id]={permit_id}",
        f"{API_URL}/map-permits?filter[id]={permit_id}",
    ]
    
    for endpoint in endpoints_to_try:
        print(f"🔍 Trying endpoint: {endpoint}")
        response = requests.get(endpoint, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            # Handle both single object and array responses
            if isinstance(data, dict):
                if 'items' in data and len(data['items']) > 0:
                    # It's a paginated response
                    print(f"✅ Found permit in paginated response")
                    print(json.dumps(data['items'][0], indent=2))
                    return data['items'][0]
                elif 'id' in data:
                    # It's a single permit object
                    print(f"✅ Found permit as single object")
                    print(json.dumps(data, indent=2))
                    return data
            break
        else:
            print(f"⚠️  Status {response.status_code}: {response.text}")
    
    print("❌ Could not retrieve permit from any endpoint")
    return None

# Bonus: Test the expand=tags functionality mentioned in the documentation
def get_permit_with_tags(permit_id, access_token):
    """Fetch a single permit with expanded tags"""
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(
        f"{API_URL}/map-permit/{permit_id}?expand=tags",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve permit with tags. Status: {response.status_code}, Response: {response.text}")
        return None

    print("🏷️ Permit with expanded tags:")
    print(json.dumps(response.json(), indent=2))
    return response.json()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Retrieve permits from Verofy API")
    parser.add_argument("map_project_id", nargs="?", help="Map Project ID to retrieve permits for")
    parser.add_argument("--permit", help="Get a single permit by ID")
    parser.add_argument("--permit-tags", help="Get a single permit with expanded tags by ID")
    parser.add_argument("--owner", help="Filter permits by owner name")
    
    args = parser.parse_args()

    # Validate arguments
    if not args.permit and not args.permit_tags and not args.map_project_id:
        print("❌ Usage:")
        print("  Get all permits: python get_permits.py <MAP_PROJECT_ID> [--owner <OWNER_NAME>]")
        print("  Get single permit: python get_permits.py --permit <PERMIT_ID>")
        print("  Get permit with tags: python get_permits.py --permit-tags <PERMIT_ID>")
        print("\nExamples:")
        print("  python get_permits.py 123")
        print("  python get_permits.py 123 --owner 'John Doe'")
        print("  python get_permits.py --permit 456")
        print("  python get_permits.py --permit-tags 456")
        exit(1)

    access_token = get_access_token()
    if not access_token:
        exit(1)

    if args.permit:
        # Get single permit
        get_single_permit(args.permit, access_token)
    elif args.permit_tags:
        # Get single permit with expanded tags
        get_permit_with_tags(args.permit_tags, access_token)
    else:
        # Get all permits for map project (optionally filtered by owner)
        if args.owner:
            print(f"🔍 Filtering permits by owner: '{args.owner}'")
        list_permits(args.map_project_id, access_token, args.owner)