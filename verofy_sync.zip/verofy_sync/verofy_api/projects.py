import requests
import json
import os
import sys
from pathlib import Path

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 100  # Adjust this value to control page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

def get_access_token():
    """Get a new access token using login credentials"""
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)
        
        if token_response.status_code == 200:
            #print("✅ Access Token Retrieved Successfully!")
            return token_response.json().get("access-token")
            
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    return None

def list_map_projects(access_token):
    """Fetch and display all map projects"""
    headers = {"Authorization": f"Bearer {access_token}"}
    page = 1
    total_projects = 0
    all_projects = []
    while True:
        response = requests.get(
            f"{API_URL}/map-projects?page={page}&per-page={PER_PAGE}",
            headers=headers
        )
        
        if response.status_code != 200:
            print(f"❌ Failed to retrieve projects. Status: {response.status_code}")
            break
            
        data = response.json()
        projects = data.get("items", [])
        
        if not projects:
            break
        all_projects.extend(projects)   
        # Print each project's details
        for project in projects:
            continue
            print("\n-----------------------------------")
            print(f"📍 Project ID: {project.get('id')}")
            print(f"📝 Name: {project.get('name')}")
            print(f"📊 Status: {project.get('statusId')}")
            print(f"📅 Created: {project.get('createdDate')}")
            if project.get('description'):
                print(f"📄 Description: {project.get('description')}")
        
        total_projects += len(projects)
        
        # Check if there are more pages
        meta = data.get("_meta", {})
        if page >= meta.get("pageCount", page):
            break
            
        page += 1
    
    #print(f"\n✅ Total Projects Found: {total_projects}")
    print(json.dumps(all_projects))

if __name__ == "__main__":
    access_token = get_access_token()
    if access_token:
        list_map_projects(access_token)
