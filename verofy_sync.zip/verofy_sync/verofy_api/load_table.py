import os
import json
import sys
from dotenv import load_dotenv
import psycopg2
from psycopg2 import Error

def get_field_value(record, field_name):
    """Get field value using case-insensitive matching"""
    # Direct match first
    if field_name in record:
        return record[field_name]
    
    # Try case-insensitive match
    field_lower = field_name.lower()
    for k in record:
        if k.lower() == field_lower:
            return record[k]
    return None

def convert_value(val, col_type):
    """Convert value to appropriate Python type"""
    if val is None:
        return None
        
    try:
        if col_type == 'integer' and isinstance(val, int):
            return val
        elif col_type == 'numeric' and isinstance(val, (int, float)):
            return val
        elif col_type in ('text', 'character varying'):
            # Handle complex data types (lists, dicts) by converting to JSON
            if isinstance(val, (list, dict)):
                return json.dumps(val)
            return str(val) if val is not None else None
        return val
    except (ValueError, TypeError) as e:
        print(f"⚠️ Could not convert '{val}' to {col_type}: {str(e)}")
        return None

def load_table(table_name, json_file):
    # Load environment variables
    load_dotenv()

    # Initialize connection as None
    conn = None
    cur = None

    try:
        # Database connection parameters
        db_params = {
            "host": os.getenv("POSTGRES_HOST"),
            "port": int(os.getenv("POSTGRES_PORT", 5432)),
            "database": os.getenv("POSTGRES_DB"),
            "user": os.getenv("POSTGRES_USER"),
            "password": os.getenv("POSTGRES_PASSWORD")
        }

        # Validate connection parameters
        missing_params = [k for k, v in db_params.items() if not v]
        if missing_params:
            raise ValueError(f"Missing required database parameters: {', '.join(missing_params)}")

        # Load and validate JSON file
        print(f"📄 Reading JSON file: {json_file}")
        with open(json_file, 'r') as f:
            data = json.load(f)
            
        if not data or not isinstance(data, list) or len(data) == 0:
            raise ValueError("JSON file must contain at least one object")

        # Connect to database
        print("📡 Connecting to PostgreSQL database...")
        conn = psycopg2.connect(**db_params)
        cur = conn.cursor()

        # Get table columns with their data types (excluding gid and geom)
        cur.execute(f"""
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_schema = 'verofy' 
            AND table_name = %s 
            AND column_name NOT IN ('gid', 'geom')
        """, (table_name,))
        columns = cur.fetchall()
        column_names = [col[0] for col in columns]
        column_types = {col[0]: col[1] for col in columns}

        # Check if table has geometry and get its type
        cur.execute("""
            SELECT type 
            FROM geometry_columns 
            WHERE f_table_schema = 'verofy' 
            AND f_table_name = %s
        """, (table_name,))
        geom_result = cur.fetchone()
        geom_type = geom_result[0].upper() if geom_result else None

        # Prepare insert statement
        fields = ', '.join(column_names)
        values_template = ', '.join(['%s'] * len(column_names))
        
        if geom_type:
            fields += ', geom'
            values_template += ", ST_SetSRID(ST_GeomFromText(%s), 4326)"

        insert_sql = f"""
            INSERT INTO verofy.{table_name} ({fields})
            VALUES ({values_template})
        """

        print(f"\n🔄 Loading data into '{table_name}'...")
        records_processed = 0
        records_with_geom = 0

        # Process each record
        for record in data:
            # Prepare values for regular columns
            values = []
            for col in column_names:
                val = get_field_value(record, col)
                converted_val = convert_value(val, column_types[col])
                values.append(converted_val)

            # Handle geometry if present - use poly data for LINESTRING
            if geom_type:
                if geom_type == 'LINESTRING':
                    # Use poly data for linestring
                    poly_data = get_field_value(record, 'poly')
                    if poly_data and isinstance(poly_data, list) and len(poly_data) >= 2:
                        try:
                            coords = []
                            for point in poly_data:
                                if 'lng' in point and 'lat' in point:
                                    coords.append(f"{point['lng']} {point['lat']}")
                            if coords:
                                wkt = f"LINESTRING({', '.join(coords)})"
                                values.append(wkt)
                                records_with_geom += 1
                            else:
                                values.append(None)
                        except Exception as e:
                            print(f"⚠️ Error creating linestring for record {records_processed + 1}: {str(e)}")
                            values.append(None)
                    else:
                        values.append(None)
                elif geom_type == 'POINT':
                    # Use longitude/latitude for points
                    lon_str = get_field_value(record, 'longitude')
                    lat_str = get_field_value(record, 'latitude')
                    
                    if lon_str is not None and lat_str is not None:
                        try:
                            lon = float(str(lon_str))
                            lat = float(str(lat_str))
                            if -180 <= lon <= 180 and -90 <= lat <= 90:
                                wkt = f"POINT({lon} {lat})"
                                values.append(wkt)
                                records_with_geom += 1
                            else:
                                values.append(None)
                        except (ValueError, TypeError):
                            values.append(None)
                    else:
                        values.append(None)

            try:
                cur.execute(insert_sql, values)
                records_processed += 1
                if records_processed % 100 == 0:
                    print(f"✓ Processed {records_processed} records ({records_with_geom} with geometry)...")
                    conn.commit()
            except Exception as e:
                print(f"⚠️ Error processing record {records_processed + 1}: {str(e)}")
                continue

        # Final commit and summary
        conn.commit()
        print(f"\n✅ Successfully loaded {records_processed} records!")
        print(f"   Records with geometry: {records_with_geom}")

    except ValueError as ve:
        print(f"❌ Configuration error: {ve}")
    except json.JSONDecodeError as je:
        print(f"❌ JSON parsing error: {je}")
    except (Exception, Error) as error:
        print(f"❌ Error while working with PostgreSQL: {error}")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()
            print("🔌 Database connection closed.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("❌ Usage: python load_table.py <table_name> <json_file>")
        sys.exit(1)
    
    table_name = sys.argv[1]
    json_file = sys.argv[2]
    load_table(table_name, json_file)