import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Ensure a site ID is provided as a command-line argument
if len(sys.argv) < 2:
    print("❌ Usage: python update_site.py <SITE_ID>")
    exit(1)

SITE_ID = sys.argv[1]  # Get site ID from CLI argument

# Step 1: Get a new access token dynamically before updating the site
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Update the site name to "TEST"
def update_site(site_id, access_token):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Define update payload
    update_data = {
        "name": "SEB"  # Setting the site name to 'TEST'
    }

    # Send PATCH request
    response = requests.patch(f"{API_URL}/map-site/update?id={site_id}", headers=headers, json=update_data)

    if response.status_code == 200:
        print("\n✅ Site Updated Successfully!")
        print(json.dumps(response.json(), indent=4))  # Pretty-print response
    else:
        print(f"❌ Failed to update site. Status: {response.status_code}, Response: {response.text}")

# Run the process
if __name__ == "__main__":
    access_token = get_access_token()
    if access_token:
        update_site(SITE_ID, access_token)