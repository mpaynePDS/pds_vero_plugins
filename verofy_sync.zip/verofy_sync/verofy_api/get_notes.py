import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust this value to increase/decrease page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL notes for a specific map project, handling pagination efficiently
def list_notes(map_project_id, access_token):
    headers = {"Authorization": f"Bearer {access_token}"}
    notes = []
    
    # First request to determine total pages and notes
    response = requests.get(
        f"{API_URL}/map-notes?filter[mapProjectId]={map_project_id}&page=1&per-page={PER_PAGE}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve notes. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total pages & total notes from metadata
    total_notes = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Notes: {total_notes}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        notes.extend(data["items"])
        print(f"✅ Page 1 retrieved with {len(data['items'])} notes.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        response = requests.get(
            f"{API_URL}/map-notes?filter[mapProjectId]={map_project_id}&page={page}&per-page={PER_PAGE}",
            headers=headers
        )

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                notes.extend(data["items"])
                print(f"✅ Page {page} retrieved with {len(data['items'])} notes.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file
    filename = f"{map_project_id}_notes.json"
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(notes, json_file, indent=4)

    print(f"\n✅ Successfully saved {len(notes)} notes to `{filename}`.")

def get_single_note(note_id, access_token):
    """Fetch a single note by its ID"""
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(
        f"{API_URL}/map-note/{note_id}",
        headers=headers
    )

    if response.status_code != 200:
        print(f"❌ Failed to retrieve note. Status: {response.status_code}, Response: {response.text}")
        return None

    # Print formatted JSON to terminal
    print(json.dumps(response.json(), indent=2))
    return response.json()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ Usage:")
        print("  Get all notes: python get_notes.py <MAP_PROJECT_ID>")
        print("  Get single note: python get_notes.py --note <NOTE_ID>")
        exit(1)

    access_token = get_access_token()
    if not access_token:
        exit(1)

    if sys.argv[1] == "--note" and len(sys.argv) == 3:
        # Get single note
        get_single_note(sys.argv[2], access_token)
    else:
        # Get all notes for map project
        list_notes(sys.argv[1], access_token)