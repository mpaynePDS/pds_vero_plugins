import requests
import json
import os
import sys
import argparse

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"

def parse_arguments():
    parser = argparse.ArgumentParser(description='Create a pole on a map')
    parser.add_argument('--map_id', required=True, help='Map Project ID where the pole will be created')
    parser.add_argument('--latitude', required=True, type=float, help='Pole latitude')
    parser.add_argument('--longitude', required=True, type=float, help='Pole longitude')
    parser.add_argument('--name', default='New Pole', help='Name for the pole')
    return parser.parse_args()

def get_access_token():
    # Read credentials from environment variables
    EMAIL = os.getenv("VEROFY_USER")
    PASSWORD = os.getenv("VEROFY_PASS")

    if not EMAIL or not PASSWORD:
        print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
        sys.exit(1)

    # Get refresh token
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}")
    sys.exit(1)

def create_pole(access_token, args):
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Restructured pole data to match create_site.py pattern
    pole_data = {
        "mapProjectId": int(args.map_id),
        "name": args.name,
        "latitude": str(args.latitude),
        "longitude": str(args.longitude),
        "mrStateId": 8
    }

    # Create pole using POST request
    response = requests.post(
        f"{API_URL}/map-pole/create",
        headers=headers,
        json=pole_data
    )

    if response.status_code == 201:
        print("✅ Pole created successfully!")
        print(json.dumps(response.json(), indent=2))
        return response.json()
    else:
        print(f"❌ Failed to create pole! Status: {response.status_code}")
        print(f"Response: {response.text}")
        sys.exit(1)

def main():
    args = parse_arguments()
    access_token = get_access_token()
    created_pole = create_pole(access_token, args)

if __name__ == "__main__":
    main()