import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust this value to increase/decrease page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL cables for a specific map project, handling pagination efficiently
def list_cables(map_project_id, access_token, expand_segments=False):
    """Fetch ALL cables for a specific map project, with optional segment expansion"""
    headers = {"Authorization": f"Bearer {access_token}"}
    cables = []
    
    # Build URL with optional expand parameter
    url = f"{API_URL}/map-cables?filter[mapProjectId]={map_project_id}&page=1&per-page={PER_PAGE}"
    if expand_segments:
        url += "&expand=segments"
        print(f"🔗 Expanding segments for all cables in project {map_project_id}")
    
    # First request to determine total pages and cables
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"❌ Failed to retrieve cables. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total pages & total cables from metadata
    total_cables = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Cables: {total_cables}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        cables.extend(data["items"])
        if expand_segments:
            segments_count = sum(len(cable.get('segments', [])) for cable in data["items"])
            print(f"✅ Page 1 retrieved with {len(data['items'])} cables and {segments_count} total segments.")
        else:
            print(f"✅ Page 1 retrieved with {len(data['items'])} cables.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        page_url = f"{API_URL}/map-cables?filter[mapProjectId]={map_project_id}&page={page}&per-page={PER_PAGE}"
        if expand_segments:
            page_url += "&expand=segments"
            
        response = requests.get(page_url, headers=headers)

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                cables.extend(data["items"])
                if expand_segments:
                    segments_count = sum(len(cable.get('segments', [])) for cable in data["items"])
                    print(f"✅ Page {page} retrieved with {len(data['items'])} cables and {segments_count} total segments.")
                else:
                    print(f"✅ Page {page} retrieved with {len(data['items'])} cables.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file with appropriate filename
    if expand_segments:
        filename = f"{map_project_id}_cables_with_segments.json"
        total_segments = sum(len(cable.get('segments', [])) for cable in cables)
        print(f"\n✅ Successfully saved {len(cables)} cables with {total_segments} total segments to `{filename}`.")
    else:
        filename = f"{map_project_id}_cables.json"
        print(f"\n✅ Successfully saved {len(cables)} cables to `{filename}`.")
    
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(cables, json_file, indent=4)

def get_single_cable(cable_id, access_token, expand_segments=False):
    """Fetch a single cable by its ID, optionally with expanded segments"""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Build URL with optional expand parameter
    url = f"{API_URL}/map-cable/{cable_id}"
    if expand_segments:
        url += "?expand=segments"
        print(f"🔗 Expanding segments for cable {cable_id}")
    
    response = requests.get(url, headers=headers)
    
    # If direct endpoint fails, try collection filter
    if response.status_code == 404:
        print("🔄 Direct endpoint not found, trying collection filter...")
        url = f"{API_URL}/map-cables?filter[id]={cable_id}"
        if expand_segments:
            url += "&expand=segments"
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                cable_data = data["items"][0]
                if expand_segments and "segments" in cable_data:
                    print(f"✅ Cable retrieved with {len(cable_data['segments'])} segments")
                print(json.dumps(cable_data, indent=2))
                return cable_data
            else:
                print(f"❌ Cable with ID {cable_id} not found")
                return None

    if response.status_code != 200:
        print(f"❌ Failed to retrieve cable. Status: {response.status_code}, Response: {response.text}")
        return None

    cable_data = response.json()
    if expand_segments and "segments" in cable_data:
        print(f"✅ Cable retrieved with {len(cable_data['segments'])} segments")
    print(json.dumps(cable_data, indent=2))
    return cable_data

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ Usage:")
        print("  Get all cables: python get_cables.py <MAP_PROJECT_ID>")
        print("  Get all cables with segments: python get_cables.py <MAP_PROJECT_ID> --with-segments")
        print("  Get single cable: python get_cables.py --cable <CABLE_ID>")
        print("  Get single cable with segments: python get_cables.py --cable-segments <CABLE_ID>")
        exit(1)

    access_token = get_access_token()
    if not access_token:
        exit(1)

    if sys.argv[1] == "--cable" and len(sys.argv) == 3:
        # Get single cable without segments
        get_single_cable(sys.argv[2], access_token, expand_segments=False)
    elif sys.argv[1] == "--cable-segments" and len(sys.argv) == 3:
        # Get single cable with expanded segments
        get_single_cable(sys.argv[2], access_token, expand_segments=True)
    elif len(sys.argv) == 3 and sys.argv[2] == "--with-segments":
        # Get all cables for map project with segments
        list_cables(sys.argv[1], access_token, expand_segments=True)
    else:
        # Get all cables for map project without segments
        list_cables(sys.argv[1], access_token, expand_segments=False)
