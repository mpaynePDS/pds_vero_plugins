import requests
import json
import os
import sys

# API Configuration
API_URL = "https://api.verofy.veronetworks.com/v1"
PER_PAGE = 1000  # Adjust this value to increase/decrease page size

# Read credentials from environment variables
EMAIL = os.getenv("VEROFY_USER")
PASSWORD = os.getenv("VEROFY_PASS")

if not EMAIL or not PASSWORD:
    print("❌ Missing environment variables: Please set VEROFY_USER and VEROFY_PASS")
    exit(1)

# Step 1: Get a new access token dynamically before fetching data
def get_access_token():
    payload = {"email": EMAIL, "password": PASSWORD}
    response = requests.post(f"{API_URL}/login", json=payload)
    
    if response.status_code == 200:
        refresh_token = response.json().get("refresh-token")
        headers = {"Authorization": f"Bearer {refresh_token}"}
        token_response = requests.get(f"{API_URL}/refresh-token", headers=headers)

        if token_response.status_code == 200:
            access_token = token_response.json().get("access-token")
            if access_token:
                print("✅ Access Token Retrieved Successfully!")
                return access_token
    print(f"❌ Failed to retrieve access token! Status: {response.status_code}, Response: {response.text}")
    return None

# Step 2: Fetch ALL sites for a specific map project, handling pagination efficiently
def list_sites(map_project_id, access_token, expand_tags=False):
    """Fetch ALL sites for a specific map project, with optional tag expansion"""
    headers = {"Authorization": f"Bearer {access_token}"}
    sites = []
    
    # Build URL with optional expand parameter
    url = f"{API_URL}/map-sites?filter[mapProjectId]={map_project_id}&page=1&per-page={PER_PAGE}"
    if expand_tags:
        url += "&expand=tags"
        print(f"🏷️  Expanding tags for all sites in project {map_project_id}")
    
    # First request to determine total pages and sites
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"❌ Failed to retrieve sites. Status: {response.status_code}, Response: {response.text}")
        return

    data = response.json()

    # Extract total pages & total sites from metadata
    total_sites = data["_meta"]["totalCount"] if "_meta" in data and "totalCount" in data["_meta"] else "?"
    total_pages = data["_meta"]["pageCount"] if "_meta" in data and "pageCount" in data["_meta"] else 1

    print(f"📊 Total Sites: {total_sites}, Total Pages: {total_pages} (Page Size: {PER_PAGE})")

    # Collect first page data
    if "items" in data and len(data["items"]) > 0:
        sites.extend(data["items"])
        if expand_tags:
            tags_count = sum(len(site.get('tags', [])) for site in data["items"])
            print(f"✅ Page 1 retrieved with {len(data['items'])} sites and {tags_count} total tags.")
        else:
            print(f"✅ Page 1 retrieved with {len(data['items'])} sites.")

    # Fetch remaining pages (if any)
    for page in range(2, total_pages + 1):
        page_url = f"{API_URL}/map-sites?filter[mapProjectId]={map_project_id}&page={page}&per-page={PER_PAGE}"
        if expand_tags:
            page_url += "&expand=tags"
            
        response = requests.get(page_url, headers=headers)

        if response.status_code == 200:
            data = response.json()
            if "items" in data and len(data["items"]) > 0:
                sites.extend(data["items"])
                if expand_tags:
                    tags_count = sum(len(site.get('tags', [])) for site in data["items"])
                    print(f"✅ Page {page} retrieved with {len(data['items'])} sites and {tags_count} total tags.")
                else:
                    print(f"✅ Page {page} retrieved with {len(data['items'])} sites.")
        else:
            print(f"❌ Failed to retrieve page {page}. Status: {response.status_code}, Response: {response.text}")
            break

    # Save to JSON file with appropriate filename
    if expand_tags:
        filename = f"{map_project_id}_sites_with_tags.json"
        total_tags = sum(len(site.get('tags', [])) for site in sites)
        print(f"\n✅ Successfully saved {len(sites)} sites with {total_tags} total tags to `{filename}`.")
    else:
        filename = f"{map_project_id}_sites.json"
        print(f"\n✅ Successfully saved {len(sites)} sites to `{filename}`.")
    
    with open(filename, "w", encoding="utf-8") as json_file:
        json.dump(sites, json_file, indent=4)

def get_single_site(site_id, access_token, expand_tags=False):
    """Fetch a single site by its ID, optionally with expanded tags"""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Build URL with optional expand parameter
    url = f"{API_URL}/map-sites?filter[id]={site_id}"
    if expand_tags:
        url += "&expand=tags"
        print(f"🏷️  Expanding tags for site {site_id}")
    
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        print(f"❌ Failed to retrieve site. Status: {response.status_code}, Response: {response.text}")
        return None

    data = response.json()
    if "items" in data and len(data["items"]) > 0:
        site_data = data["items"][0]
        if expand_tags and "tags" in site_data:
            print(f"✅ Site retrieved with {len(site_data['tags'])} tags")
        print(json.dumps(site_data, indent=2))
        return site_data
    else:
        print(f"❌ Site with ID {site_id} not found")
        return None

def get_single_site_direct(site_id, access_token, expand_tags=False):
    """Try to fetch a single site using direct endpoint (singular form)"""
    headers = {"Authorization": f"Bearer {access_token}"}
    
    # Build URL with optional expand parameter
    url = f"{API_URL}/map-site/{site_id}"
    if expand_tags:
        url += "?expand=tags"
        print(f"🏷️  Expanding tags for site {site_id}")
    
    response = requests.get(url, headers=headers)

    if response.status_code == 404:
        print("🔄 Direct endpoint not found, trying collection filter...")
        return get_single_site(site_id, access_token, expand_tags)
    
    if response.status_code != 200:
        print(f"❌ Failed to retrieve site. Status: {response.status_code}, Response: {response.text}")
        return None

    site_data = response.json()
    if expand_tags and "tags" in site_data:
        print(f"✅ Site retrieved with {len(site_data['tags'])} tags")
    print(json.dumps(site_data, indent=2))
    return site_data

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ Usage:")
        print("  Get all sites: python get_sites.py <MAP_PROJECT_ID>")
        print("  Get all sites with tags: python get_sites.py <MAP_PROJECT_ID> --with-tags")
        print("  Get single site: python get_sites.py --site <SITE_ID>")
        print("  Get single site with tags: python get_sites.py --site-tags <SITE_ID>")
        exit(1)

    access_token = get_access_token()
    if not access_token:
        exit(1)

    if sys.argv[1] == "--site" and len(sys.argv) == 3:
        # Get single site without tags
        get_single_site_direct(sys.argv[2], access_token, expand_tags=False)
    elif sys.argv[1] == "--site-tags" and len(sys.argv) == 3:
        # Get single site with expanded tags
        get_single_site_direct(sys.argv[2], access_token, expand_tags=True)
    elif len(sys.argv) == 3 and sys.argv[2] == "--with-tags":
        # Get all sites for map project with tags
        list_sites(sys.argv[1], access_token, expand_tags=True)
    else:
        # Get all sites for map project without tags
        list_sites(sys.argv[1], access_token, expand_tags=False)
