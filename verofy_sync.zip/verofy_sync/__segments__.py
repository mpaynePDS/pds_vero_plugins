# -*- coding: utf-8 -*-
"""
Created on Monday, August 25, 2025
Vero QC LLD
@author: Marie Payne
"""

import sys
import os
import re

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea, QgsCoordinateTransform
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime
import psycopg2
import psycopg2.extras

from .json_to_geojson import json_to_geojson
from . import globals_module
import subprocess
import json
class Segments:
        global  config, python_exe, parent_dir, CREATE_NO_WINDOW

        config = globals_module.config
        python_exe = globals_module.python_exe
        parent_dir = globals_module.parent_dir
        CREATE_NO_WINDOW = globals_module.CREATE_NO_WINDOW

  
        def _upload_(dbox, map_id, schema_name, selectionType, segment_id, lyr): #create
            conn = psycopg2.connect(**config)
            curr = conn.cursor()
            if selectionType == 'zone':
                query = f"""
                SELECT f.uuid, f.segment_type, f.segment_status, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.segments f
                WHERE
                    ST_Within(f.geom, (SELECT ST_Union(p.geom) FROM {schema_name}.cabinet_boundary p where p.segment_id in ('{segment_id}') ));
                """
            elif selectionType == 'map':
                query = f"""
                SELECT f.uuid, f.segment_type,f.segment_status, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.segments f;
                """
            elif selectionType == 'selected':
                uuid_list = [f["uuid"] for f in lyr.getSelectedFeatures()]
                if not uuid_list:
                    raise ValueError("No UUIDs selected")
                uuid_str = ', '.join(f"'{uuid}'" for uuid in uuid_list)
                query = f"""
                    SELECT f.uuid, f.segment_type, f.segment_status, ST_AsGeoJSON(ST_Transform(f.geom, 4326)) AS geometry
                    FROM {schema_name}.segments f
                    WHERE f.uuid IN ({uuid_str});
                """
            
            curr.execute(query)
            
            for row in curr.fetchall():
                geojson = json.loads(row[3])
                coords = geojson.get("coordinates", [])
                poly = [{"lat": round(lat, 15), "lng": round(lng, 15)} for lng, lat in coords]

                dbox.append(str(poly))
                dbox.append(f'{parent_dir}\\verofy_api\\create_segment.py')
                result = subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\create_segment.py',
                '--map_id', str(map_id),
                '--name', '',  #segments ID
                '--type_id', str(5)  if row[1] == 9 else str(3) if row[1] == 2 else '',
                '--status_id', str(4) if row[2] == 3 else '',
                '--poly_coordinates', json.dumps(poly)],
                capture_output=True, text=True,creationflags=CREATE_NO_WINDOW)

                if result.stdout.strip():
                    dbox.append(result.stdout.strip())
                if result.stderr.strip():
                    dbox.append(result.stderr.strip())

            curr.close()
            conn.close()
            dbox.append('Success! Features uploaded!')
        
        def _download_(dbox, map_id, schema_name, selectionType, segment_id, lyr): #get
            conn = psycopg2.connect(**config)
            curr = conn.cursor()
            dbox.append(selectionType)
            if selectionType == 'zone':
                query = f"""
                SELECT ST_AsText(geom) AS bbox
                FROM {schema_name}.cabinet_boundary
                WHERE segment_id = '{segment_id}';
                """
            elif selectionType == 'map':
                pass
            elif selectionType == 'selected':
                uuid_list = [f["uuid"] for f in lyr.getSelectedFeatures()]
                count_selected = lyr.selectedFeatureCount()
                dbox.append(f'{str(count_selected)} features selected.')
                if not uuid_list:
                    raise ValueError("No UUIDs selected")
                uuid_str = ', '.join(f"'{uuid}'" for uuid in uuid_list)
                query = f"""
                    SELECT ST_AsText(ST_Union(ST_Buffer(geom, 1)))

                    FROM {schema_name}.segments f
                    WHERE f.uuid IN ({uuid_str}) and geom is not null;
                """
            else:
                print('error')


            #"get" retrieves the entire verofy map, there is no way to pre-filter it, "get"returns a .json file
            dbox.append(str(map_id))
            result = subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\get_segments.py',str(map_id)],
                                       capture_output=True, text=True,
                                       creationflags=CREATE_NO_WINDOW)
            # returns json file that gets sent to "Documents", as "map_id"_"layer".json, i.e. "12234_segmentss.json"
            if result.stdout.strip():
                dbox.append(result.stdout)
            file = f'{str(map_id)}_segments.json'
            newfile = json_to_geojson(file)
            layer = QgsVectorLayer(newfile, "verofy_segments", "ogr")
            QgsProject.instance().addMapLayer(layer)
            if not layer.isValid():
                dbox.append("Layer failed to load.")
                return
            elif layer.geometryType() != QgsWkbTypes.LineGeometry:
                dbox.append("Layer loaded, but it's not recognized as a line layer. No segments found on verofy map.")
                return

            if selectionType in ['zone', 'selected']:
                curr.execute(query)
                results = curr.fetchone()
                if results and results[0]:
                    dbox.append(str(results))
                    wkt = results[0]
                    verofy_segments = QgsProject.instance().mapLayersByName('verofy_segments')[0]
                    segments = QgsProject.instance().mapLayersByName('Segments')[0]
                    extent_geom = QgsGeometry.fromWkt(wkt)
                    transform = QgsCoordinateTransform(segments.crs(), verofy_segments.crs(), QgsProject.instance())

                    extent_geom.transform(transform)
                    wkt = extent_geom.asWkt()
                    expression = f"intersects($geometry, geom_from_wkt('{wkt}'))"
                    dbox.append(expression)
                    verofy_segments.selectByExpression(expression, QgsVectorLayer.SetSelection)
                    verofy_segments.invertSelection()
                    verofy_segments.startEditing()
                    for fid in verofy_segments.selectedFeatureIds():
                        verofy_segments.deleteFeature(fid)
                    verofy_segments.commitChanges()
                    count_remaining = verofy_segments.featureCount()
                    dbox.append(f'{str(count_remaining)} matching features found in verofy.')
            

            curr.close()
            conn.close()
            
        def _update_(dbox, map_id, schema_name, selectionType, segment_id, lyr):
            conn = psycopg2.connect(**config)
            curr = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
            if selectionType == 'zone':
                query = f"""
                SELECT f.uuid, f.segment_type, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.segments f
                WHERE
                    ST_Within(f.geom, (SELECT ST_Union(p.geom) FROM {schema_name}.cabinet_boundary p where p.segment_id in ('{segment_id}')));
                """
            elif selectionType == 'map':
                query = f"""
                SELECT f.uuid, f.segment_type, ST_AsGeoJSON(ST_Transform(geom, 4326)) AS geometry
                FROM
                    {schema_name}.segments f;
                """
            elif selectionType == 'selected':
                uuid_list = [f["uuid"] for f in lyr.getSelectedFeatures()]
                if not uuid_list:
                    raise ValueError("No UUIDs selected")
                uuid_str = ', '.join(f"'{uuid}'" for uuid in uuid_list)
                query = f"""
                    SELECT f.uuid, f.segment_type, ST_AsGeoJSON(ST_Transform(f.geom, 4326)) AS geometry
                    FROM {schema_name}.segments f
                    WHERE f.uuid IN ({uuid_str});
                """
            curr.execute(query)

            for index, row in enumerate(curr.fetchall()):               
                geojson = json.loads(row[3])
                coords = geojson.get("coordinates", [])
                poly = [{"lat": round(lat, 15), "lng": round(lng, 15)} for lng, lat in coords]

                result = subprocess.run([python_exe, f'{parent_dir}\\verofy_api\\update_segments.py',
                '--segment_id', '1073335', #need to build 
                '--name', '',
                '--type_id', str(5)  if row[1] == 9 else str(3) if row[1] == 2 else '',
                #'--fiber_count', '',
                #'--fibers_utilized', '',
                #'--conduit', '',
                #'--construction_method_id', '',
                #'--cable_override', '',
                #'--segment_protection_status_id', '',
                '--poly', json.dumps(poly)],
                capture_output=True, text=True,creationflags=CREATE_NO_WINDOW)

                if result.stdout.strip():
                    dbox.append(result.stdout.strip())
                if result.stderr.strip():
                    dbox.append(result.stderr.strip())
            curr.close()
            conn.close()
            dbox.append('Success! Features updated!')