import os
import psycopg2
os.environ['VEROFY_USER'] = 'mpayne@precision-design.org'
os.environ['VEROFY_PASS'] = 'verofy_fish'
config = {
        "dbname":"vero",
        "user":"mpayne",
        "password":"fBh5NULkPZkiOnG6",
        "host":"gis.precision-design.org",
        "port":"51549"}
'''psycopg2.connect(
        dbname="vero",
        user="mpayne",
        password="fBh5NULkPZkiOnG6",
        host="gis.precision-design.org",  # e.g., "localhost" or an IP
        port="51549"                # default PostgreSQL port
        )'''
current_file = os.path.abspath(__file__)
parent_dir = os.path.dirname(current_file)
python_exe = f'{parent_dir}\\verofy_api\\.venv\\Scripts\\python.exe'

CREATE_NO_WINDOW = 0x08000000