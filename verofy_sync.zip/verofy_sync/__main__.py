# -*- coding: utf-8 -*-
"""
Created on Monday, August 25, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea, QgsCoordinateTransform
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime
import psycopg2
import psycopg2.extras

from .json_to_geojson import json_to_geojson
from . import globals_module
from .__pole__ import Pole
from .__segments__ import Segments
from.__unfielded_pole__ import UnfieldedPole
import subprocess
import json
import os
import re



def __main__(dbox,layer, map_name, selectionType, segment_id, opsType):
    try:
        map_id = int(map_name.split(" -+-")[0].strip())
        dbox.append(str(map_id))
    except ValueError:
        raise("Map ID not a valid integer.")
    dbox.append(str(QgsProject.instance()))
    lyr = QgsProject.instance().mapLayersByName(layer)[0]
    source_string = lyr.source()
    dbox.append(source_string)
    match = re.search(r'table="?(\w+)"?\."?(\w+)"?', source_string)
    if match:
        schema_name = match.group(1).strip('"').strip("'")
        dbox.append(schema_name)
    else:
        dbox.append("Database name not found in layer source.")


    if layer == 'Pole':
        dbox.append(opsType)
        if opsType == 'upload':
            Pole._upload_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
        elif opsType == 'download':
            Pole._download_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
        elif opsType == 'update':
            Pole._update_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
    
    if layer == 'Unfielded_Pole':
        dbox.append(opsType)
        if opsType == 'upload':
            UnfieldedPole._upload_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
        elif opsType == 'download':
            UnfieldedPole._download_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
        elif opsType == 'update':
            UnfieldedPole._update_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
    
    if layer == 'Segments':
        dbox.append(opsType)
        if opsType == 'upload':
            Segments._upload_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
        elif opsType == 'download':
            Segments._download_(dbox, map_id, schema_name, selectionType, segment_id, lyr)
        elif opsType == 'update':
            Segments._update_(dbox, map_id, schema_name, selectionType, segment_id, lyr)