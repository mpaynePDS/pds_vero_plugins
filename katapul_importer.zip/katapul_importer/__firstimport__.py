# -*- coding: utf-8 -*-
"""
Created on Friday, March 2025
Katapult Importer
@author: Marie Payne

Description:
- After exporting 'AGOL Data' & 'Node' reports from Katapult as excel from zip
- Join to the Pole layer in the Vero project using 'UID' fields
- copy over the data to the 'real' fields
- unjoin
"""
import os
from openpyxl import load_workbook
from datetime import datetime
import pandas as pd
import numpy as np
from zipfile import ZipFile
import sys
import time
from qgis.core import *
from qgis.PyQt.QtCore import QVariant
from qgis import processing
from datetime import datetime
def __firstimport__(inputfiles, dbox, progressBar,errorFormat, warningFormat, validFormat):
    try:
        progressBar.setValue(5)
        project = QgsProject.instance()
        poles = project.mapLayersByName('Pole')[0]
        pole_node_list = [] #list of node_ids in layer
        for p in poles.getFeatures():
            if p['node_id'] not in [None, '']:
                pole_node_list.append(p['node_id'])
        dbox.append(str(inputfiles))
        dir = os.path.dirname(inputfiles[0])
        agol_cols = ['class', 'height', 'number_of_attachments', 'pole_number_power', 'pole_owner', 'riser_count',
                    'stub_pole_transfer', 'tree_trim', 'low_power_attachment', 'node_id',
                    'attachment_a_owner', 'attachment_a_existing', 'attachment_a_proposed',
                    'attachment_b_owner', 'attachment_b_existing', 'attachment_b_proposed',
                    'attachment_c_owner', 'attachment_c_existing', 'attachment_c_proposed',
                    'attachment_d_owner', 'attachment_d_existing', 'attachment_d_proposed',
                    'attachment_e_owner', 'attachment_e_existing', 'attachment_e_proposed',
                    'attachment_f_owner', 'attachment_f_existing', 'attachment_f_proposed',
                    'attachment_g_owner', 'attachment_g_existing', 'attachment_g_proposed',
                    'attachment_h_owner', 'attachment_h_existing', 'attachment_h_proposed',
                    'attachment_i_owner', 'attachment_i_existing', 'attachment_i_proposed',
                    'attachment_j_owner', 'attachment_j_existing', 'attachment_j_proposed',
                    ]
        agol_db = pd.DataFrame(columns=agol_cols)
        node_cols = ['node_id',  'internal_note','latitude', 'longitude', 'make_ready_type', 'initial_make_ready_type']
        node_db = pd.DataFrame(columns=node_cols) #latitude, longitude, pole number
        segment_cols = ['conntype', 'length']
        segment_db = pd.DataFrame(columns = segment_cols)
        # open the zip file
        conns = []
        row_node = []
        element_node = []
        for zip in inputfiles:
            with ZipFile(zip, 'r') as zObject:
                zObject.extractall(dir)
                li = zObject.namelist()
                agol = None
                node = None
                
                for l in li:
                    if 'AGOL' in l:
                        agol = l
                    if 'Node Attributes' in l:
                        node = l
                    if all(x in l for x in ['Connections', '.shp']) and all(x not in l for x in ['down', 'ATT', 'AT&T', 'PLA']):
                    #if 'Connections' in l and '.shp' in l and 'down' not in l: #all line types except down guy.
                        conns.append(f'{dir}\\{l}')
                    if all(x in l for x in ['Nodes', '.shp']) and all(x not in l for x in ['ATT', 'AT&T','PLA', 'pole', 'reference', 'unknown', 'anchor', 'Address']): 
                        row_node.append(f'{dir}\\{l}')
                    if all(x in l for x in ['Nodes', 'anchor', '.shp']) and all(x not in l for x in ['ATT', 'AT&T','PLA', 'pole', 'reference', 'unknown', 'existing anchor']): 
                         element_node.append(f'{dir}\\{l}')
            if agol is not None:
                df = pd.read_excel(f'{dir}\\{agol}', sheet_name="Poles")
                df.columns= df.columns.str.lower().str.replace(' ', '_', regex=False)
                #df= df.drop(['infinium_id', 'fireworks_project_number'], axis = 1)
                nf = df[df['node_id'].isin(pole_node_list)]
                if len(nf)>0:
                    dbox.append(errorFormat.format(f'{len(nf)} node_ids already match exisitng features. These features will be excluded.'))
                if 'pole_owner' not in df.columns.to_list():
                    dbox.append(errorFormat.format('AGOL Table missing "Pole Owner", overwriting with NULL values.'))
                    df['pole_owner'] = None
                if all(i not in agol for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                    df = df[(df['pole_owner'] != 'ATT') & (~df['node_id'].isin(pole_node_list))]
                else:
                    df = df[(df['pole_owner'] == 'ATT') & (~df['node_id'].isin(pole_node_list))]
                #agol_db = pd.concat([agol_db, df], join='inner')
                agol_zdb = df[[col for col in agol_cols if col in df.columns]]
                agol_db = pd.concat([agol_db, agol_zdb], axis=0).reset_index(drop=True)


                
                df = pd.read_excel(f'{dir}\\{node}')
                df.columns = df.columns.str.lower().str.replace(' ', '_', regex=False)
                if 'pole_owner' not in df.columns.to_list():
                    dbox.append(errorFormat.format('Node Table missing "Pole Owner", overwriting with NULL values.'))
                    df['pole_owner'] = None
                if all(i not in node for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                    df = df[(df['pole_owner'] != 'ATT')]
                else:
                    df = df[(df['pole_owner'] == 'ATT')]
                df = df[(df['node_type'] == 'pole')]
                #node_db = pd.concat([node_db, df],join='inner')
                node_zdb = df[[col for col in node_cols if col in df.columns]]
                node_db = pd.concat([node_db, node_zdb], axis = 0).reset_index(drop=True)
                zObject.close() 
        progressBar.setValue(10)
  
        '''
        Some areas are Underground only and will have no poles, so the AGOL pole table will be blank. DFNF table will be len 0.
        '''
        no_poles = None
        if len(agol_db)>0:
            no_poles = False
            #agol_db['mre_grade'] =agol_db['mre_grade'].fillna('')
            #agol_db['mre_grade'] = agol_db['mre_grade'].apply(lambda x: 'Simple MR' if 'Communications' in x else 'Power MR' if 'Light Power' in x else 'Pole Replacement' if 'Heavy Power' in x else 'No MR' if 'No Make Ready' in x else x)
            agol_db['stub_pole_transfer'] = agol_db['stub_pole_transfer'].fillna('false')

            try:
                columns_to_convert =  ['attachment_a_existing', 'attachment_a_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_b_existing', 'attachment_b_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_c_existing', 'attachment_c_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_d_existing', 'attachment_d_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_e_existing', 'attachment_e_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_f_existing', 'attachment_f_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_g_existing', 'attachment_g_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_h_existing', 'attachment_h_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_i_existing', 'attachment_i_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
                columns_to_convert =  ['attachment_j_existing', 'attachment_j_proposed']
                agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)

            except:
                pass
            #dbox.append(str(df['mre_grade']))
            # join node node_id data to agol data using lat/longs
            #nf = pd.read_excel(f'{dir}\\{node}')
            #dbox.append(str(nf.columns.to_list()))
            '''['node_id', 'latitude', 'longitude', 'feedback', 'scid', 'node_type', 'pole_owner', 'oncor_tag', 'done', 'field_completed',\
                'flag_for_review', 'infinium_ID', 'internal_note', 'make_ready_notes', 'make_ready_type', 'mr_state', 'note', 'pole_class',\
                'pole_height', 'pole_owner.1', 'pole_spec', 'verify_location_in_field', 'time_bucket_start', 'time_bucket_stop', 'time_bucket_user',\
                'time_bucket_start_2', 'time_bucket_stop_2', 'time_bucket_user_2', 'time_bucket_start_3', 'time_bucket_stop_3', 'time_bucket_user_3',\
                'photo_count', 'main_photo', 'all_photos']'''
            #dfnf = pd.merge(agol_db, node_db, left_on=['latitude', 'longitude'], right_on = ['latitude', 'longitude'], how='left')
            dfnf = pd.merge(agol_db, node_db,  on='node_id', how='outer')
            dfnf['joined'] = 'True'
            dfnf['initial_make_ready_type'] = dfnf['make_ready_type']
            dfnf['data_source'] = f'Katapult First Import {datetime.now().strftime("%x")}'
            dfnf['height'] = dfnf['height'].astype(str)
            dfnf['class'] = dfnf['class'].astype(str)
            dfnf['riser_count'] = dfnf['riser_count'].astype(str)
            dfnf['tree_trim'] = dfnf['tree_trim'].astype(str)
            dfnf['low_power_attachment'] = dfnf['low_power_attachment'].astype(str)
            dfnf['number_of_attachments'] = dfnf['number_of_attachments'].astype(str)
            for col in agol_cols:
                if col not in dfnf.columns:
                    dfnf[col] = None
            for col in node_cols:
                if col not in dfnf.columns:
                    dfnf[col] = None
            #dfnf['latitude_x'].fillna(dfnf['latitude_y'], inplace=True)
            #dfnf['longitude_x'].fillna(dfnf['longitude_y'], inplace=True)
            dfnf.replace('nan', pd.NA, inplace=True)
            dfnf = dfnf.where(pd.notnull(dfnf), None)
            dfnf = dfnf
            dfnf_count = len(dfnf)
            if dfnf_count == 0:
                raise Exception('Joined Katapult Table has no featuers.')
            dfnf.to_excel(f'{dir}\\dfnf.xlsx', index=False)
            progressBar.setValue(20)
            #project.crs().authid()    -> This grabs the project CRS if we needed to project, but we don't need it yet. The points work best in EPSG: 4326

            pts = processing.run("native:createpointslayerfromtable", {'INPUT':f'{dir}\\dfnf.xlsx','XFIELD':'longitude','YFIELD':'latitude','ZFIELD':'','MFIELD':'','TARGET_CRS':QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            reprojected = processing.run("native:reprojectlayer", {'INPUT': pts,'TARGET_CRS':QgsCoordinateReferenceSystem(project.crs().authid()),'CONVERT_CURVED_GEOMETRIES':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            project.addMapLayer(reprojected)
            repr = project.mapLayersByName('Reprojected')[0]
            #Select all poles within 30 feet of Reprojected poles
            progressBar.setValue(25)
            # set all poles without 'node_id' to 'Original'
            processing.run("qgis:selectbyexpression", {'INPUT': poles,'EXPRESSION':"data_source is null and node_id is null",'METHOD':0})
            dbox.append(f' {poles.selectedFeatureCount()}  Poles updating data source "Original"  due to null data source and node_id. Please wait while this calculates, it may take a while.')
            progressBar.setValue(27)
            #time.sleep(4)
            if poles.selectedFeatureCount() > 0:
                try:
                    poles.startEditing()
                except:
                    pass
                for f in poles.selectedFeatures():
                        f['data_source'] = 'Original'
                        poles.updateFeature(f)
                poles.commitChanges()
                poles.removeSelection()
            progressBar.setValue(30)
            if QgsUnitTypes.encodeUnit(project.distanceUnits()) == 'feet':
                #time.sleep(4)
                dbox.append('Calculating pole selection for "Original" source poles...')
                time.sleep(2)
                #buffer = processing.run("native:buffer", {'INPUT':reprojected,'DISTANCE':29.99993999999992,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                #processing.run("native:selectbylocation", {'INPUT':poles,'PREDICATE':[0],'INTERSECT':buffer,'METHOD':0})
                processing.run("native:selectwithindistance", {'INPUT':poles,'REFERENCE':repr,'DISTANCE':29.99993999999992,'METHOD':0})#distance defaults to map units which is in feet for Vero
                dbox.append(f' {poles.selectedFeatureCount()}  Poles within 30 feet of new imports.')
                progressBar.setValue(35)
            else:
                dbox.append('Error! Map CRS must be in units of feet.')
                return
            #Delete the selected features if they are marked as "original"
            if poles.selectedFeatureCount()>0:
                processing.run("qgis:selectbyexpression", {'INPUT': poles,'EXPRESSION':"data_source = 'Original'",'METHOD':3}) #selecting within current selection (because you already have selected the poles that are within 30 feet of the imports)
                dbox.append(f' {poles.selectedFeatureCount()} "Original" Poles selected for deletion.')
                if poles.selectedFeatureCount()>0:
                    progressBar.setValue(45)
                    try:
                        poles.startEditing()
                    except:
                        pass
                    selected_ids = poles.selectedFeatureIds()
                    poles.deleteFeatures(selected_ids)
                    poles.commitChanges()
                #for f in poles.selectedFeatures():
                #   poles.deleteFeature(f.id())
            repr.setName('Poles to Import')
            progressBar.setValue(50)
        else:
            dbox.append(warningFormat.format('No poles in AGOL file. Underground only. Checking for segments...'))
            no_poles = True
            progressBar.setValue(50)
        #-------------------------------------------------------------------------------------
        #Begin segments
        if len(conns) == 0:
            dbox.append('No Connections found.')
        else:
            #Issue: underground vs aerial
            aer_conns = [c for c in conns if 'underground' not in c and 'unknown' not in c and 'reference' not in c]
            ug_conns = [c for c in conns if 'underground' in c] 
            mixed_conns = [c for c in conns if 'unknown' not in c and 'reference' not in c and 'down' not in c]
            progressBar.setValue(51)
            
            if no_poles == False:
                dbox.append('Merging aerial segments...')
                merged_conns = processing.run("native:mergevectorlayers", {'LAYERS':aer_conns,'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            elif no_poles == True:
                dbox.append('Merging underground segments...')
                merged_conns = processing.run("native:mergevectorlayers", {'LAYERS':ug_conns,'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            
            progressBar.setValue(52)
            merged_conns.dataProvider().addAttributes([QgsField("data_source", QVariant.String)])
            merged_conns.dataProvider().addAttributes([QgsField("segment_type", QVariant.String)])
            progressBar.setValue(54)
            merged_conns.updateFields()
            progressBar.setValue(55)
            with edit(merged_conns):
                for f in merged_conns.getFeatures():
                    f['segment_type'] = 'Aerial' if 'underground' not in f['conntype'] else 'Underground' if 'underground' in f['conntype'] else None
                    f['data_source'] =f'Katapult First Import {datetime.now().strftime("%x")}'
                    merged_conns.updateFeature(f)

            #merged_conns = processing.run("native:mergevectorlayers", {'LAYERS':aer_conns,'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                
            progressBar.setValue(65)
            centroids = processing.run("native:centroids", {'INPUT':merged_conns,'ALL_PARTS':True,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #centroids is in degrees, buffer is about 5 feet
            centroids_buffer = processing.run("native:buffer", {'INPUT':centroids,'DISTANCE':0.000014,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            segments = project.mapLayersByName('Segments')[0]
            progressBar.setValue(85)
            processing.run("native:selectbylocation", {'INPUT': segments,'PREDICATE':[0],'INTERSECT':centroids_buffer,'METHOD':0})
            processing.run("qgis:selectbyexpression", {'INPUT': segments,'EXPRESSION':'"data_source" = \'Original\' and "segment_status" is null','METHOD':3})
            dbox.append(f' {segments.selectedFeatureCount()} "Original" Segments selected for deletion.')
            progressBar.setValue(90)
            try:
                segments.startEditing()
            except:
                pass
            selected_ids = segments.selectedFeatureIds()
            segments.deleteFeatures(selected_ids)
            segments.commitChanges()
            m = project.addMapLayer(merged_conns)
            m.setName('Merged Segments Import')
       #Begin ROWs (Point Features)
        if len(row_node)==0:
            dbox.append('No ROWs found.')
        else:
            # we want "nodetype", "note", "nodeid", "jobkey"
            merged_row_nodes = processing.run("native:mergevectorlayers", {'LAYERS':row_node,'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            merged_row_nodes.dataProvider().addAttributes([QgsField("data_source", QVariant.String)])
            #merged_row_nodes.dataProvider().addAttributes([QgsField("segment_type", QVariant.String)])
            progressBar.setValue(54)
            merged_row_nodes.updateFields()
            progressBar.setValue(55)
            with edit(merged_row_nodes):
                for f in merged_row_nodes.getFeatures():
                    f['data_source'] =f'Katapult First Import {datetime.now().strftime("%x")}'
                    merged_row_nodes.updateFeature(f)
            m = project.addMapLayer(merged_row_nodes)
            m.setName('Merged ROW Import')
        #-------------------------------------------------------------------------------------
        #Begin Elements (Point Features)
        if len(row_node)==0:
            dbox.append('No New Anchors found.')
        else:
            merged_element_nodes = processing.run("native:mergevectorlayers", {'LAYERS':element_node,'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            merged_element_nodes.dataProvider().addAttributes([QgsField("data_source", QVariant.String)])
            merged_element_nodes.dataProvider().addAttributes([QgsField("element_type", QVariant.String)])
            merged_element_nodes.dataProvider().addAttributes([QgsField("physical_status", QVariant.String)])
            progressBar.setValue(54)
            merged_element_nodes.updateFields()
            progressBar.setValue(55)
            with edit(merged_element_nodes):
                for f in merged_element_nodes.getFeatures():
                    f['data_source'] =f'Katapult First Import {datetime.now().strftime("%x")}'
                    f['element_type'] = 'Anchor'
                    f['physical_status'] = 'New Build' if 'new' in f['nodetype'] else 'Existing Infrastructure' if 'existing' in f['nodetype'] else 'Error'
                    merged_element_nodes.updateFeature(f)
            m = project.addMapLayer(merged_element_nodes)
            m.setName('Merged Element Import')

        #-------------------------------------------------------------------------------------
        #End
        dbox.append(validFormat.format(f'Vero Katault Import has been succesfully completed. Import '))
        progressBar.setValue(100)
    except Exception as e:
        dbox.append(errorFormat.format(e))
    