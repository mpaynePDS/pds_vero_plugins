# -*- coding: utf-8 -*-
"""
Created on Friday, March 2025
Katapult Importer
@author: Marie Payne

Description:
- After exporting 'AGOL Data' & 'Node' reports from Katapult as excel from zip
- Join to the Pole layer in the Vero project using 'UID' fields
- copy over the data to the 'real' fields
- unjoin
"""
import os
from openpyxl import load_workbook
from datetime import datetime
import pandas as pd
import numpy as np
from zipfile import ZipFile
import sys
from qgis.core import *
from qgis import processing
from datetime import datetime

def __permiter__(permit_list,all_permits, internal_ids,  inputfiles, dbox, progressBar,errorFormat, warningFormat, validFormat):#
    try:
        progressBar.setValue(5)
        project = QgsProject.instance()
        dbox.append(QgsUnitTypes.encodeUnit(project.distanceUnits()))
        dbox.append(str(inputfiles))
        dir = os.path.dirname(inputfiles[0])
        agol_cols = ['class', 'height', 'number_of_attachments', 'pole_number_power', 'pole_owner', 'riser_count', 'stub_pole_transfer', 'tree_trim',
                    'low_power_attachment', 'node_id',
                    'attachment_a_owner', 'attachment_a_existing', 'attachment_a_proposed',
                    'attachment_b_owner', 'attachment_b_existing', 'attachment_b_proposed',
                    'attachment_c_owner', 'attachment_c_existing', 'attachment_c_proposed',
                    'attachment_d_owner', 'attachment_d_existing', 'attachment_d_proposed',
                    'attachment_e_owner', 'attachment_e_existing', 'attachment_e_proposed',
                    'attachment_f_owner', 'attachment_f_existing', 'attachment_f_proposed',
                    'attachment_g_owner', 'attachment_g_existing', 'attachment_g_proposed',
                    'attachment_h_owner', 'attachment_h_existing', 'attachment_h_proposed',
                    'attachment_i_owner', 'attachment_i_existing', 'attachment_i_proposed',
                    'attachment_j_owner', 'attachment_j_existing', 'attachment_j_proposed',
                    ] #removed mre_grade on 4/24/25
        agol_db = pd.DataFrame(columns=agol_cols)
        node_cols = ['node_id', 'latitude', 'longitude', 'internal_note', 'make_ready_type']
        node_db = pd.DataFrame(columns=node_cols) #latitude, longitude, pole number
        # open the zip file
        master = False
        progressBar.setValue(10)
        for zip in inputfiles:
            with ZipFile(zip, 'r') as zObject:
                zObject.extractall(dir)
                li = zObject.namelist()
                print(li)
                for l in li:
                    if 'AGOL' in l:
                        agol = l
                    if 'Node Attributes' in l:
                        node = l
                    if 'MASTER' in l:
                        master = True
            df = pd.read_excel(f'{dir}\\{agol}', sheet_name="Poles")
            #dbox.append(str(df.columns.to_list()))
            '''['Infinium ID', 'Fireworks Project Number', 'Pole Owner', 'Pole Number_Power', 'Pole Number_Frontier', 'Pole Access Type', \
                'Pole Use', 'Class', 'Height', 'Material', 'Drop Pole', 'Comm Riser', 'Riser Count', 'Attach', 'Number of Attachments', \
                'Tree Trim', 'Stub Pole Transfer', 'mre_grade', 'MRE Description', 'Low_Power', 'Low_Power_Attachment', 'Attachment_A_Owner', \
                'Attachment_A_Existing', 'Attachment_A_Proposed', 'Attachment_B_Owner', 'Attachment_B_Existing', 'Attachment_B_Proposed',\
                'Attachment_C_Owner', 'Attachment_C_Existing', 'Attachment_C_Proposed', 'Attachment_D_Owner', 'Attachment_D_Existing',\
                'Attachment_D_Proposed', 'Attachment_E_Owner', 'Attachment_E_Existing', 'Attachment_E_Proposed', 'Comments', \
                'Physical Status', 'Inventory Status Code', 'Longitude', 'Latitude', 'Object ID', 'Structure Name', 'Structure ID',\
                'Pole Number', 'Treatment Type', 'Diameter', 'Foundation Type', 'Grounded', 'Year Manufactured', 'Installation Date',\
                'Cable Owner Contact Number', 'Symbol Rotation', 'IPID', 'Contract Number', 'Global ID', 'Shape', 'ID',\
                'Create Work Order ID', 'Edit Work Order ID', 'Level Begin', 'Level End', 'Num Levels', 'Level Mapping', 'Group ID', \
                'Serving Feature ID', 'Planning ID', 'Is Delete', 'Timestamp', 'Clone Type', 'Is Planning', 'Edit Tracking Date', 'Edit Tracking User', 'Pole Change Out']'''
            df.columns= df.columns.str.lower().str.replace(' ', '_', regex=False)
            #df= df.drop(['infinium_id', 'fireworks_project_number'], axis = 1)
            if all(i not in agol for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                df = df[(df['pole_owner'] != 'ATT')]
            else:
                df = df[(df['pole_owner'] == 'ATT')]
            #agol_db = pd.concat([agol_db, df])
            agol_zdb = df[[col for col in agol_cols if col in df.columns]]
            agol_db = pd.concat([agol_db, agol_zdb], axis=0).reset_index(drop=True)


            df = pd.read_excel(f'{dir}\\{node}')
            df.columns = df.columns.str.lower().str.replace(' ', '_', regex=False)
            if all(i not in node for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                df = df[(df['pole_owner'] != 'ATT')]
            else:
                df = df[(df['pole_owner'] == 'ATT')]
            df = df[(df['node_type'] == 'pole')]    
            #node_db = pd.concat([node_db, df])
            node_zdb = df[[col for col in node_cols if col in df.columns]]
            node_db = pd.concat([node_db, node_zdb], axis = 0).reset_index(drop=True)
            zObject.close() 
        progressBar.setValue(20)
        #agol_db['mre_grade'] =agol_db['mre_grade'].fillna('')
        #agol_db['mre_grade'] = agol_db['mre_grade'].apply(lambda x: 'Simple MR' if 'Communications' in x else 'Power MR' if 'Light Power' in x else 'Pole Replacement' if 'Heavy Power' in x else 'No MR' if 'No Make Ready' in x else x)
        agol_db['stub_pole_transfer'] = agol_db['stub_pole_transfer'].fillna('false')

        try:
            columns_to_convert =  ['attachment_a_existing', 'attachment_a_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_b_existing', 'attachment_b_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_c_existing', 'attachment_c_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_d_existing', 'attachment_d_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_e_existing', 'attachment_e_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_f_existing', 'attachment_f_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_g_existing', 'attachment_g_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_h_existing', 'attachment_h_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_i_existing', 'attachment_i_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_j_existing', 'attachment_j_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
        except:
            pass
        #dbox.append(str(df['mre_grade']))
        # join node node_id data to agol data using lat/longs
        #nf = pd.read_excel(f'{dir}\\{node}')
        #dbox.append(str(nf.columns.to_list()))
        '''['node_id', 'latitude', 'longitude', 'feedback', 'scid', 'node_type', 'pole_owner', 'oncor_tag', 'done', 'field_completed',\
            'flag_for_review', 'infinium_ID', 'internal_note', 'make_ready_notes', 'make_ready_type', 'mr_state', 'note', 'pole_class',\
            'pole_height', 'pole_owner.1', 'pole_spec', 'verify_location_in_field', 'time_bucket_start', 'time_bucket_stop', 'time_bucket_user',\
            'time_bucket_start_2', 'time_bucket_stop_2', 'time_bucket_user_2', 'time_bucket_start_3', 'time_bucket_stop_3', 'time_bucket_user_3',\
            'photo_count', 'main_photo', 'all_photos']'''
        progressBar.setValue(30)
        #dfnf = pd.merge(agol_db, node_db, left_on=['latitude', 'longitude'], right_on = ['latitude', 'longitude'], how='left')
        dfnf = pd.merge(agol_db, node_db,  on='node_id', how='outer')
        dfnf['joined'] = 'True'
        dfnf['data_source'] = f'Katapult Update {datetime.now().strftime("%x")}'
        dfnf['height'] = dfnf['height'].astype(str)
        dfnf['class'] = dfnf['class'].astype(str)
        for col in agol_cols:
            if col not in dfnf.columns:
                dfnf[col] = None
        for col in node_cols:
            if col not in dfnf.columns:
                dfnf[col] = None
        dfnf.replace('nan', pd.NA, inplace=True)
        dfnf = dfnf.where(pd.notnull(dfnf), None)
        dfnf = dfnf
        dfnf_count = len(dfnf)
        dfnf.to_excel(f'{dir}\\dfnf.xlsx', index=False)
        
        # define layers & convert xlsx to layer
        #poles = project.mapLayersByName('Pole_KP_Reference_5_15_25')[0]
        poles = project.mapLayersByName('Pole')[0]
        csv_file = QgsVectorLayer(f'{dir}\\dfnf.xlsx', 'Katapult AGOL', 'ogr')
        QgsProject.instance().addMapLayer(csv_file)
        csv = project.mapLayersByName('Katapult AGOL')[0]
        progressBar.setValue(35)
        # Locate the permit boundries and limit Katapult AGOL layer to only those permit poles.
        permits_layer = project.mapLayersByName('Permits')[0]
        #Pole Permits , general QC
        #
        all_perms = '(\''
        all_perms += '\', \''.join(p for p in all_permits if p is not None)
        all_perms +='\')'

        all_internal_ids = '(\''
        all_internal_ids += '\', \''.join(p for p in internal_ids if p is not None)
        all_internal_ids +='\')'

        progressBar.setValue(40)
        qc_poles = processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':f'"permit" not in {all_perms} and "permit" not in {all_internal_ids} and "permit" is not Null','METHOD':0})['OUTPUT']
        qc_poles_count = qc_poles.selectedFeatureCount()
        dbox.append(warningFormat.format(f'{qc_poles_count} Poles with "permit" field that does not match any Permit Polygon.'))
        progressBar.setValue(45)
        #Extract by specific internal permit ids
        int_perms = '(\''
        int_perms += '\', \''.join(p.split(' | ')[0] for p in permit_list if p.split(' | ')[0] not in ['NULL', '']) #CISCTX-ZONE 01-3 | 2025-038-0003  # f'{p['internal_permit_id']} | {p['permit_number']}'
        int_perms +='\')'
        perms = '(\''
        perms += '\', \''.join(p.split(' | ')[1] for p in permit_list if p.split(' | ')[1] not in ['NULL', '']) #CISCTX-ZONE 01-3 | 2025-038-0003  # f'{p['internal_permit_id']} | {p['permit_number']}'
        perms +='\')'
        permit_selection = processing.run("qgis:selectbyexpression", {'INPUT':permits_layer,'EXPRESSION':f'("internal_permit_id" in {int_perms} or "internal_permit_id" is NULL) and ("permit_number" in {perms} or "permit_number" IS NULL)','METHOD':0})['OUTPUT']
        """selected_internal_ids = []
        for f in permits_layer.selectedFeatures():
            if f['internal_permit_id']:
                selected_internal_ids.append(f['internal_permit_id'])
        sel_ids = '(\''
        sel_ids += '\', \''.join(p for p in selected_internal_ids)
        sel_ids +='\')"""
        progressBar.setValue(50)
        # join katapult onto pole layer
        field_names = [field.name() for field in csv.fields()]
        node_field = 'node_id' if 'node_id' in field_names else 'node_id_x' if 'node_id_x' in field_names else 'node_id_y' if 'node_id_y' in field_names else None
        if node_field is None:
            dbox.append(errorFormat.format('Could not locate node_id from Katapult Tables.'))
            return
        joinObject = QgsVectorLayerJoinInfo()
        joinObject.setJoinFieldName(node_field)# may be node_id, node_id_x or node_id_y
        joinObject.setTargetFieldName('node_id')
        joinObject.setJoinLayerId = csv.id()
        joinObject.setJoinLayer(csv)
        joinObject.setPrefix('k_')
        joinObject.setUsingMemoryCache(True)
        poles.addJoin(joinObject)
        dbox.append('Joined')
        progressBar.setValue(60)
        # QC Select all poles that share the correct permit name
        total_poles_permit_named = processing.run("qgis:selectbyexpression", {'INPUT':poles, 'EXPRESSION':f'"permit" in {perms} or "permit" in {int_perms} or "mr_notes" in {perms} or "mr_notes" in {int_perms}','METHOD':0})['OUTPUT']
        total_poles_permit_named_count = total_poles_permit_named.selectedFeatureCount()
        poles_permit_named = processing.run("qgis:selectbyexpression", {'INPUT':poles, 'EXPRESSION':f'("permit" in {perms} or "permit" in {int_perms} or "mr_notes" in {perms} or "mr_notes" in {int_perms}) and "attach" = \'Yes\'','METHOD':0})['OUTPUT']
        poles_permit_named_count = poles_permit_named.selectedFeatureCount()
        dbox.append(f'()"permit" in {perms} or "permit" in {int_perms} or "mr_notes" in {perms} or "mr_notes" in {int_perms}) and "attach" = \'Yes\'')
        progressBar.setValue(65)
        # Select only rows affected by join
        selection_a = processing.run("native:selectbylocation", {'INPUT':poles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(permit_selection.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})['OUTPUT']
        permit_poles_count = selection_a.selectedFeatureCount()
        progressBar.setValue(75)
        '''
        Note: June/2/25, if pole is attach = 'No', then it will not be uploaded to Verofy and does not need to be updated.
        '''
        if master:
            selection = processing.run("qgis:selectbyexpression", {'INPUT':poles, 'EXPRESSION':f'"k_joined" is not NULL and ("permit" in {perms} or "permit" in {int_perms} or "mr_notes" in {perms} or "mr_notes" in {int_perms} ) and "data_source" LIKE \'MASTER\'','METHOD':3})['OUTPUT']

        else:
            selection = processing.run("qgis:selectbyexpression", {'INPUT':poles, 'EXPRESSION':f'"k_joined" is not NULL and ("permit" in {perms} or "permit" in {int_perms} or "mr_notes" in {perms} or "mr_notes" in {int_perms} )','METHOD':3})['OUTPUT']
        selection_count = selection.selectedFeatureCount()
        dbox.append(f'{permit_poles_count} Poles within Permit Polygons|{total_poles_permit_named_count} Total Poles with Permit Name | {poles_permit_named_count} "Yes" Poles with Permit Name | {selection_count} Joined Features')
        if permit_poles_count == 0 or selection_count ==0 or poles_permit_named_count == 0:
            dbox.append(errorFormat.format('Not enough poles.'))
            return
        progressBar.setValue(85)
        # map the fields
        if poles.isEditable():
            poles.commitChanges()
        with edit(poles):
            poles.updateFields()
            for f in poles.selectedFeatures():
                if 'k_node_id' is not None:
                    #f['attach'] = f['k_attach'] if f['k_attach'] is not None else f['attach']
                    if master:
                        f['data_source'] = f['k_data_source'] + ' MASTER MAP'
                    else:
                        f['data_source'] = f['k_data_source']
                    f['attachment_a_owner'] = f['k_attachment_a_owner'] if f['k_attachment_a_owner'] not in [None, 'nan'] else f['attachment_a_owner']
                    f['attachment_a_existing'] = f['k_attachment_a_existing'] if f['k_attachment_a_existing'] not in [None, 'nan'] else f['attachment_a_existing']
                    f['attachment_a_proposed'] = f['k_attachment_a_proposed'] if f['k_attachment_a_proposed'] not in [None, 'nan'] else f['attachment_a_proposed']

                    f['attachment_b_owner'] = f['k_attachment_b_owner'] if f['k_attachment_b_owner']  not in [None, 'nan'] else f['attachment_b_owner']
                    f['attachment_b_existing'] = f['k_attachment_b_existing'] if f['k_attachment_b_existing'] not in [None, 'nan'] else f['attachment_b_existing']
                    f['attachment_b_proposed'] = f['k_attachment_b_proposed'] if f['k_attachment_b_proposed']  not in [None, 'nan'] else f['attachment_b_proposed']

                    f['attachment_c_owner'] = f['k_attachment_c_owner'] if f['k_attachment_c_owner']  not in [None, 'nan'] else f['attachment_c_owner']
                    f['attachment_c_existing'] = f['k_attachment_c_existing'] if f['k_attachment_c_existing'] not in [None, 'nan'] else f['attachment_c_existing']
                    f['attachment_c_proposed'] = f['k_attachment_c_proposed'] if f['k_attachment_c_proposed']  not in [None, 'nan'] else f['attachment_c_proposed']

                    f['attachment_d_owner'] = f['k_attachment_d_owner'] if f['k_attachment_d_owner'] not in [None, 'nan'] else f['attachment_d_owner']
                    f['attachment_d_existing'] = f['k_attachment_d_existing'] if f['k_attachment_d_existing'] not in [None, 'nan'] else f['attachment_d_existing']
                    f['attachment_d_proposed'] = f['k_attachment_d_proposed'] if f['k_attachment_d_proposed']  not in [None, 'nan'] else f['attachment_d_proposed']

                    f['attachment_e_owner'] = f['k_attachment_e_owner'] if f['k_attachment_e_owner'] not in [None, 'nan'] else f['attachment_e_owner']
                    f['attachment_e_existing'] = f['k_attachment_e_existing'] if f['k_attachment_e_existing']  not in [None, 'nan'] else f['attachment_e_existing']
                    f['attachment_e_proposed'] = f['k_attachment_e_proposed'] if f['k_attachment_e_proposed']  not in [None, 'nan'] else f['attachment_e_proposed']

                    f['attachment_f_owner'] = f['k_attachment_f_owner'] if f['k_attachment_f_owner']  not in [None, 'nan'] else f['attachment_f_owner']
                    f['attachment_f_existing'] = f['k_attachment_f_existing'] if f['k_attachment_f_existing']  not in [None, 'nan'] else f['attachment_f_existing']
                    f['attachment_f_proposed'] = f['k_attachment_f_proposed'] if f['k_attachment_f_proposed']  not in [None, 'nan'] else f['attachment_f_proposed']

                    f['attachment_g_owner'] = f['k_attachment_g_owner'] if f['k_attachment_g_owner']  not in [None, 'nan'] else f['attachment_g_owner']
                    f['attachment_g_existing'] = f['k_attachment_g_existing'] if f['k_attachment_g_existing']  not in [None, 'nan'] else f['attachment_g_existing']
                    f['attachment_g_proposed'] = f['k_attachment_g_proposed'] if f['k_attachment_g_proposed']  not in [None, 'nan'] else f['attachment_g_proposed']

                    f['attachment_h_owner'] = f['k_attachment_h_owner'] if f['k_attachment_h_owner']  not in [None, 'nan'] else f['attachment_h_owner']
                    f['attachment_h_existing'] = f['k_attachment_h_existing'] if f['k_attachment_h_existing']  not in [None, 'nan'] else f['attachment_h_existing']
                    f['attachment_h_proposed'] = f['k_attachment_h_proposed'] if f['k_attachment_h_proposed']  not in [None, 'nan'] else f['attachment_h_proposed']

                    f['attachment_i_owner'] = f['k_attachment_i_owner'] if f['k_attachment_i_owner']  not in [None, 'nan'] else f['attachment_i_owner']
                    f['attachment_i_existing'] = f['k_attachment_i_existing'] if f['k_attachment_i_existing']  not in [None, 'nan'] else f['attachment_i_existing']
                    f['attachment_i_proposed'] = f['k_attachment_i_proposed'] if f['k_attachment_i_proposed']  not in [None, 'nan'] else f['attachment_i_proposed']

                    f['attachment_j_owner'] = f['k_attachment_j_owner'] if f['k_attachment_j_owner']  not in [None, 'nan'] else f['attachment_j_owner']
                    f['attachment_j_existing'] = f['k_attachment_j_existing'] if f['k_attachment_j_existing']  not in [None, 'nan'] else f['attachment_j_existing']
                    f['attachment_j_proposed'] = f['k_attachment_j_proposed'] if f['k_attachment_j_proposed']  not in [None, 'nan'] else f['attachment_j_proposed']

                    f['class'] = f['k_class'] if f['k_class'] not in [None, 'nan'] else f['class']
                    try:
                        f['internal_note'] = f['k_internal_note'] if f['k_internal_note'] not in [None, 'nan'] else f['internal_note']
                    except:
                        try:
                            f['internal_note'] = f['k_internal_note_x'] if f['k_internal_note_x'] not in [None, 'nan'] else f['internal_note']
                        except:
                            f['internal_note'] = f['k_internal_note_y'] if f['k_internal_note_y'] not in [None, 'nan'] else f['internal_note']
                    try:
                        f['height'] = f['k_height'] if f['k_height'] not in [None, 'nan'] else f['height']
                    except:
                        f['height'] = f['k_height_x'] if f['k_height_x'] not in [None, 'nan'] else f['height']
                    #f['mr_state'] = f['k_mre_grade'] if f['k_mre_grade'] not in [None, 'nan'] else f['mr_state']
                    f['make_ready_type'] = f['k_make_ready_type'] if f['k_make_ready_type'] not in [None, 'nan'] else f['mr_state']
                    f['no_attachments']= f['k_number_of_attachments'] if f['k_number_of_attachments'] not in [None, 'nan'] else f['no_attachments']
                    f['pole_tag'] = f['k_pole_number_power'] if f['k_pole_number_power'] not in [None, 'nan'] else f['pole_tag']
                    try:
                        f['pole_owner'] = f['k_pole_owner'] if f['k_pole_owner'] not in [None, 'nan'] else f['pole_owner']
                    except:
                        try:
                            f['pole_owner'] = f['k_pole_owner_x'] if f['k_pole_owner_x'] not in [None, 'nan'] else f['pole_owner']
                        except:
                            f['pole_owner'] = f['k_pole_owner_y'] if f['k_pole_owner_y'] not in [None, 'nan'] else f['pole_owner']
                    try:
                        f['riser_count'] = f['k_riser_count'] if f['k_riser_count']not in [None, 'nan'] else f['riser_count']
                    except:
                        f['riser_count'] = f['k_riser_count_x'] if f['k_riser_count_x']not in [None, 'nan'] else f['riser_count']
                    try:
                        f['stub_pole_transfer'] = f['k_stub_pole_transfer'] if f['k_stub_pole_transfer']not in [None, 'nan'] else f['stub_pole_transfer']
                    except:
                        f['stub_pole_transfer'] = f['k_stub_pole_transfer_x'] if f['k_stub_pole_transfer_x']not in [None, 'nan'] else f['stub_pole_transfer']
                    try:
                        f['tree_trim'] = f['k_tree_trim'] if f['k_tree_trim'] not in [None, 'nan'] else f['tree_trim']
                    except:
                        f['tree_trim'] = f['k_tree_trim_x'] if f['k_tree_trim_x'] not in [None, 'nan'] else f['tree_trim']
                    poles.updateFeature(f)
        
                # remove the join
        progressBar.setValue(90)
        poles.removeJoin(csv.id())
    
        QgsProject.instance().removeMapLayers( [csv.id()] )
        progressBar.setValue(95)
        os.remove(f'{dir}\\{agol}')
        os.remove(f'{dir}\\{node}')
        
        dbox.append(validFormat.format(f'Vero Katault Import has been succesfully completed.'))
        progressBar.setValue(100)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {line_number}'))
    