# -*- coding: utf-8 -*-
"""
Created on Friday, March 2025
Katapult Importer
@author: Marie Payne

Description:
- After exporting 'AGOL Data' & 'Node' reports from Katapult as excel from zip
- Join to the Pole layer in the Vero project using 'UID' fields
- copy over the data to the 'real' fields
- unjoin
"""
import os
from openpyxl import load_workbook
from datetime import datetime
import pandas as pd
import numpy as np
from zipfile import ZipFile
import sys
from qgis.core import *
from qgis import processing

def __checker__(inputfiles, dbox, progressBar,errorFormat, warningFormat, validFormat):
    try:
        progressBar.setValue(5)
        project = QgsProject.instance()
        dbox.append(QgsUnitTypes.encodeUnit(project.distanceUnits()))
        dbox.append(str(inputfiles))
        dir = os.path.dirname(inputfiles[0])
        agol_cols = ['class', 'height', 'number_of_attachments', 'pole_number_power', 'pole_owner', 'riser_count', 'stub_pole_transfer', 'tree_trim',
                    'low_power_attachment', 'node_id',
                    'attachment_a_owner', 'attachment_a_existing', 'attachment_a_proposed',
                    'attachment_b_owner', 'attachment_b_existing', 'attachment_b_proposed',
                    'attachment_c_owner', 'attachment_c_existing', 'attachment_c_proposed',
                    'attachment_d_owner', 'attachment_d_existing', 'attachment_d_proposed',
                    'attachment_e_owner', 'attachment_e_existing', 'attachment_e_proposed',
                    'attachment_f_owner', 'attachment_f_existing', 'attachment_f_proposed',
                    'attachment_g_owner', 'attachment_g_existing', 'attachment_g_proposed',
                    'attachment_h_owner', 'attachment_h_existing', 'attachment_h_proposed',
                    'attachment_i_owner', 'attachment_i_existing', 'attachment_i_proposed',
                    'attachment_j_owner', 'attachment_j_existing', 'attachment_j_proposed',
                    ] #removed mre_grade on 4/24/25
        agol_db = pd.DataFrame(columns=agol_cols)
        node_cols = ['node_id','internal_note', 'latitude', 'longitude', 'make_ready_type']
        node_db = pd.DataFrame(columns=node_cols) #latitude, longitude, pole number
        master = False
        # open the zip file
        for zip in inputfiles:
            with ZipFile(zip, 'r') as zObject:
                zObject.extractall(dir)
                li = zObject.namelist()
                print(li)
                for l in li:
                    if 'AGOL' in l:
                        agol = l
                    if 'Node Attributes' in l:
                        node = l
                    if 'MASTER' in l:
                        master = True
            df = pd.read_excel(f'{dir}\\{agol}', sheet_name="Poles")
            #dbox.append(str(df.columns.to_list()))
            '''['Infinium ID', 'Fireworks Project Number', 'Pole Owner', 'Pole Number_Power', 'Pole Number_Frontier', 'Pole Access Type', \
                'Pole Use', 'Class', 'Height', 'Material', 'Drop Pole', 'Comm Riser', 'Riser Count', 'Attach', 'Number of Attachments', \
                'Tree Trim', 'Stub Pole Transfer', 'mre_grade', 'MRE Description', 'Low_Power', 'Low_Power_Attachment', 'Attachment_A_Owner', \
                'Attachment_A_Existing', 'Attachment_A_Proposed', 'Attachment_B_Owner', 'Attachment_B_Existing', 'Attachment_B_Proposed',\
                'Attachment_C_Owner', 'Attachment_C_Existing', 'Attachment_C_Proposed', 'Attachment_D_Owner', 'Attachment_D_Existing',\
                'Attachment_D_Proposed', 'Attachment_E_Owner', 'Attachment_E_Existing', 'Attachment_E_Proposed', 'Comments', \
                'Physical Status', 'Inventory Status Code', 'Longitude', 'Latitude', 'Object ID', 'Structure Name', 'Structure ID',\
                'Pole Number', 'Treatment Type', 'Diameter', 'Foundation Type', 'Grounded', 'Year Manufactured', 'Installation Date',\
                'Cable Owner Contact Number', 'Symbol Rotation', 'IPID', 'Contract Number', 'Global ID', 'Shape', 'ID',\
                'Create Work Order ID', 'Edit Work Order ID', 'Level Begin', 'Level End', 'Num Levels', 'Level Mapping', 'Group ID', \
                'Serving Feature ID', 'Planning ID', 'Is Delete', 'Timestamp', 'Clone Type', 'Is Planning', 'Edit Tracking Date', 'Edit Tracking User', 'Pole Change Out']'''
            df.columns= df.columns.str.lower().str.replace(' ', '_', regex=False)
            #df= df.drop(['infinium_id', 'fireworks_project_number'], axis = 1)
            if 'pole_owner' not in df.columns.to_list():
                dbox.append(errorFormat.format('AGOL Table missing "Pole Owner", overwriting with NULL values.'))
                df['pole_owner'] = None
            if all(i not in agol for i in ['ATT', 'AT&T', 'PLA','SOUTHERN PINE']):
                df = df[(df['pole_owner'] != 'ATT')]
            else:
                df = df[(df['pole_owner'] == 'ATT')]
            #agol_db = pd.concat([agol_db, df], join='inner')
            agol_zdb = df[[col for col in agol_cols if col in df.columns]]
            agol_db = pd.concat([agol_db, agol_zdb], axis=0).reset_index(drop=True)


            
            df = pd.read_excel(f'{dir}\\{node}')
            df.columns = df.columns.str.lower().str.replace(' ', '_', regex=False)
            if 'pole_owner' not in df.columns.to_list():
                dbox.append(errorFormat.format('Node Table missing "Pole Owner", overwriting with NULL values.'))
                df['pole_owner'] = None
            if all(i not in node for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                df = df[(df['pole_owner'] != 'ATT')]
            else:
                df = df[(df['pole_owner'] == 'ATT')]
            df = df[(df['node_type'] == 'pole')]
            #node_db = pd.concat([node_db, df],join='inner')
            node_zdb = df[[col for col in node_cols if col in df.columns]]
            node_db = pd.concat([node_db, node_zdb], axis = 0).reset_index(drop=True)
            zObject.close() 

        #agol_db['mre_grade'] =agol_db['mre_grade'].fillna('')
        #agol_db['mre_grade'] = agol_db['mre_grade'].apply(lambda x: 'Simple MR' if 'Communications' in x else 'Power MR' if 'Light Power' in x else 'Pole Replacement' if 'Heavy Power' in x else 'No MR' if 'No Make Ready' in x else x)
        agol_db['stub_pole_transfer'] = agol_db['stub_pole_transfer'].fillna('false')
        
        '''columns_to_convert = ['attachment_a_existing', 'attachment_a_proposed', 
                        'attachment_b_existing', 'attachment_b_proposed',
                        'attachment_c_existing', 'attachment_c_proposed',
                        'number_of_attachments', 'low_power_attachment']
        agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)'''
        try:
            columns_to_convert =  ['attachment_a_existing', 'attachment_a_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_b_existing', 'attachment_b_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_c_existing', 'attachment_c_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_d_existing', 'attachment_d_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_e_existing', 'attachment_e_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_f_existing', 'attachment_f_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_g_existing', 'attachment_g_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_h_existing', 'attachment_h_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_i_existing', 'attachment_i_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_j_existing', 'attachment_j_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
        except:
            pass
        #dbox.append(str(df['mre_grade']))
        # join node node_id data to agol data using lat/longs
        #nf = pd.read_excel(f'{dir}\\{node}')
        #dbox.append(str(nf.columns.to_list()))
        '''['node_id', 'latitude', 'longitude', 'feedback', 'scid', 'node_type', 'pole_owner', 'oncor_tag', 'done', 'field_completed',\
            'flag_for_review', 'infinium_ID', 'internal_note', 'make_ready_notes', 'make_ready_type', 'mr_state', 'note', 'pole_class',\
            'pole_height', 'pole_owner.1', 'pole_spec', 'verify_location_in_field', 'time_bucket_start', 'time_bucket_stop', 'time_bucket_user',\
            'time_bucket_start_2', 'time_bucket_stop_2', 'time_bucket_user_2', 'time_bucket_start_3', 'time_bucket_stop_3', 'time_bucket_user_3',\
            'photo_count', 'main_photo', 'all_photos']'''
        #dfnf = pd.merge(agol_db, node_db, left_on=['latitude', 'longitude'], right_on = ['latitude', 'longitude'], how='left')
        dfnf = pd.merge(agol_db, node_db,  on='node_id', how='outer')
        dfnf['joined'] = 'True'
        dfnf['data_source'] = 'Katapult Update'
        dfnf['height'] = dfnf['height'].astype(str)
        dfnf['class'] = dfnf['class'].astype(str)
        for col in agol_cols:
            if col not in dfnf.columns:
                dfnf[col] = None
        for col in node_cols:
            if col not in dfnf.columns:
                dfnf[col] = None
        #dfnf['latitude_x'].fillna(dfnf['latitude_y'], inplace=True)
        #dfnf['longitude_x'].fillna(dfnf['longitude_y'], inplace=True)
        #dfnf = dfnf.fillna(np.nan).replace([np.nan], [None])
        #dfnf = dfnf.where(pd.notnull(dfnf), None)
        dfnf.replace('nan', pd.NA, inplace=True)
        dfnf = dfnf.where(pd.notnull(dfnf), None)

        dfnf = dfnf
        dfnf_count = len(dfnf)
        dfnf_node_ids = dfnf['node_id'].to_list()
        dfnf.to_excel(f'{dir}\\dfnf.xlsx', index=False)
        
        # define layers & convert xlsx to layer
        #poles = project.mapLayersByName('Pole_KP_Reference_5_15_25')[0]
        poles = project.mapLayersByName('Pole')[0]
        csv_file = QgsVectorLayer(f'{dir}\\dfnf.xlsx', 'Katapult AGOL', 'ogr')
        QgsProject.instance().addMapLayer(csv_file)
        
        csv = project.mapLayersByName('Katapult AGOL')[0]
        # join katapult onto pole layer
        field_names = [field.name() for field in csv.fields()]
        node_field = 'node_id' if 'node_id' in field_names else 'node_id_x' if 'node_id_x' in field_names else 'node_id_y' if 'node_id_y' in field_names else None
        joinObject = QgsVectorLayerJoinInfo()
        
        joinObject.setJoinFieldName(node_field)
        joinObject.setTargetFieldName('node_id')
        joinObject.setJoinLayerId = csv.id()
        joinObject.setJoinLayer(csv)
        joinObject.setPrefix('k_')
        joinObject.setUsingMemoryCache(True)
        poles.addJoin(joinObject)
        dbox.append('Joined')
        # Select only rows affected by join
        if master:
            selection = processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':'"k_joined" is not NULL and "data_source" LIKE \'MASTER\'','METHOD':0})['OUTPUT']
        else:
            selection = processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':'"k_joined" is not NULL','METHOD':0})['OUTPUT']

        selection_count = selection.selectedFeatureCount()
        dbox.append(f'{dfnf_count} Katapult Features: {selection_count} Joined Features')
        node_id_joined = []
        # map the fields
        uuids = []
        for f in poles.selectedFeatures():
            node_id_joined.append(f['node_id'])
            if 'k_node_id' is not None:
                #f['attach'] = f['k_attach'] if f['k_attach'] is not None else f['attach']#f['make_ready_type'] != f['k_make_ready_type']or\
                if f['attachment_a_owner'] != f['k_attachment_a_owner'] or \
                f['attachment_a_existing'] != f['k_attachment_a_existing'] or\
                f['attachment_a_proposed'] != f['k_attachment_a_proposed'] or\
                f['attachment_b_owner'] != f['k_attachment_b_owner'] or\
                f['attachment_b_existing'] != f['k_attachment_b_existing'] or\
                f['attachment_b_proposed'] != f['k_attachment_b_proposed'] or\
                f['attachment_c_owner'] != f['k_attachment_c_owner'] or\
                f['attachment_c_existing'] != f['k_attachment_c_existing'] or\
                f['attachment_c_proposed'] != f['k_attachment_c_proposed'] or\
                f['attachment_d_owner'] != f['k_attachment_d_owner'] or\
                f['attachment_d_existing'] != f['k_attachment_d_existing']or\
                f['attachment_d_proposed'] != f['k_attachment_d_proposed']or\
                f['attachment_e_owner']!= f['k_attachment_e_owner'] or\
                f['attachment_e_existing'] != f['k_attachment_e_existing']or\
                f['attachment_e_proposed'] != f['k_attachment_e_proposed']or\
                f['attachment_f_owner'] != f['k_attachment_f_owner'] or\
                f['attachment_f_existing'] != f['k_attachment_f_existing']or\
                f['attachment_f_proposed'] != f['k_attachment_f_proposed'] or\
                f['attachment_g_owner'] != f['k_attachment_g_owner'] or\
                f['attachment_g_existing'] != f['k_attachment_g_existing']or\
                f['attachment_g_proposed'] != f['k_attachment_g_proposed'] or\
                f['attachment_h_owner'] != f['k_attachment_h_owner'] or\
                f['attachment_h_existing'] != f['k_attachment_h_existing']or\
                f['attachment_h_proposed'] != f['k_attachment_h_proposed'] or\
                f['attachment_i_owner'] != f['k_attachment_i_owner'] or\
                f['attachment_i_existing'] != f['k_attachment_i_existing']or\
                f['attachment_i_proposed'] != f['k_attachment_i_proposed'] or\
                f['attachment_j_owner'] != f['k_attachment_j_owner'] or\
                f['attachment_j_existing'] != f['k_attachment_j_existing']or\
                f['attachment_j_proposed'] != f['k_attachment_j_proposed'] or\
                f['no_attachments'] != f['k_number_of_attachments']or\
                f['pole_tag'] != f['k_pole_number_power'] or\
                f['stub_pole_transfer'] != f['k_stub_pole_transfer'] or\
                f['class'] != f['k_class']:
                    uuids.append(f['uuid'])

                try:
                    if f['internal_note'] != f['k_internal_note']:
                        uuids.append(f['uuid'])
                except:
                    if f['internal_note'] != f['k_internal_note_x']:
                        uuids.append(f['uuid'])
                try:
                    if f['height'] != f['k_height']:
                        uuids.append(f['uuid'])
                except:
                    if f['height'] != f['k_height_x']:
                        uuids.append(f['uuid'])
                
                try:
                    if f['pole_owner'] != f['k_pole_owner']:
                        uuids.append(f['uuid'])
                except Exception as e:
                    dbox.append(str(e))
                    try:
                        if f['pole_owner'] != f['k_pole_owner_x']:
                            uuids.append(f['uuid'])
                    except Exception as e:
                        dbox.append(e)
                        if f['pole_owner'] != f['k_pole_owner_y']:
                            uuids.append(f['uuid'])
                try:
                    if f['riser_count'] != f['k_riser_count']:
                        uuids.append(f['uuid'])
                except:
                    if f['riser_count'] != f['k_riser_count_x']:
                        uuids.append(f['uuid'])
                
                try:
                    if f['tree_trim'] != f['k_tree_trim']:
                       uuids.append(f['uuid'])
                except:
                    if f['tree_trim'] != f['k_tree_trim_x']:
                        uuids.append(f['uuid'])
        if len(uuids)>0:
            uuids_str  = ""
            uuids_str += "', '".join(uuids)
            uuids_str2 = "('" + uuids_str+"')"
            dbox.append(uuids_str2)
            selection = processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':f'"uuid" in {uuids_str2}','METHOD':0})['OUTPUT']
        else:
            selection = processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':f'"uuid" is null','METHOD':0})['OUTPUT']
                # remove the join
        dbox.append(str(len(dfnf_node_ids)))
        dbox.append(str(len(node_id_joined)))
        missing_nodes = [n for n in dfnf_node_ids if n not in node_id_joined]
        dbox.append(f'Nodes missing node_id from dfnf: {str(missing_nodes)}')
        os.remove(f'{dir}\\{agol}')
        os.remove(f'{dir}\\{node}')
        katapult_agol = processing.run("native:createpointslayerfromtable", {'INPUT':csv_file,'XFIELD':'longitude','YFIELD':'latitude','ZFIELD':'','MFIELD':'','TARGET_CRS':QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        QgsProject.instance().addMapLayer(katapult_agol)
        if len(missing_nodes) > 0:
            safe_tuple = ', '.join(f"'{x}'" for x in missing_nodes)
            selection = processing.run("qgis:selectbyexpression", {'INPUT':csv_file,'EXPRESSION':f'"node_id" in ({safe_tuple})','METHOD':0})['OUTPUT']
            missing_node_pts = processing.run("native:createpointslayerfromtable", {'INPUT':QgsProcessingFeatureSourceDefinition(csv_file.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'XFIELD':'longitude','YFIELD':'latitude','ZFIELD':'','MFIELD':'','TARGET_CRS':QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            QgsProject.instance().addMapLayer(missing_node_pts)
            missing_node_pts.setName('Missing Poles')
        dbox.append(validFormat.format(f'Vero Katault Validity Check has been succesfully completed.'))
        progressBar.setValue(100)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {line_number}'))
