# -*- coding: utf-8 -*-
"""
Created on Friday, March 2025
Katapult Importer - Upate Existing with Node iD
@author: Marie Payne

Description:
- After exporting 'AGOL Data' & 'Node' reports from Katapult as excel from zip
- Join to the Pole layer in the Vero project using 'UID' fields
- copy over the data to the 'real' fields
- unjoin
"""
import os
from openpyxl import load_workbook
from datetime import datetime
import pandas as pd
import numpy as np
from zipfile import ZipFile
import sys
from qgis.core import *
from qgis import processing
from datetime import datetime

def __main__(inputfiles, dbox, progressBar,errorFormat, warningFormat, validFormat):
    try:
        progressBar.setValue(5)
        project = QgsProject.instance()
        dbox.append(QgsUnitTypes.encodeUnit(project.distanceUnits()))
        dbox.append(str(inputfiles))
        dir = os.path.dirname(inputfiles[0])
        agol_cols = ['class', 'height', 'number_of_attachments', 'pole_number_power', 'pole_owner', 'riser_count', 'stub_pole_transfer', 'tree_trim',
                    'low_power_attachment', 'node_id',
                    'attachment_a_owner', 'attachment_a_existing', 'attachment_a_proposed',
                    'attachment_b_owner', 'attachment_b_existing', 'attachment_b_proposed',
                    'attachment_c_owner', 'attachment_c_existing', 'attachment_c_proposed',
                    'attachment_d_owner', 'attachment_d_existing', 'attachment_d_proposed',
                    'attachment_e_owner', 'attachment_e_existing', 'attachment_e_proposed',
                    'attachment_f_owner', 'attachment_f_existing', 'attachment_f_proposed',
                    'attachment_g_owner', 'attachment_g_existing', 'attachment_g_proposed',
                    'attachment_h_owner', 'attachment_h_existing', 'attachment_h_proposed',
                    'attachment_i_owner', 'attachment_i_existing', 'attachment_i_proposed',
                    'attachment_j_owner', 'attachment_j_existing', 'attachment_j_proposed',] #removed mre_grade on 4/24/25
        agol_db = pd.DataFrame(columns=agol_cols)
        node_cols = ['node_id', 'internal_note', 'latitude', 'longitude', 'make_ready_type']
        node_db = pd.DataFrame(columns=node_cols) #latitude, longitude, pole number
        # open the zip file
        master = False
        for zip in inputfiles:
            with ZipFile(zip, 'r') as zObject:
                zObject.extractall(dir)
                li = zObject.namelist()
                print(li)
                for l in li:
                    if 'AGOL' in l:
                        agol = l
                    if 'Node Attributes' in l:
                        node = l
                    if 'MASTER' in l:
                        master = True    
            df = pd.read_excel(f'{dir}\\{agol}', sheet_name="Poles")
            #dbox.append(str(df.columns.to_list()))
            '''['Infinium ID', 'Fireworks Project Number', 'Pole Owner', 'Pole Number_Power', 'Pole Number_Frontier', 'Pole Access Type', \
                'Pole Use', 'Class', 'Height', 'Material', 'Drop Pole', 'Comm Riser', 'Riser Count', 'Attach', 'Number of Attachments', \
                'Tree Trim', 'Stub Pole Transfer', 'mre_grade', 'MRE Description', 'Low_Power', 'Low_Power_Attachment', 'Attachment_A_Owner', \
                'Attachment_A_Existing', 'Attachment_A_Proposed', 'Attachment_B_Owner', 'Attachment_B_Existing', 'Attachment_B_Proposed',\
                'Attachment_C_Owner', 'Attachment_C_Existing', 'Attachment_C_Proposed', 'Attachment_D_Owner', 'Attachment_D_Existing',\
                'Attachment_D_Proposed', 'Attachment_E_Owner', 'Attachment_E_Existing', 'Attachment_E_Proposed', 'Comments', \
                'Physical Status', 'Inventory Status Code', 'Longitude', 'Latitude', 'Object ID', 'Structure Name', 'Structure ID',\
                'Pole Number', 'Treatment Type', 'Diameter', 'Foundation Type', 'Grounded', 'Year Manufactured', 'Installation Date',\
                'Cable Owner Contact Number', 'Symbol Rotation', 'IPID', 'Contract Number', 'Global ID', 'Shape', 'ID',\
                'Create Work Order ID', 'Edit Work Order ID', 'Level Begin', 'Level End', 'Num Levels', 'Level Mapping', 'Group ID', \
                'Serving Feature ID', 'Planning ID', 'Is Delete', 'Timestamp', 'Clone Type', 'Is Planning', 'Edit Tracking Date', 'Edit Tracking User', 'Pole Change Out']'''
            df.columns= df.columns.str.lower().str.replace(' ', '_', regex=False)
            #df= df.drop(['infinium_id', 'fireworks_project_number'], axis = 1)
            if all(i not in agol for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                df = df[(df['pole_owner'] != 'ATT')]
            else:
                df = df[(df['pole_owner'] == 'ATT')]
            #agol_db = pd.concat([agol_db, df], join='inner')
            agol_zdb = df[[col for col in agol_cols if col in df.columns]]
            agol_db = pd.concat([agol_db, agol_zdb], axis=0).reset_index(drop=True)
            
            df = pd.read_excel(f'{dir}\\{node}')
            df.columns = df.columns.str.lower().str.replace(' ', '_', regex=False)
            if all(i not in node for i in ['ATT', 'AT&T', 'PLA', 'SOUTHERN PINE']):
                df = df[(df['pole_owner'] != 'ATT')]
            else:
                df = df[(df['pole_owner'] == 'ATT')]
            df = df[(df['node_type'] == 'pole')]
            #node_db = pd.concat([node_db, df],join='inner')
            node_zdb = df[[col for col in node_cols if col in df.columns]]
            node_db = pd.concat([node_db, node_zdb], axis = 0).reset_index(drop=True)
            zObject.close() 

        #agol_db['mre_grade'] =agol_db['mre_grade'].fillna('')
        #agol_db['mre_grade'] = agol_db['mre_grade'].apply(lambda x: 'Simple MR' if 'Communications' in x else 'Power MR' if 'Light Power' in x else 'Pole Replacement' if 'Heavy Power' in x else 'No MR' if 'No Make Ready' in x else x)
        agol_db['stub_pole_transfer'] = agol_db['stub_pole_transfer'].fillna('false')
        
        '''columns_to_convert = ['attachment_a_existing', 'attachment_a_proposed', 
                        'attachment_b_existing', 'attachment_b_proposed',
                        'attachment_c_existing', 'attachment_c_proposed',
                        'number_of_attachments', 'low_power_attachment']
        agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)'''
        try:
            columns_to_convert =  ['attachment_a_existing', 'attachment_a_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_b_existing', 'attachment_b_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_c_existing', 'attachment_c_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_d_existing', 'attachment_d_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_e_existing', 'attachment_e_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_f_existing', 'attachment_f_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_g_existing', 'attachment_g_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_h_existing', 'attachment_h_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_i_existing', 'attachment_i_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
            columns_to_convert =  ['attachment_j_existing', 'attachment_j_proposed']
            agol_db[columns_to_convert] = agol_db[columns_to_convert].astype(str)
        except:
            pass
        #dbox.append(str(df['mre_grade']))
        # join node node_id data to agol data using lat/longs
        #nf = pd.read_excel(f'{dir}\\{node}')
        #dbox.append(str(nf.columns.to_list()))
        '''['node_id', 'latitude', 'longitude', 'feedback', 'scid', 'node_type', 'pole_owner', 'oncor_tag', 'done', 'field_completed',\
            'flag_for_review', 'infinium_ID', 'internal_note', 'make_ready_notes', 'make_ready_type', 'mr_state', 'note', 'pole_class',\
            'pole_height', 'pole_owner.1', 'pole_spec', 'verify_location_in_field', 'time_bucket_start', 'time_bucket_stop', 'time_bucket_user',\
            'time_bucket_start_2', 'time_bucket_stop_2', 'time_bucket_user_2', 'time_bucket_start_3', 'time_bucket_stop_3', 'time_bucket_user_3',\
            'photo_count', 'main_photo', 'all_photos']'''
        #dfnf = pd.merge(agol_db, node_db, left_on=['latitude', 'longitude'], right_on = ['latitude', 'longitude'], how='left')
        dfnf = pd.merge(agol_db, node_db,  on='node_id', how='outer')
        dfnf['joined'] = 'True'
        dfnf['joined'] = 'True'
        dfnf['data_source'] = f'Katapult Update {datetime.now().strftime("%x")}'
        dfnf['height'] = dfnf['height'].astype(str)
        dfnf['class'] = dfnf['class'].astype(str)
        for col in agol_cols:
            if col not in dfnf.columns:
                dfnf[col] = None
        for col in node_cols:
            if col not in dfnf.columns:
                dfnf[col] = None
        dfnf.replace('nan', pd.NA, inplace=True)
        dfnf = dfnf.where(pd.notnull(dfnf), None)
        dfnf = dfnf
        dfnf_count = len(dfnf)
        dfnf.to_excel(f'{dir}\\dfnf.xlsx', index=False)
        
        # define layers & convert xlsx to layer
        progressBar.setValue(15)
        #poles = project.mapLayersByName('Pole_KP_Reference_5_15_25')[0]
        poles = project.mapLayersByName('Pole')[0]
        #poles = project.mapLayersByName('temp')[0]
        csv_file = QgsVectorLayer(f'{dir}\\dfnf.xlsx', 'Katapult AGOL', 'ogr')
        QgsProject.instance().addMapLayer(csv_file)
        csv = project.mapLayersByName('Katapult AGOL')[0]
        # join katapult onto pole layer
        field_names = [field.name() for field in csv.fields()]
        node_field = 'node_id' if 'node_id' in field_names else 'node_id_x' if 'node_id_x' in field_names else 'node_id_y' if 'node_id_y' in field_names else None
        joinObject = QgsVectorLayerJoinInfo()
        
        joinObject.setJoinFieldName(node_field)
        joinObject.setTargetFieldName('node_id')
        joinObject.setJoinLayerId = csv.id()
        joinObject.setJoinLayer(csv)
        joinObject.setPrefix('k_')
        joinObject.setUsingMemoryCache(True)
        poles.addJoin(joinObject)
        dbox.append('Joined')
        # Select only rows affected by join
        selection = processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':'"k_joined" is not NULL','METHOD':0})['OUTPUT']
        selection_count = selection.selectedFeatureCount()
        dbox.append(f'{dfnf_count} Katapult Features: {selection_count} Joined Features')
        #
        '''if dfnf_count > selection_count:
            poles.removeJoin(csv.id())
            pts_from_tbl = processing.run("native:createpointslayerfromtable", {'INPUT':csv,'XFIELD':'longitude','YFIELD':'latitude','ZFIELD':'','MFIELD':'','TARGET_CRS':QgsCoordinateReferenceSystem('EPSG:4326'),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #join to nearest 15 ft buffer
            joined_lyr = processing.run("native:joinbynearest", {'INPUT':poles,'INPUT_2': pts_from_tbl ,'FIELDS_TO_COPY':[],'DISCARD_NONMATCHING':False,'PREFIX':'k_','NEIGHBORS':1,'MAX_DISTANCE':14.99996999999996,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            joined_n_not_1 = processing.run("qgis:selectbyexpression", {'INPUT':joined_lyr,'EXPRESSION':'"n" is not 1 or  (strpos("node_id",\'-\') is not 0 and "node_id" is not null)','METHOD':0})['OUTPUT']
            QgsProject.instance().addMapLayer(joined_n_not_1)
            dbox.append(errorFormat.format('Not all features joined. Joined layer created for node_id matching.'))
            return'''
        #
        # map the 
        progressBar.setValue(25)
        if poles.isEditable():
            poles.commitChanges()
        progressBar.setValue(30)    
        with edit(poles):
            poles.updateFields()
            for f in poles.selectedFeatures():
                if 'k_node_id' is not None:
                    #f['attach'] = f['k_attach'] if f['k_attach'] is not None else f['attach']
                    f['data_source'] = f['k_data_source']
                    f['attachment_a_owner'] = f['k_attachment_a_owner'] if f['k_attachment_a_owner'] not in [None, 'nan'] else f['attachment_a_owner']
                    f['attachment_a_existing'] = f['k_attachment_a_existing'] if f['k_attachment_a_existing'] not in [None, 'nan'] else f['attachment_a_existing']
                    f['attachment_a_proposed'] = f['k_attachment_a_proposed'] if f['k_attachment_a_proposed'] not in [None, 'nan'] else f['attachment_a_proposed']

                    f['attachment_b_owner'] = f['k_attachment_b_owner'] if f['k_attachment_b_owner']  not in [None, 'nan'] else f['attachment_b_owner']
                    f['attachment_b_existing'] = f['k_attachment_b_existing'] if f['k_attachment_b_existing'] not in [None, 'nan'] else f['attachment_b_existing']
                    f['attachment_b_proposed'] = f['k_attachment_b_proposed'] if f['k_attachment_b_proposed']  not in [None, 'nan'] else f['attachment_b_proposed']

                    f['attachment_c_owner'] = f['k_attachment_c_owner'] if f['k_attachment_c_owner']  not in [None, 'nan'] else f['attachment_c_owner']
                    f['attachment_c_existing'] = f['k_attachment_c_existing'] if f['k_attachment_c_existing'] not in [None, 'nan'] else f['attachment_c_existing']
                    f['attachment_c_proposed'] = f['k_attachment_c_proposed'] if f['k_attachment_c_proposed']  not in [None, 'nan'] else f['attachment_c_proposed']

                    f['attachment_d_owner'] = f['k_attachment_d_owner'] if f['k_attachment_d_owner'] not in [None, 'nan'] else f['attachment_d_owner']
                    f['attachment_d_existing'] = f['k_attachment_d_existing'] if f['k_attachment_d_existing'] not in [None, 'nan'] else f['attachment_d_existing']
                    f['attachment_d_proposed'] = f['k_attachment_d_proposed'] if f['k_attachment_d_proposed']  not in [None, 'nan'] else f['attachment_d_proposed']

                    f['attachment_e_owner'] = f['k_attachment_e_owner'] if f['k_attachment_e_owner'] not in [None, 'nan'] else f['attachment_e_owner']
                    f['attachment_e_existing'] = f['k_attachment_e_existing'] if f['k_attachment_e_existing']  not in [None, 'nan'] else f['attachment_e_existing']
                    f['attachment_e_proposed'] = f['k_attachment_e_proposed'] if f['k_attachment_e_proposed']  not in [None, 'nan'] else f['attachment_e_proposed']

                    f['attachment_f_owner'] = f['k_attachment_f_owner'] if f['k_attachment_f_owner']  not in [None, 'nan'] else f['attachment_f_owner']
                    f['attachment_f_existing'] = f['k_attachment_f_existing'] if f['k_attachment_f_existing']  not in [None, 'nan'] else f['attachment_f_existing']
                    f['attachment_f_proposed'] = f['k_attachment_f_proposed'] if f['k_attachment_f_proposed']  not in [None, 'nan'] else f['attachment_f_proposed']
                    
                    f['attachment_g_owner'] = f['k_attachment_g_owner'] if f['k_attachment_g_owner']  not in [None, 'nan'] else f['attachment_g_owner']
                    f['attachment_g_existing'] = f['k_attachment_g_existing'] if f['k_attachment_g_existing']  not in [None, 'nan'] else f['attachment_g_existing']
                    f['attachment_g_proposed'] = f['k_attachment_g_proposed'] if f['k_attachment_g_proposed']  not in [None, 'nan'] else f['attachment_g_proposed']

                    f['attachment_h_owner'] = f['k_attachment_h_owner'] if f['k_attachment_h_owner']  not in [None, 'nan'] else f['attachment_h_owner']
                    f['attachment_h_existing'] = f['k_attachment_h_existing'] if f['k_attachment_h_existing']  not in [None, 'nan'] else f['attachment_h_existing']
                    f['attachment_h_proposed'] = f['k_attachment_h_proposed'] if f['k_attachment_h_proposed']  not in [None, 'nan'] else f['attachment_h_proposed']

                    f['attachment_i_owner'] = f['k_attachment_i_owner'] if f['k_attachment_i_owner']  not in [None, 'nan'] else f['attachment_i_owner']
                    f['attachment_i_existing'] = f['k_attachment_i_existing'] if f['k_attachment_i_existing']  not in [None, 'nan'] else f['attachment_i_existing']
                    f['attachment_i_proposed'] = f['k_attachment_i_proposed'] if f['k_attachment_i_proposed']  not in [None, 'nan'] else f['attachment_i_proposed']

                    f['attachment_j_owner'] = f['k_attachment_j_owner'] if f['k_attachment_j_owner']  not in [None, 'nan'] else f['attachment_j_owner']
                    f['attachment_j_existing'] = f['k_attachment_j_existing'] if f['k_attachment_j_existing']  not in [None, 'nan'] else f['attachment_j_existing']
                    f['attachment_j_proposed'] = f['k_attachment_j_proposed'] if f['k_attachment_j_proposed']  not in [None, 'nan'] else f['attachment_j_proposed']
                    f['class'] = f['k_class'] if f['k_class'] not in [None, 'nan'] else f['class']
                    try:
                        f['height'] = f['k_height'] if f['k_height'] not in [None, 'nan'] else f['height']
                    except:
                        f['height'] = f['k_height_x'] if f['k_height_x'] not in [None, 'nan'] else f['height']
                    #f['mr_state'] = f['k_mre_grade'] if f['k_mre_grade'] not in [None, 'nan'] else f['mr_state']
                    f['make_ready_type'] = f['k_make_ready_type'] if f['k_make_ready_type'] not in [None, 'nan'] else f['mr_state']
                    f['no_attachments']= f['k_number_of_attachments'] if f['k_number_of_attachments'] not in [None, 'nan'] else f['no_attachments']
                    f['pole_tag'] = f['k_pole_number_power'] if f['k_pole_number_power'] not in [None, 'nan'] else f['pole_tag']
                    try:
                        f['internal_note'] = f['k_internal_note'] if f['k_internal_note'] not in [None, 'nan'] else f['internal_note']
                    except:
                        try:
                            f['internal_note'] = f['k_internal_note_x'] if f['k_internal_note_x'] not in [None, 'nan'] else f['internal_note']
                        except:
                            f['internal_note'] = f['k_internal_note_y'] if f['k_internal_note_y'] not in [None, 'nan'] else f['internal_note']
                    try:
                        f['pole_owner'] = f['k_pole_owner'] if f['k_pole_owner'] not in [None, 'nan'] else f['pole_owner']
                    except:
                        try:
                            f['pole_owner'] = f['k_pole_owner_x'] if f['k_pole_owner_x'] not in [None, 'nan'] else f['pole_owner']
                        except:
                            f['pole_owner'] = f['k_pole_owner_y'] if f['k_pole_owner_y'] not in [None, 'nan'] else f['pole_owner']
                    try:
                        f['riser_count'] = f['k_riser_count'] if f['k_riser_count']not in [None, 'nan'] else f['riser_count']
                    except:
                        f['riser_count'] = f['k_riser_count_x'] if f['k_riser_count_x']not in [None, 'nan'] else f['riser_count']
                    f['stub_pole_transfer'] = f['k_stub_pole_transfer'] if f['k_stub_pole_transfer']not in [None, 'nan'] else f['stub_pole_transfer']
                    try:
                        f['tree_trim'] = f['k_tree_trim'] if f['k_tree_trim'] not in [None, 'nan'] else f['tree_trim']
                    except:
                        f['tree_trim'] = f['k_tree_trim_x'] if f['k_tree_trim_x'] not in [None, 'nan'] else f['tree_trim']
                    poles.updateFeature(f)
        
                # remove the join
        poles.removeJoin(csv.id())
    
        QgsProject.instance().removeMapLayers( [csv.id()] )
        os.remove(f'{dir}\\{agol}')
        os.remove(f'{dir}\\{node}')
        
        dbox.append(validFormat.format(f'Vero Katault Import has been succesfully completed.'))
        progressBar.setValue(100)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {line_number}'))
    