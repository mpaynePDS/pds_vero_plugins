# -*- coding: utf-8 -*-
"""
Created on Tues DEC 2024
Vero BOM
@author: Marie Payne
"""
import os
import sys
from openpyxl import load_workbook
from datetime import datetime
from qgis.core import *
from qgis import processing

def __main__(bound, outputfolder, dbox, progressBar,errorFormat, warningFormat, validFormat):
    if outputfolder in [None, '']:
        dbox.append(errorFormat.format('Select an Output Location to continue.'))
        return
    progressBar.setValue(5)
    project = QgsProject.instance()
    #-------------------------------------------------------------------------------------
    # Set template
    #-------------------------------------------------------------------------------------
    here = os.path.dirname(os.path.abspath(__file__))
    template = os.path.join(here, 'vero_BOM_Estimator_v2.xlsx')
    wb = load_workbook(template)
    ws = wb["BOM Estimator"] #QTYs go in column F
    progressBar.setValue(10)
    #-------------------------------------------------------------------------------------
    # Read, Extract, and Evaluate Data
    #-------------------------------------------------------------------------------------
    """
    we only need feature counts, so there's no need to export or convert data.
    Use "select by location/expression" rather than "extract selected features" the extract 
    function will create a new layer and we don't want that here.
    """
    # Header
    ws['B1'] = datetime.now()
    project_name = bound['area_id']
    ws['B2'] = bound['wire_center'] +'-'+project_name
    
    #Layers
    progressBar.setValue(12)
    fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
    site = project.mapLayersByName('Site')[0]
    access_point = project.mapLayersByName('Access_Point')[0]
    fiber_cable= project.mapLayersByName('Fiber_Cable')[0]
    segment = project.mapLayersByName('Segments')[0]
    network_element = project.mapLayersByName('Network_Element')[0]
    pole = project.mapLayersByName('Pole')[0]
    splicing = project.mapLayersByName('Splicing')[0]
    progressBar.setValue(15)
    #filter selection to FDA area
    dbox.append(f"-----------------------\nProject Area: {bound['area_id']}\nOutput Folder: {outputfolder}")
    #Had to use 'select by attribute' becuase select by expression was not accepting f-strings or .format
    bound =   processing.run("native:extractbyexpression", {'INPUT':fda_boundary, 'EXPRESSION': f'"area_id" LIKE \'%{project_name}%\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
    #sites = processing.run("native:selectbylocation", {'INPUT':site,'PREDICATE':[0],'INTERSECT':bound,'METHOD':0})['OUTPUT']
    sites = processing.run("native:extractbylocation", {'INPUT': site,'PREDICATE':[0],'INTERSECT': bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    passings = processing.run("native:extractbyexpression", {'INPUT': sites,'EXPRESSION':'"ben_" is not NULL and "ben_" >= 1','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
    list_of_ben = QgsVectorLayerUtils.getValues(passings,'ben_')[0]
    total = 0
    for i in list_of_ben:
        total += int(i)
        
    ws['A3'] = total
    #ws['A3'] = passings.aggregate(QgsAggregateCalculator.Sum, "ben_")[0]
    progressBar.setValue(20)
    '''
    Splice Enclosures

    '''

    '''
    Access Points: Size= {1: 12x12x12, 2: 1324x18, 3: 24x36x24, 4: 30x48x24}
    '''
    access_points =  processing.run("native:extractbylocation", {'INPUT':access_point,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #x30x48x30 = processing.run("qgis:selectbyexpression", {'INPUT':access_points,'EXPRESSION':'represent_value("size") = \'30x48x30\'','METHOD':3})['OUTPUT']
    x30x48x30 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':'"size" = 5','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A25'] = x30x48x30.featureCount()
    x30x48x24 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':'"size" = 4','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #not in BOM
    x24x36x24 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':'"size" = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A26'] = x24x36x24.featureCount()
    progressBar.setValue(30)
    x13x24x18 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':'"size" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A27'] = x13x24x18.featureCount()
    x12x12x12 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':'"size" = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A28'] = x12x12x12.featureCount()
    progressBar.setValue(40)  
    
    #
    fiber_cables =  processing.run("native:extractbylocation", {'INPUT':fiber_cable,'PREDICATE':[0],'INTERSECT':bound, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
    progressBar.setValue(42)
    network_elements = processing.run("native:extractbylocation", {'INPUT':network_element,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    
    '''
    FC: Tags = {1:Bulk, 2:F2, 3:Fiber Equipment Tail, 4:Flex NAP}
    FC: Fibercount = {1: 2, 2: 4, 3: 6, 4: 8, 5: 12, 6:24 , 7: 48, 8: 96, 9: 144, 10: 288, 11: 432, 12:854}
    FC: Placement_type = {1: Aerial, 2: Direct Buried, 3: Indoor, 4: Underground}
    FC: Cable_category + {1: Distribution, 2: Drop 3: F1, 4: F2} 
    '''
    x24ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" in (1,4) and "fibercount" = 6','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack24_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 6 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack24_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 6 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack24_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 6 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack24 = (slack24_25.featureCount()*25) +  (slack24_100.featureCount()*100) + (slack24_160.featureCount()*160) 
    ws['A33'] = (x24ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack24)* 1.07#footage  + 7% adder
    progressBar.setValue(43)
    
    x48ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" in (1,4) and "fibercount" = 7','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack48_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 7 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack48_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 7 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack48_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 7 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack48 = (slack48_25.featureCount()*25) +  (slack48_100.featureCount()*100) + (slack48_160.featureCount()*160) 
    ws['A34'] = (x48ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack48)* 1.07#footage  + 7% adder
    progressBar.setValue(44)
    
    x96ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" in (1,4) and "fibercount" = 8','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack96_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 8 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack96_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 8 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack96_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 8 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack96 = (slack96_25.featureCount()*25) +  (slack96_100.featureCount()*100) + (slack96_160.featureCount()*160) 
    ws['A35'] = (x96ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack96)* 1.07#footage  + 7% adder
    progressBar.setValue(47)
    
    x144ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" in (1,4) and "fibercount" = 9','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack144_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 9 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack144_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 9 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack144_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 9 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack144 = (slack144_25.featureCount()*25) +  (slack144_100.featureCount()*100) + (slack144_160.featureCount()*160) 
    ws['A36'] = (x144ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]+totalslack144)* 1.07#footage  + 7% adder
    progressBar.setValue(48)
   
    x288ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" in (1,4) and "fibercount" = 10','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack288_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 10 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack288_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 10 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack288_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 10 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack288 = (slack288_25.featureCount()*25) +  (slack288_100.featureCount()*100) + (slack288_160.featureCount()*160) 
    ws['A37'] = (x288ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack288)* 1.07#footage  + 7% adder
    
    x432ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" in (1,4) and "fibercount" = 11','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack432_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 11 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack432_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 11 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack432_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 3 and fiber_size = 11 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack432 = (slack432_25.featureCount()*25) +  (slack432_100.featureCount()*100) + (slack432_160.featureCount()*160) 
    
    ws['A38'] = (x432ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]+totalslack432)* 1.07#footage  + 7% adder
    progressBar.setValue(50)
    #duct_34 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"placement_type" = 4 and "cable_category" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT'] #eliminated on 1/14/25 per Alex Weitkamp
    
    #
    '''
    Segments: {1: 2:Aerial 3: 4: 5: 6: 7: 8: 9: Underground}
    '''
    try:
        segments =  processing.run("native:extractbylocation", {'INPUT':segment,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        progressBar.setValue(55)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format('Invalid Geometry.'))
        dbox.append(errorFormat.format(f'{e}, {line_number}'))

    '''
    Change Line 40 from 3/4" to 1.25"
    Duct total of 1 = total duct length on Line 40
    Duct total of 3 = total duct length on Line 41
    Duct total of 4 = total duct length on Line 40 and 41
    Duct total of 6 = total duct length times 2 on line 41
    Duct total of 7 = total duct length on line 40 and total duct length times 2 on line 41
    -  Kirk Corders email Fwd: GIS BOM Issue Pearsall, 6/5/2025
    '''
    line40 = 0
    line41 = 0

    duct_125_1 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    line40 += duct_125_1.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_1.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    
    duct_125_3 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    line41 += duct_125_3.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_3.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    
    duct_125_4 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 4','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    line40 += duct_125_4.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_4.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    line41 += duct_125_4.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_4.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    
    duct_125_6 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 6','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    line41 += 2 * duct_125_6.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_6.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    
    duct_125_7 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 7','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    line40 += duct_125_7.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_7.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    line41 += 2 * duct_125_7.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_125_7.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    
    ws['A40'] = line40
    ws['A41'] = line41
    progressBar.setValue(65)
    ''' Old calculation, no longer used as of 6/5/2025, see above for new calculation and notes.
    ws['A40'] = duct_34.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if duct_34.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0 
    progressBar.setValue(60)

    duct_125 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 9 and "duct_diameter" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A41'] = duct_125.aggregate(QgsAggregateCalculator.Sum, '"calculated_length" * "duct_count"')[0] if duct_125.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]  is not None else 0
    '''

    strand_14 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':'"segment_type" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A44'] = strand_14.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] if strand_14.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] is not None else 0
    progressBar.setValue(70)
    #
    '''
    Network Elements: {1: Anchor, 2: Riser, 3: Slack Coil}
    '''
    network_elements = processing.run("native:extractbylocation", {'INPUT':network_element,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    riser_uguard = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A68'] = riser_uguard.featureCount()*2
    ws['A97'] = riser_uguard.featureCount()
    progressBar.setValue(75)
    #
    splice_type = processing.run("native:extractbyexpression", {'INPUT':splicing,'EXPRESSION':'"type" = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT'] #type=3 = splice
    splices = processing.run("native:extractbylocation", {'INPUT':splice_type,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #
    BGEL =  processing.run("native:extractbyexpression", {'INPUT':splices,'EXPRESSION':'"material" = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT'] #material = 1 = BGEL
    
    DGEL =  processing.run("native:extractbyexpression", {'INPUT':splices,'EXPRESSION':'"material" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT'] #material = 2 = DGEL
    #FC96down = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"fibercount" <= 8','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #splices96down = processing.run("native:extractbylocation", {'INPUT':splices,'PREDICATE':[0],'INTERSECT': FC96down,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A16'] = BGEL.featureCount()
    #FC97up = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"fibercount" > 8','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #splices97up = processing.run("native:extractbylocation", {'INPUT':splices,'PREDICATE':[0],'INTERSECT':FC97up,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A18'] = DGEL.featureCount()
    progressBar.setValue(80)
    #
    anchors = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A66'] = anchors.featureCount()
    #
    grouped_fibers = processing.run("qgis:statisticsbycategories", {'INPUT':fiber_cables,'VALUES_FIELD_NAME':'calculated_length','CATEGORIES_FIELD_NAME':['cable_name'],'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    progressBar.setValue(81)
    #QgsProject.instance().addMapLayer(layer['OUTPUT'], False)
    MST_4_50 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,       'EXPRESSION':'"cable_name" LIKE \'%4F/%\' and "cable_name" LIKE \'%MST%\'  and "sum" <= 50','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A77']  = MST_4_50.featureCount()
    MST_8_50 =  processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name"  LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and "sum" <= 50','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A78']  = MST_8_50.featureCount()
    MST_12_50 =  processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and "sum" <= 50','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A79']  = MST_12_50.featureCount()
    progressBar.setValue(84)
    MST_4_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%4F/%\'  and "cable_name" LIKE \'%MST%\'  and 50 <"sum" and "sum" <= 500','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A80']  = MST_4_500.featureCount()
    MST_8_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and 50 <"sum" and "sum"<= 500','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A81']  = MST_8_500.featureCount()
    MST_12_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and 50 <"sum" and "sum"<= 500','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A82']  = MST_12_500.featureCount()
    progressBar.setValue(87)
    MST_4_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%4F/%\'  and "cable_name" LIKE \'%MST%\'  and 500 <"sum" and "sum"<= 1000','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A83']  = MST_4_1000.featureCount()
    MST_8_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and 500 <"sum" and "sum"<= 1000','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A84']  = MST_8_1000.featureCount()
    MST_12_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name" LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and 500 <"sum" and "sum"<= 1000','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A85']  = MST_12_1000.featureCount()
    progressBar.setValue(90)

    
    progressBar.setValue(95)
    '''
    Splicing: type = {1: FTP, 2: MST, 3: Splice}
    '''
    poles =  processing.run("native:extractbylocation", {'INPUT':pole,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_splicing = processing.run("native:extractbylocation", {'INPUT': splicing,'PREDICATE':[0],'INTERSECT': poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_AE = processing.run("native:extractbyexpression", {'INPUT':AE_splicing,'EXPRESSION':'"type" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A86'] = MST_AE.featureCount()
    progressBar.setValue(99)

    wb.save(f'{outputfolder}\\{project_name}-LLD BOM Estimator.xlsx')
    dbox.append(f'Output File: {outputfolder}\\{project_name}-LLD BOM Estimator.xlsx')
    dbox.append(validFormat.format(f'Vero BOM Estimator has been succesfully completed.'))
    progressBar.setValue(100)




