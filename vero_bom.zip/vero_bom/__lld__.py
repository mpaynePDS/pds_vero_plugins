# -*- coding: utf-8 -*-
"""
Created on Tues DEC 2024
Vero BOM
@author: Marie Payne
"""
import os
import sys
import math
from openpyxl import load_workbook
from datetime import datetime
from qgis.core import *
from qgis import processing
def __lld__(bound, outputfolder, dbox, progressBar,errorFormat, warningFormat, validFormat):
    if outputfolder in [None, '']:
        dbox.append(errorFormat.format('Select an Output Location to continue.'))
        return
    progressBar.setValue(5)
    project = QgsProject.instance()
    #-------------------------------------------------------------------------------------
    # Set template
    #-------------------------------------------------------------------------------------
    here = os.path.dirname(os.path.abspath(__file__))
    template = os.path.join(here, 'BOM Formulas_v10.xlsx')
    wb = load_workbook(template)
    ws = wb["BOM Estimator"] #QTYs go in column F
    progressBar.setValue(10)
    #-------------------------------------------------------------------------------------
    # Read, Extract, and Evaluate Data
    #-------------------------------------------------------------------------------------
    """
    we only need feature counts, so there's no need to export or convert data.
    Use "select by location/expression" rather than "extract selected features" the extract 
    function will create a new layer and we don't want that here.
    """
    # Header
    ws['B1'] = datetime.now()
    project_name = bound['area_id']
    if bound['wire_center'] in [None, '']:
        dbox.append(warningFormat.format('Warning: "wire_center" is required for cell B2.'))
        ws['B2'] = project_name
    else:
        ws['B2'] = bound['wire_center'] +'-'+project_name
    #Layers
    progressBar.setValue(12)
    fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
    site = project.mapLayersByName('Site')[0]
    access_point = project.mapLayersByName('Access_Point')[0]
    fiber_cable= project.mapLayersByName('Fiber_Cable')[0]
    segment = project.mapLayersByName('Segments')[0]
    network_element = project.mapLayersByName('Network_Element')[0]
    pole = project.mapLayersByName('Pole')[0]
    unfielded_pole = project.mapLayersByName("Unfielded_Pole")[0]
    splicing = project.mapLayersByName('Splicing')[0]
    progressBar.setValue(15)
    #filter selection to FDA area
    dbox.append(f"-----------------------\nProject Area: {bound['area_id']}\nOutput Folder: {outputfolder}")
    if any(x in bound['area_id'] for x in ['F0', 'F1']) or any(x in bound['fda_name'] for x in ['F0', 'F1']):
        F2 = False
    else:
        F2 = True
    segment_id = bound['segment_id']
    try:
        dbox.append(segment_id)
    except TypeError:
        dbox.append(errorFormat.format('Error: No Segment ID.'))
        return          
    #initial data extraction by bound
    try:
        bound =   processing.run("native:extractbyexpression", {'INPUT':fda_boundary, 'EXPRESSION': f'"area_id" LIKE \'%{project_name}%\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        poles =  processing.run("native:extractbylocation", {'INPUT':pole,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        sites = processing.run("native:extractbylocation", {'INPUT': site,'PREDICATE':[0],'INTERSECT': bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        splices =  processing.run("native:extractbylocation", {'INPUT':splicing,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        access_points =  processing.run("native:extractbylocation", {'INPUT':access_point,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        fiber_cables =  processing.run("native:extractbylocation", {'INPUT':fiber_cable,'PREDICATE':[0],'INTERSECT':bound, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        segments =  processing.run("native:extractbylocation", {'INPUT':segment,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        network_elements = processing.run("native:extractbylocation", {'INPUT':network_element,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        unfielded_poles = processing.run("native:extractbylocation", {'INPUT':unfielded_pole,'PREDICATE':[0],'INTERSECT':bound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}')) 
        return


        
    passings = processing.run("native:extractbyexpression", {'INPUT': sites,'EXPRESSION':'"ben_" is not NULL and "ben_" >= 1','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
    list_of_ben = QgsVectorLayerUtils.getValues(passings,'ben_')[0]
    total = 0
    for i in list_of_ben:
        total += int(i)
    ws['A3'] = total
    #ws['A3'] = passings.aggregate(QgsAggregateCalculator.Sum, "ben_")[0]
    
    progressBar.setValue(20)
    '''Panel & Cabinets'''
    #Panel 48, 144, 288, 432; 1 per size cable at Headend (F0 only)
    if F2:
        ws['A7'] = 0
        ws['A8'] = 0
        ws['A9'] = 0
        ws['A10'] = 0
        ws['A11'] = 1
        ws['A12'] = 1
        ws['A13'] = 5
    else: #is F0 or F1
        pass
    ftp_576 =  processing.run("native:extractbyexpression", {'INPUT':splices, 'EXPRESSION':f'"type" = 1 and "subtype" = 3 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #ws['A11'] = ftp_576.featureCount()
    ftp_432 =  processing.run("native:extractbyexpression", {'INPUT':splices, 'EXPRESSION':f'"type" = 1 and "subtype" = 8 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ftp_288 =  processing.run("native:extractbyexpression", {'INPUT':splices, 'EXPRESSION':f'"type" = 1 and "subtype" = 9 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    '''
    Splice Enclosures- Material{1: BGEL-450, 2:DGEL-450}
    '''
    bGEL =  processing.run("native:extractbyexpression", {'INPUT':splices, 'EXPRESSION':f'"material" = 1 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    dGEL = processing.run("native:extractbyexpression", {'INPUT':splices, 'EXPRESSION':f'"material" = 2 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    bgel_trays = 0
    dgel_trays = 0
    for  f in bGEL.getFeatures():
        if f['spliced_fibers'] not in [None, '']:
            bgel_trays += math.ceil(int(f['spliced_fibers'])/24)
    for f in dGEL.getFeatures():
        if f['spliced_fibers'] not in [None, '']:
            dgel_trays += math.ceil(int(f['spliced_fibers'])/72)
    ws['A16'] = bGEL.featureCount()
    ws['A17'] = bgel_trays
    ws['A18'] = dGEL.featureCount()
    ws['A20'] = dgel_trays
    ws['A19'] = 1 if F2 else 0
    
    '''
    Splicing: type = {1: FTP, 2: MST, 3: Splice} , tags(subtype) = {5: MCA, 6: RE}
    '''
    AE_splicing = processing.run("native:extractbylocation", {'INPUT': splicing,'PREDICATE':[0],'INTERSECT': poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    UG_splicing = processing.run("native:extractbylocation", {'INPUT': splicing,'PREDICATE':[0],'INTERSECT': access_points,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_AE = processing.run("native:extractbyexpression", {'INPUT':AE_splicing,'EXPRESSION':f'"type" = 2 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_UG = processing.run("native:extractbyexpression", {'INPUT':UG_splicing,'EXPRESSION':f'"type" = 2 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    REMCA_UG = processing.run("native:extractbyexpression", {'INPUT':UG_splicing,'EXPRESSION':f'"tags" in (5, 6) and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    REMCA_AE = processing.run("native:extractbyexpression", {'INPUT':AE_splicing,'EXPRESSION':f'"tags" in (5, 6) and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A22'] = REMCA_AE.featureCount()
    ws['A30'] = REMCA_UG.featureCount()
    ws['A45'] = MST_UG.featureCount()
    ws['A94'] = MST_AE.featureCount()
    '''
    Access Points: Size= {1: 12x12x12, 2: 1324x18, 3: 24x36x24, 4: 30x48x24}
    '''
    #x30x48x36 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':f'"size" = 6 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    x30x48x30 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':f'"size" = 5 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A26'] = x30x48x30.featureCount()
    #x30x48x24 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':f'"size" = 4 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    x24x36x24 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':f'"size" = 3 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A27'] = x24x36x24.featureCount()
    progressBar.setValue(30)
    x13x24x18 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':f'"size" = 2 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A28'] = x13x24x18.featureCount()
    x12x12x12 = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':f'"size" = 1 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A29'] = x12x12x12.featureCount()
    progressBar.setValue(40)  
    '''
    Total Fiber Optic Cable Lengths. FC + slack + 5% adder, round up
    FC: Tags = {1:Bulk, 2:F2, 3:Fiber Equipment Tail, 4:Flex NAP}
    FC: Fibercount = {1: 2, 2: 4, 3: 6, 4: 8, 5: 12, 6:24 , 7: 48, 8: 96, 9: 144, 10: 288, 11: 432, 12:854}
    FC: Placement_type = {1: Aerial, 2: Direct Buried, 3: Indoor, 4: Underground}
    FC: Cable_category + {1: Distribution, 2: Drop 3: F1, 4: F2} 
    '''
    #
    progressBar.setValue(42)
    slacks = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_slacks = processing.run("native:extractbylocation", {'INPUT':slacks,'PREDICATE':[0],'INTERSECT':poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_slacks_160 = processing.run("native:extractbyexpression", {'INPUT':AE_slacks,'EXPRESSION':f'"size" = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT'] # 3= 160
    AE_slacks_poles = processing.run("native:extractbylocation", {'INPUT':poles,'PREDICATE':[0],'INTERSECT':AE_slacks_160,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A52'] = (2*AE_slacks_poles.featureCount())+REMCA_AE.featureCount()
    #x24ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':f'"tags" in (1,4) and "fibercount" = 6','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #slack24_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 6 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #slack24_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 6 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #slack24_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 6 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #totalslack24 = (slack24_25.featureCount()*25) +  (slack24_100.featureCount()*100) + (slack24_160.featureCount()*160) 
    #ws['A34'] = math.ceil((x24ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack24)* 1.05)#footage  + 5 adder
    #progressBar.setValue(43)
    
    x48ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':f'"tags" in (1,4) and "fibercount" = 7 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack48_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 7 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack48_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 7 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack48_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 7 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack48 = (slack48_25.featureCount()*25) +  (slack48_100.featureCount()*100) + (slack48_160.featureCount()*160) 
    ws['A35'] = math.ceil((x48ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack48)* 1.05)#footage  + 5% adder
    progressBar.setValue(44)
    
    x96ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':f'"tags" in (1,4) and "fibercount" = 8 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack96_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 8 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack96_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 8 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack96_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 8 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack96 = (slack96_25.featureCount()*25) +  (slack96_100.featureCount()*100) + (slack96_160.featureCount()*160) 
    ws['A36'] = math.ceil((x96ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack96)* 1.05)#footage  +5% adder
    progressBar.setValue(47)
    
    x144ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':f'"tags" in (1,4) and "fibercount" = 9 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack144_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 9 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack144_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 9 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack144_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 9 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack144 = (slack144_25.featureCount()*25) +  (slack144_100.featureCount()*100) + (slack144_160.featureCount()*160) 
    ws['A37'] = math.ceil((x144ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]+totalslack144)* 1.05)#footage  + 5% adder
    progressBar.setValue(48)
   
    x288ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':f'"tags" in (1,4) and "fibercount" = 10 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack288_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 10 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack288_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 10 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack288_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 10 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack288 = (slack288_25.featureCount()*25) +  (slack288_100.featureCount()*100) + (slack288_160.featureCount()*160) 
    ws['A38'] = math.ceil((x288ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + totalslack288)* 1.05)#footage  + 5% adder
    progressBar.setValue(49)

    x432ct = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':f'"tags" in (1,4) and "fibercount" = 11 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack432_25 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 11 and size = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack432_100 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 11 and size = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    slack432_160 = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 3 and fiber_size = 11 and size = 3','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    totalslack432 = (slack432_25.featureCount()*25) +  (slack432_100.featureCount()*100) + (slack432_160.featureCount()*160) 
    ws['A39'] = math.ceil((x432ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]+totalslack432)* 1.05)#footage  + 5% adder
    progressBar.setValue(50)
    sum_FC = x48ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + x96ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] + x144ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]+x288ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]+x432ct.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    #duct_34 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"placement_type" = 4 and "cable_category" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT'] #eliminated on 1/14/25 per Alex Weitkamp
    
    #
    '''
    Segments: {1: 2:Aerial 3: 4: 5: 6: 7: 8: 9: Underground}
    Line 42 = Length of conduits (One duct + 2(Two duct) + Four duct + 2(Five duct) + Seven duct+ 2(Eight duct)) with segment ID + 8% adder round up
    Line 43 = Length of conduits (Three duct + Four duct + Five duct + 2(Six duct) + 2(Seven duct) + 2(Eight duct) + 3(Nine duct)) with segment ID + 8% adder round up

    '''

    line42 = 0
    line43 = 0

    duct_125_1 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 1 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_1.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line42 +=  sum_length if sum_length is not None else 0 
    
    duct_125_2 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 2 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_2.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line42 += 2 * sum_length if sum_length is not None else 0 
    
    duct_125_3 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 3 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_3.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line43 += sum_length if sum_length is not None else 0

    duct_125_4 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 4 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_4.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line42 += sum_length if sum_length is not None else 0 
    line43 += sum_length if sum_length is not None else 0 
    
    duct_125_5 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 5 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_5.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line42 += 2 * sum_length if sum_length is not None else 0 
    line43 += sum_length if sum_length is not None else 0 

    duct_125_6 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 6 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length =  duct_125_6.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line43 += 2 * sum_length
    
    duct_125_7 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 7 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_7.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line42 += sum_length if sum_length is not None else 0 
    line43 += 2 * sum_length if sum_length is not None else 0 
    
    duct_125_8 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 8 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_8.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line42 += 2 *  sum_length if sum_length is not None else 0 
    line43 += 2 *  sum_length if sum_length is not None else 0 

    duct_125_9 = processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "duct_diameter" = 2 and "duct_count" = 9 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = duct_125_9.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0]
    line43 += 3 * sum_length if sum_length is not None else 0 

    ws['A42'] = math.ceil(line42 * 1.08) #8% adder, round up
    ws['A43'] = math.ceil(line43 * 1.08) #8% adder, round up
    progressBar.setValue(65)


    '''
    Network Elements: {1: Anchor, 2: Riser, 3: Slack Coil} & Segments
    '''
    AE_segments= processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 2 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    UG_segments= processing.run("native:extractbyexpression", {'INPUT':segments,'EXPRESSION':f'"segment_type" = 9 and "segment_id" = \'{segment_id}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

    anchors = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':'"element_type" = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    sum_length = AE_segments.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] 
    
    ws['A46'] = round((sum_length if sum_length is not None else 0) + (anchors.featureCount()*25),1)#Dylan says 1 down guy per anchor 9/24/25
    ws['A47'] = round((sum_length /600 if sum_length is not None else 0),1)
    ws['A61'] = anchors.featureCount()
    progressBar.setValue(70)#Network Elements will not use segment_id filter because that field is not filled out in that layer. Per video discussion of BOM formulas with Dylan Farmer on 9/24/2025 
    riser = processing.run("native:extractbyexpression", {'INPUT':network_elements,'EXPRESSION':f'"element_type" = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A105'] = riser.featureCount()
    progressBar.setValue(75)
    
    '''
    MSTs: Fiber cable is grouped by name in order to calculate the sum of the individual segment lengths for each cable_name. 
    '''
    grouped_fibers = processing.run("qgis:statisticsbycategories", {'INPUT':fiber_cables,'VALUES_FIELD_NAME':'calculated_length','CATEGORIES_FIELD_NAME':['cable_name'],'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_Fibers = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"cable_name" LIKE \'%MST%\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    progressBar.setValue(81)
    #QgsProject.instance().addMapLayer(layer['OUTPUT'], False)
    MST_4 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,       'EXPRESSION':'"cable_name" LIKE \'%4F/%\' and "cable_name" LIKE \'%MST%\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_8 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,       'EXPRESSION':'"cable_name" LIKE \'%8F/%\' and "cable_name" LIKE \'%MST%\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_12 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,       'EXPRESSION':'"cable_name" LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_X_50 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,       'EXPRESSION':'"cable_name" LIKE \'%MST%\'  and "sum" <= 40','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_X_100 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%MST%\'  and 40 <"sum" and "sum" <= 60','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_X_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%MST%\'  and 60 <"sum" and "sum" <= 400','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_X_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name" LIKE \'%MST%\'  and 400 <"sum" and "sum"<= 900','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    MST_X_1500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name" LIKE \'%MST%\'  and 900 <"sum" and "sum"<= 1350','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    
    MST_4_50 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,       'EXPRESSION':'"cable_name" LIKE \'%4F/%\' and "cable_name" LIKE \'%MST%\'  and "sum" <= 40','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A79'] = MST_4_50.featureCount()
    MST_8_50 =  processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name"  LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and "sum" <= 40','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A80']  = MST_8_50.featureCount()
    MST_12_50 =  processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and "sum" <= 40','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A81']  = MST_12_50.featureCount()
    progressBar.setValue(82)
    MST_4_100 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%4F/%\'  and "cable_name" LIKE \'%MST%\'  and 40 <"sum" and "sum" <= 60','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A82']  = MST_4_100.featureCount()
    MST_8_100 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and 40 <"sum" and "sum"<= 60','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A83']  = MST_8_100.featureCount()
    MST_12_100 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and 40 <"sum" and "sum"<= 60','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A84']  = MST_12_100.featureCount()
    progressBar.setValue(84)
    MST_4_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%4F/%\'  and "cable_name" LIKE \'%MST%\'  and 60 <"sum" and "sum" <= 400','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A85']  = MST_4_500.featureCount()
    MST_8_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,      'EXPRESSION':'"cable_name" LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and 60 <"sum" and "sum"<= 400','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A86']  = MST_8_500.featureCount()
    MST_12_500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and 60 <"sum" and "sum"<= 400','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A87']  = MST_12_500.featureCount()
    progressBar.setValue(87)
    MST_4_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%4F/%\'  and "cable_name" LIKE \'%MST%\'  and 400 <"sum" and "sum"<= 900','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A88']  = MST_4_1000.featureCount()
    MST_8_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and 400 <"sum" and "sum"<= 900','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A89']  = MST_8_1000.featureCount()
    MST_12_1000 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name" LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and 400 <"sum" and "sum"<= 900','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A90']  = MST_12_1000.featureCount()
    progressBar.setValue(90)
    MST_4_1500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%4F/%\'  and "cable_name" LIKE \'%MST%\'  and 900 <"sum" and "sum"<= 1350','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A91']  = MST_4_1500.featureCount()
    MST_8_1500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name"  LIKE \'%8F/%\'  and "cable_name" LIKE \'%MST%\'  and 900 <"sum" and "sum"<= 1350','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A92']  = MST_8_1500.featureCount()
    MST_12_1500 = processing.run("native:extractbyexpression", {'INPUT':grouped_fibers,     'EXPRESSION':'"cable_name" LIKE \'%12F/%\' and "cable_name" LIKE \'%MST%\'  and 900 <"sum" and "sum"<= 1350','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A93']  = MST_12_1500.featureCount()
    #Combined total quantity of fiber cable and tails
    #MST_FT_Total =  (MST_X_50.featureCount()*50) + (MST_X_100.featureCount()*100) + (MST_X_500.featureCount()*500) + (MST_X_1000.featureCount()*1000) + (MST_X_1500.featureCount()*1500)
    MST_FT_Total = MST_Fibers.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] 
    ws['A102'] = math.ceil(sum_FC + MST_FT_Total)
    #Total of ports on all MSTs
    ws['A103'] = (MST_4.featureCount()*4) + (MST_8.featureCount()*8) + (MST_12.featureCount()*12)
    #Total of MST footage, rounded by category
    ws['A104'] = round(MST_FT_Total, 1)
    progressBar.setValue(93)

    '''
    Drops, cable_category 2 = Drops, placement_type 2 = AE, 4 = UG
    '''
    AE_Drops_190 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2) and "placement_type" = 1 and "calculated_length"<=190','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_Drops_340 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2) and "placement_type" = 1 and 190<"calculated_length" and "calculated_length"<=340','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_Drops_500 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"tags" = 5 and "placement_type" = 1 and 340<"calculated_length" and "calculated_length"<=500','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    
    UG_Drops_140 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2) and "placement_type" = 4 and "calculated_length" and "calculated_length"<=140','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    UG_Drops_240 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2) and "placement_type" = 4 and 140<"calculated_length" and "calculated_length"<=240','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    UG_Drops_350 = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2) and "placement_type" = 4 and 240<"calculated_length" and "calculated_length"<=350','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_Drops = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2) and "placement_type" = 1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    All_Drops = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'("tags" = 5 or "cable_category" = 2 or "fibercount"=1)','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    Drops_2UG = processing.run("native:extractbyexpression", {'INPUT':fiber_cables,'EXPRESSION':'"fibercount" = 1 and "placement_type" = 4 ','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    buff_conduit = processing.run("native:buffer", {'INPUT': UG_segments,'DISTANCE':0.0032808333333333244,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    drops_difference = processing.run("native:difference", {'INPUT':Drops_2UG,'OVERLAY':buff_conduit,'OUTPUT':'TEMPORARY_OUTPUT','GRID_SIZE':None})['OUTPUT']
    distance_calculator = QgsDistanceArea()
    distance_calculator.setEllipsoid('WGS84')  # Or use your project's ellipsoid
    distance_calculator.setSourceCrs(drops_difference.crs(), QgsProject.instance().transformContext())

    with edit(drops_difference):
        for f in drops_difference.getFeatures():
            geodesic_length = distance_calculator.measureLength(f.geometry())
            f.setAttribute(f.fieldNameIndex('calculated_length'), geodesic_length*3.28084)
            drops_difference.updateFeature(f)
    drops_difference.commitChanges()
    ws['A41'] = math.ceil(drops_difference.aggregate(QgsAggregateCalculator.Sum, "calculated_length")[0] )
    #Drops intersecting pole
    poles_drop = processing.run("native:extractbylocation", {'INPUT': poles ,'PREDICATE':[0],'INTERSECT': All_Drops,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #drop_only_unfielded = processing.run("native:extractbyexpression", {'INPUT':unfielded_poles,'EXPRESSION': '"drop_pole" ilike \'%Drop_Pole%\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    drop_only_unfielded = processing.run("native:extractbylocation", {'INPUT': unfielded_poles ,'PREDICATE':[0],'INTERSECT': All_Drops,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    AE_Drops_Poles = processing.run("native:extractbylocation", {'INPUT': AE_Drops ,'PREDICATE':[0],'INTERSECT': poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    #Poles with drops snapped
    #ws['A14'] = math.ceil(All_Drops.featureCount()*0.4)
    ws['A25'] = 2*(poles_drop.featureCount() + drop_only_unfielded.featureCount())
    ws['A76'] = poles_drop.featureCount() + drop_only_unfielded.featureCount()
    ws['A77'] = AE_Drops.featureCount()#AE_Drops_Poles.featureCount()

    ws['A95'] = math.ceil(AE_Drops_190.featureCount() * 0.4)
    ws['A96'] = math.ceil(AE_Drops_340.featureCount() * 0.4)
    ws['A97'] = math.ceil(AE_Drops_500.featureCount() * 0.4)

    ws['A98']= math.ceil(UG_Drops_140.featureCount() * 0.4)
    ws['A99']= math.ceil(UG_Drops_240.featureCount() * 0.4)
    ws['A100']= math.ceil(UG_Drops_350.featureCount() * 0.4)


    progressBar.setValue(95)

    '''
    Poles & Things Attached to Poles... like Anchors and Fiber
    '''
    #processing.run("native:extractbylocation", {'INPUT': splicing,'PREDICATE':[0],'INTERSECT': poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    attach_poles = processing.run("native:extractbyexpression", {'INPUT':poles,'EXPRESSION':'"attach" in (\'Yes\', \'yes\')','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    non12x12HH = processing.run("native:extractbyexpression", {'INPUT':access_points,'EXPRESSION':'"size" not in (1)','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    ws['A40'] = attach_poles.featureCount() + non12x12HH.featureCount()
    ws['A44'] = math.floor(access_points.featureCount() * 1.5)
    ws['A48'] = 2 * attach_poles.featureCount()
    ws['A73'] = round((attach_poles.featureCount()/10)/315, 3)

    # # of attach poles without splice closure or slack loops; First select all poles in layer, then remove from selection by intersections
    attach_poles.selectAll()
    processing.run("native:selectbylocation", {'INPUT':attach_poles,'PREDICATE':[0],'INTERSECT':slacks,'METHOD':3})#removing from current selection
    processing.run("native:selectbylocation", {'INPUT':attach_poles,'PREDICATE':[0],'INTERSECT':REMCA_AE,'METHOD':3})#removing from current selection
    ws['A75'] =  attach_poles.selectedFeatureCount()
    wb.save(f'{outputfolder}\\{project_name}-LLD BOM Actual.xlsx')
    dbox.append(f'Output File: {outputfolder}\\{project_name}-LLD BOM Actual.xlsx')
    dbox.append(validFormat.format(f'Vero BOM Estimator has been succesfully completed.'))
    progressBar.setValue(100)




