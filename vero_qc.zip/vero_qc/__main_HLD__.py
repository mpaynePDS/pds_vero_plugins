# -*- coding: utf-8 -*-
"""
Created on Tues Jan 28, 2025
Vero QC
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __main_HLD__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks, qcCheckButton, qcListWidget):
    try:
        dbox.append(f'HLD Started at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()
        existing_layer = QgsProject.instance().mapLayer('memory.gpkg')
        if existing_layer:
            QgsProject.instance().removeMapLayer(existing_layer)
        progressBar.setValue(1)
        # define AOI boundary + create output folder
        project_name = bound
        dbox.append(str(project_name)) 

        #--------------------
        qcChecks = [
            qcListWidget.item(i).text()
            for i in range(qcListWidget.count())
            if qcListWidget.item(i).checkState() == Qt.Checked
        ]
        proj_folder= f'{outputfolder}\\QC_{str(project_name)}'
        if not os.path.exists(proj_folder):
                os.mkdir(proj_folder)
        # layers
        fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
        access_pts = project.mapLayersByName('Access_Point')[0]
        fibercables = project.mapLayersByName('Fiber_Cable')[0]
        nap_boundary = project.mapLayersByName('NAP_Boundary')[0]
        network_elements = project.mapLayersByName('Network_Element')[0]
        poles = project.mapLayersByName('Pole')[0]
        segments = project.mapLayersByName('Segments')[0]
        sites = project.mapLayersByName('Site')[0]
        splicings = project.mapLayersByName('Splicing')[0]
        
        #--------------------------------------
        
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':fda_boundary, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        fda_name = None
        segment_id = None
        area_id = None
        wire_center = None
        for f in fda_boundary.selectedFeatures():
            if f['fda_name'] not in [None,'']:
                fda_name = f['fda_name']
            if f['segment_id'] not in [None, ''] and '-' in f['segment_id']:
                segment_id = f['segment_id']
            if f['area_id'] not in [None, '']:
                area_id = f['area_id']
            if f['wire_center'] not in [None, '']:
                wire_center = f['wire_center']
            break
        # Get F0 and F1 possible fda and segment id
        intersecting_bounds = processing.run("native:extractbylocation", {'INPUT':fda_boundary,'PREDICATE':[5],'INTERSECT':QgsProcessingFeatureSourceDefinition(fda_boundary.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        f0_dict = {}
        f1_dict = {}
        f1_f0_geoms = []
        for f in intersecting_bounds.getFeatures():
            if 'F0' in f['fda_name'] or 'F0' in f['area_id']:
                f0_dict[f['area_id']] = [f['segment_id'], f.geometry(), f['fda_name']]
                f1_f0_geoms.append(f.geometry())
            elif 'F1' in f['fda_name'] or 'F1' in f['area_id']:
                f1_dict[f['area_id']] = [f['segment_id'], f.geometry(), f['fda_name']]
                f1_f0_geoms.append(f.geometry())
        merged_f1f0 = QgsGeometry.unaryUnion(f1_f0_geoms)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}')) 
        return


    def _cab_():
        start_time = datetime.now()
        dbox.append('CABINET BOUNDARY CHECKS')
        dbox.append('____________________________________________________________________________________________')
        #
        sitesWithinBound = processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        ben_total = 0
        for f in sites.selectedFeatures():
            if f['ben_'] not in [None, ''] and isinstance(f['ben_'], int):
                ben_total += f['ben_']
        try:
            errorDict = {
                "Area_ID_Invalid": 0,
                "Segment ID Invalid": 0,
                "Wire Center Invalid": 0,
                "Wire Center Mismatch": 0,
                "FDA Name Invalid": 0,
                "FDA Name/Zone Mismatch": 0,
                "Hub Size Invalid": 0,
                "Estimated HHP Invalid":0,
                "Estimated HHP Mismatch":0
            }
            total = fda_boundary.selectedFeatureCount()
            if fda_boundary.isEditable():
                fda_boundary.commitChanges()
            with edit(fda_boundary):
                for idx, f in enumerate(fda_boundary.selectedFeatures(), 1):
                    f_errors = []
                    #
                    if f['area_id'] in [None, '']:
                        errorDict['Area ID Invalid'] += 1
                        f_errors.append("Area_ID_Invalid")
                    if f['segment_id'] in [None, ''] or '-' not in f['segment_id']:
                        if all(x not in f['fda_name'] for x in ['F0', 'F1']): #F0 and F1 will not not have segment ID
                            errorDict['Segment ID Invalid'] += 1
                            f_errors.append('Segment_ID_Invalid')
                    elif '-' in f['segment_id']: #F2 Zones
                        wirecenter = f['segment_id'].split('-')[0]
                        fda_name = f['segment_id'].split('-')[-1]
                        if f['wire_center'] in [None, '']:
                            errorDict['Wire Center Invalid'] += 1
                            f_errors.append('Wire_Center_Invalid')
                        '''elif f['wire_center'] != wirecenter:
                            errorDict['Wire Center Mismatch'] += 1     
                            f_errors.append('Wire_Center_Mismatch') '''
                        if f['fda_name'] in [None, ''] or not any(x in f['fda_name'] for x in ['F0', 'F1', 'ZONE']):
                            errorDict['FDA Name Invalid'] += 1
                            f_errors.append('FDA_Name_Invalid')
                        '''elif f['fda_name'] != fda_name:
                            errorDict['FDA Name/Zone Mismatch'] += 1
                            f_errors.append('FDA_Name/Zone_Mismatch')'''#Not possible
                    if f['hub_size'] in [None,''] or f['hub_size'] not in [2,3,4,288,432,576]:
                        errorDict['Hub Size Invalid'] += 1
                        f_errors.append('Hub_Size_Invalid')
                    if f['estimated_hhp'] in [None, ''] or not isinstance(int(f['estimated_hhp']), int):
                        errorDict['Estimated HHP Invalid'] += 1
                        f_errors.append('Estimated_HHP_Invalid')
                    elif int(f['estimated_hhp']) != ben_total:
                        errorDict['Estimated HHP Mismatch'] += 1
                        f_errors.append('Estimated_HHP_Mismatch')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    fda_boundary.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Cabinet boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def _access_points_():
        start_time = datetime.now()
        dbox.append('ACCESS POINTS CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':access_pts,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            errorDict = {
                "Segment ID Invalid": 0,
                "Hierarchy Invalid": 0,
                "Group Invalid": 0,
                "Type Mismatch":0,
                "Hierarchy/Geom Mismatch":0
            }            
            total = access_pts.selectedFeatureCount()
            if access_pts.isEditable():
                access_pts.commitChanges()
            with edit(access_pts):
                for idx, f in enumerate(access_pts.selectedFeatures(), 1):
                    f_errors = []   
                    if (f['type'] not in [None, 1, 2]):  #Cabinet = 1, Handhole = 2
                        errorDict['Type Mismatch'] += 1
                        f_errors.append('Type_Mismatch')
                    if f['hierarchy'] in [None, '']:
                        errorDict['Hierarchy Invalid'] += 1
                        f_errors.append('Hierarchy_Invalid')
                    else:
                        geom = f.geometry()
                        if f['hierarchy'] in [4,5,6,7]: #contains F0
                            f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                            f0_fda_name = next((f0_dict[x][2] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                            if f0_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if f['segment_id'] in [None, ''] or f['segment_id'] != f0_segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                                if f['group'] in [None, ''] or f['group'] != f0_fda_name:
                                    errorDict['Group Invalid'] += 1
                                    f_errors.append('Group_Invalid')
                        elif f['hierarchy'] in [1,3]: #contains F1:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            f1_fda_name = next((f1_dict[x][2] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if f['segment_id'] in [None, ''] or f['segment_id'] != f1_segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                                if f['group'] in [None, ''] or f['group'] != f1_fda_name:
                                    errorDict['Group Invalid'] += 1
                                    f_errors.append('Group_Invalid')
                        elif f['hierarchy'] == 2:
                            if geom.intersects(merged_f1f0):
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if fda_name is not None:
                                    if f['group'] is None or f['group'] != fda_name:
                                        errorDict['Group Invalid'] += 1
                                        f_errors.append('Group_Invalid')
                                if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    access_pts.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Access Points check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")

    def _sites_():
        start_time = datetime.now()
        dbox.append('SITE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            '''Every Site is within 410' of an Aerial segment or within 310' of an UG segment'''
            #extract and isolate sites and segments within the boundary
            boundSites = processing.run("native:extractbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #select segments within boundary
            processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            #split segments into aerial and underground
            seg_ae = processing.run("native:extractbyattribute", {'INPUT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'FIELD':'segment_type','OPERATOR':0,'VALUE':'2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            seg_ug =  processing.run("native:extractbyattribute", {'INPUT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'FIELD':'segment_type','OPERATOR':0,'VALUE':'9','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            # 410ft buffer on aerial segments
            seg_ae_buff = processing.run("native:buffer", {'INPUT':seg_ae,'DISTANCE':409.99917999999894,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            # 310 ft buffer on ug segments
            seg_ug_buff = processing.run("native:buffer", {'INPUT':seg_ug,'DISTANCE':309.9993799999992,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #merge the buffer layers for a complete list of valid area
            seg_buff_merged =  processing.run("native:mergevectorlayers", {'LAYERS':[seg_ae_buff, seg_ug_buff],'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #select all sites within the buffer zone
            processing.run("native:selectbylocation", {'INPUT': boundSites,'PREDICATE':[0],'INTERSECT':seg_buff_merged,'METHOD':0})
            #invert the site selection to get all sites that fall outside of the valid zone.
            boundSites.invertSelection()
            #get list of uuids for failed sites. List to be referenced 
            proximity_failure = [] #uuids
            for f in boundSites.selectedFeatures():
                proximity_failure.append(f['uuid'])
            #sites gets reset in Main QC portion
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
            dbox.append(errorFormat.format('Could not complete Site proximity checks.'))
            proximity_failure = []
        
        #Main QC
        try:
            processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
 
            errorDict = {
                "Segment ID Invalid": 0,
                "Group_1 Invalid": 0,
                "BEN Invalid": 0,
                "Address Invalid": 0,
                "City Invalid": 0,
                "State Invalid": 0,
                "Zip Code Invalid": 0,
                "Site Type Invalid": 0,
                "DoNotServe Non-Zero BEN":0,
                "Address Verification Invalid": 0,
                "MDU_NOT_>1_BEN": 0,
                "Fails Segment Proximity": 0

            }
            total = sites.selectedFeatureCount()
            if sites.isEditable():
                sites.commitChanges()
            with edit(sites):
                for idx, f in enumerate(sites.selectedFeatures(), 1):
                    f_errors = []
                    if f['uuid'] in proximity_failure:
                        errorDict['Fails Segment Proximity'] += 1
                        f_errors.append('Fails_Segment_Proximity')
                    try:
                        if f['group_1'] in [None, ''] or f['group_1'] != fda_name: #Group 1
                            errorDict['Group_1 Invalid'] += 1
                            f_errors.append('Group_1_Invalid')
                    except Exception as e: #some projects have Group 1 field as site_group, and others use group_1
                        try:
                            if f['site_group'] in [None, ''] or f['site_group'] != fda_name: #Group 1
                                errorDict['Group_1 Invalid'] += 1
                                f_errors.append('Group_1_Invalid')
                        except Exception as e:
                            exc_type, exc_value, exc_traceback = sys.exc_info()
                            line_number = exc_traceback.tb_lineno
                            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
                    if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    if f['ben_'] in [None, '']:
                        errorDict['BEN Invalid'] += 1
                        f_errors.append('BEN_Invalid')
                    if f['address'] in [None, '']: #Address is combined House Number and Street Name by default in QGIS. Verofy only accepts "Address Field"
                        errorDict['Address Invalid'] += 1
                        f_errors.append('Address_Invalid')
                    if f['city'] in [None, '']:
                        errorDict['City Invalid'] += 1
                        f_errors.append('CITY_Invalid')
                    if f['state'] in [None, '']:
                        errorDict['State Invalid'] += 1
                        f_errors.append('State_Invalid')
                    if f['zip_code'] in [None, '']:
                        errorDict['Zip Code Invalid'] += 1
                        f_errors.append('Zip_Code_Invalid')
                    '''Site Types: 1: School, 2: Government,3: Large Business,
                        4: Library, 5: Museum, 6: Small Business, 7: University, 
                        8: SFR, 9: Vacant Lot, 10: MDU, 11: MTU, 12: Mobile Home,
                        13: Meet Me, 14: Do Not Serve'''
                    if f['site_type'] in [None, '']: 
                        errorDict['Site Type Invalid'] += 1
                        f_errors.append('Site_Type_Invalid')
                    elif f['site_type'] == 10 and f['ben_'] <= 1: #MDU should have BEN # >1
                        errorDict["MDU_NOT_>1_BEN"] += 1
                        f_errors.append("MDU_NOT_>1_BEN")
                    elif f['site_type'] == 14 and f['ben_'] != 0: #Do Not Serve should have BEN # = 0
                        errorDict["DoNotServe Non-Zero BEN"] += 1
                        f_errors.append("DoNotServe_Non-Zero_BEN")
                    if f['address_verification'] in [None, '']:
                        errorDict['Address Verification Invalid'] += 1
                        f_errors.append('Address_Verification_Invalid')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    sites.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Site check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def _segments_():
        start_time = datetime.now()
        dbox.append('SEGMENT CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("native:selectbylocation", {'INPUT':access_pts,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        #We only need access points that intersect with segment endpoints.
        endpoints = processing.run("native:extractspecificvertices", {'INPUT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'VERTICES':'-1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        endpoint_buffer = processing.run("native:buffer", {'INPUT':endpoints,'DISTANCE':1.9999959999999948,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        processing.run("native:selectbylocation", {'INPUT':access_pts,'PREDICATE':[0],'INTERSECT': endpoint_buffer,'METHOD':0})
        
        segment_access = processing.run("native:joinattributesbylocation", {'INPUT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'PREDICATE':[0],'JOIN': QgsProcessingFeatureSourceDefinition(access_pts.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'JOIN_FIELDS':['size'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'a_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        try:
            #Do the Attribute Join
            QgsProject.instance().addMapLayer(segment_access)
            jlayer = project.mapLayersByName(segment_access.name())[0]
            joinObject = QgsVectorLayerJoinInfo()
            joinObject.setJoinFieldName('uuid')
            joinObject.setTargetFieldName('uuid')
            joinObject.setJoinLayerId = jlayer.id()
            joinObject.setJoinLayer(jlayer)
            joinObject.setPrefix('j_')
            joinObject.setUsingMemoryCache(True)

            segments.addJoin(joinObject)
            errorDict = {
                "Segment ID Invalid": 0,
                "Group_1 Invalid": 0,
                "Physical Status Invalid": 0,
                "Segment Status Invalid": 0,
                "Type Invalid": 0,
                "Type/Duct Diameter Mismatch": 0,
                "Duct Count Invalid": 0,
                "Duct Count/Access Point Mismatch": 0

            }
            total = segments.selectedFeatureCount()
            if segments.isEditable():
                segments.commitChanges()
            with edit(segments):
                for idx, f in enumerate(segments.selectedFeatures(), 1):
                    f_errors = []
                    geom = f.geometry()
                    if f['group'] in [None, '']:
                        errorDict['Group_1 Invalid'] += 1
                        f_errors.append('Group_1__Invalid')
                    else:
                        f0_fda_name = next((f0_dict[x][2] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                        if f0_fda_name is None:
                            f1_fda_name = next((f1_dict[x][2] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_fda_name is None:
                                if f['group'] != fda_name:
                                    errorDict['Group_1 Invalid'] += 1
                                    f_errors.append('Group_1__Invalid')
                            elif f['group'] != f1_fda_name:
                                errorDict['Group_1 Invalid'] += 1
                                f_errors.append('Group_1__Invalid')
                        elif f['group'] != f0_fda_name:
                            errorDict['Group_1 Invalid'] += 1
                            f_errors.append('Group_1__Invalid')

                    if f['segment_id'] in [None, '']:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    else:
                        f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                        if f0_segment_id is None:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                if f['segment_id'] != fda_name:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                            elif f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['segment_id'] != f0_segment_id:
                            errorDict['Segment ID Invalid'] += 1
                            f_errors.append('Segment_ID_Invalid')
                    if f['physical_status'] in [None, '']:
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')
                    elif f['physical_status'] != 2 and (f['data_source'] in [None, ''] or 'Katapult' not in f['data_source']):
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')
                    if f['segment_status'] in [None, '']: 
                        errorDict['Segment Status Invalid'] += 1
                        f_errors.append('Segment_Status_Invalid')
                    if f['segment_type'] in [None, ''] or f['segment_type'] not in [2, 9]: #Not in standard AE/UG
                        errorDict['Type Invalid'] += 1
                        f_errors.append('Type_Invalid')
                    elif f['segment_type'] == 2: #Aerial
                        if f['duct_diameter'] not in [None, '']: #diameter is null/blank for aerial spans, 2 AE, 9 UG
                            errorDict['Type/Duct Diameter Mismatch'] += 1
                            f_errors.append('Type/Duct_Diameter_Mismatch')
                        if f['duct_count'] not in [None, ''] and f['duct_count'] != 0:
                            errorDict['Duct Count Invalid'] += 1
                            f_errors.append('Duct_Count_Invalid')
                    elif f['segment_type'] == 9: #UG
                        if f['duct_diameter'] is not None and  f['duct_diameter'] not in [2, 16]:#diameter is .75 or 1.25 for ug
                            errorDict['Type/Duct Diameter Mismatch'] += 1
                            f_errors.append('Type/Duct_Diameter_Mismatch')
                        if f['duct_count'] in [None, ''] or f['duct_count'] not in [1,3,4,6,7]:
                            errorDict['Duct Count Invalid'] += 1
                            f_errors.append('Duct_Count_Invalid')


                    '''if f['duct_count'] not in [None, ''] and f['duct_count'] == 1 and f['j_a_size'] != 1:
                        errorDict['Duct Count/Access Point Mismatch'] += 1
                        f_errors.append('Duct_Count/Access_Point_Mismatch')'''
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    segments.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        finally:
            QgsProject.instance().removeMapLayer(segment_access)    
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Segment check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")

    def _poles_():
        start_time = datetime.now()
        dbox.append('POLE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':poles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        selectedPoles = processing.run("native:saveselectedfeatures", {'INPUT':poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #AE Segments
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("qgis:selectbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'2','METHOD':3}) #selecting within current selection , value 2 = aerial   
        processing.run("native:selectbylocation", {'INPUT':selectedPoles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':3})
        poles_not_attached_segment = []
        for f in selectedPoles.selectedFeatures():
            poles_not_attached_segment.append(f['uuid'])
        try:
            errorDict = {
                "Segment ID Invalid": 0,
                "Group 1 Invalid": 0,
                "Attach Invalid": 0,
                "Attach/Owner/MRE Flag": 0, 
                "Owner Invalid": 0,
                "Node ID Invalid": 0,
                "Data Source Invalid": 0,
                "Make Ready Type Invalid": 0,
                "MR State Invalid": 0,
                'AE Segment Not Snapped to Pole': 0,
                'AE Segment Snapped to "No" Pole':0
            }
            total = poles.selectedFeatureCount()
            if poles.isEditable():
                poles.commitChanges()
            with edit(poles):
                for idx, f in enumerate(poles.selectedFeatures(), 1):
                    f_errors = []
                    if f['pole_group'] in [None, ''] or f['pole_group'] != fda_name:
                        errorDict['Group 1 Invalid'] += 1
                        f_errors.append('Group_1_Invalid')
                    if f['segment_id'] in [None, '']:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    else:
                        geom = f.geometry()
                        f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                        if f0_segment_id is None:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                if f['segment_id'] != fda_name:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                            elif f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['segment_id'] != f0_segment_id:
                            errorDict['Segment ID Invalid'] += 1
                            f_errors.append('Segment_ID_Invalid')

                    if f['pole_owner'] in [None, '']:
                        errorDict['Owner Invalid'] += 1
                        f_errors.append('Owner_Invalid')
                    if f['node_id'] in [None, '']:
                        errorDict['Node ID Invalid'] += 1
                        f_errors.append('Node_ID_Invalid')
                    if f['data_source'] in [None, ''] or 'Katapult' not in f['data_source']:
                        errorDict['Data Source Invalid'] += 1
                        f_errors.append('Data_Source_Invalid')
                    if f['make_ready_type'] in [None, ''] or f['make_ready_type'] not in ['No MR', 'Simple MR', 'Communication Rearrangement',\
                    'Communication Rearrangement ', 'Simple Power', 'LightPower', 'Power Rearrangement', 
                    'Pole Replacement', 'HeavyPower', 'Do Not Attach']:
                        errorDict['Make Ready Type Invalid'] += 1
                        f_errors.append('Make_Ready_Type_Invalid')
                    if f['mr_state'] in [None, ''] or f['mr_state'] not in ['No MR', 'Simple MR', 'Pole Replacement', 'Power MR', 'Do Not Attach']:
                        errorDict['MR State Invalid'] += 1
                        f_errors.append('MR_State_Invalid')
                    '''if f['attach'] is [None, '']:
                        errorDict['Attach Invalid'] += 1
                        f_errors.append('Attach_Invalid')
                    if f['attach'] in ['Yes', 'yes'] and f['pole_owner'] in ['ATT', 'AT&T', 'att'] and f['make_ready_type'] in ['Power MR', 'Simple Power', 'LightPower', 'Power Rearrangement']:
                        errorDict['Attach/Owner/MRE Flag'] += 1
                        f_errors.append('Attach/Owner/MRE_Flag')'''
                    if f['attach'] is [None, '']:
                        pass
                    elif f['attach'] in ['Yes', 'yes'] and f['uuid'] in poles_not_attached_segment:
                        errorDict['AE Segment Not Snapped to Pole'] += 1
                        f_errors.append('AE_Segment_Not_Snapped_To_Pole')
                    elif f['attach'] in ['No', 'no'] and f['uuid'] not in poles_not_attached_segment:
                            errorDict['AE Segment Snapped to "No" Pole'] += 1
                            f_errors.append('AE_Segment_Snapped_To_NO_Pole')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    poles.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Pole check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    # main script
    if len(geom_checks)>0:
        __invalid_geoms__(bound, dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks)
    else:
        print('geometry check box not checked')
    progressBar.setValue(12)
    if qcCheckButton:
        if "Site" in qcChecks and fda_name not in ['F0', 'F1']:
            _sites_()
        progressBar.setValue(25)
        if "Pole" in qcChecks:
            _poles_()
        progressBar.setValue(33)
        if "Cabinet Boundary" in qcChecks:
            _cab_()
        progressBar.setValue(45)
        if "Segments" in qcChecks:
            _segments_()
        progressBar.setValue(66)
        if "Access Point" in qcChecks:
            _access_points_()
        dbox.append(f'QC Plugin Complete \u2713')
    full_end_time = datetime.now()
    full_elapsed = full_end_time - full_start_time
    dbox.append(f"Whole program complete time in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
    print(f"Whole program check completed in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
    dbox.append(f'Finished at {datetime.now()}')
    progressBar.setValue(100)

