# -*- coding: utf-8 -*-
"""
Created on Tues Jan 28, 2025
Vero QC
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
# import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __main_HLD__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks, qcCheckButton, qcListWidget):
    dbox.append(f'HLD Started at {datetime.now()}')
    full_start_time = datetime.now()
    '''geometryChecks = [
        geometriesListWidget.item(i).text()
        for i in range(geometriesListWidget.count())
        if geometriesListWidget.item(i).checkState() == Qt.Checked
    ]'''
    
    qcChecks = [
        qcListWidget.item(i).text()
        for i in range(qcListWidget.count())
        if qcListWidget.item(i).checkState() == Qt.Checked
    ]

    existing_layer = QgsProject.instance().mapLayer('memory.gpkg')
    if existing_layer:
        QgsProject.instance().removeMapLayer(existing_layer)
    progressBar.setValue(1)
    project = QgsProject.instance()
    class CustomFieldValueConverter(QgsVectorFileWriter.FieldValueConverter):
        def __init__(self, layerz):
            QgsVectorFileWriter.FieldValueConverter.__init__(self)
            self.layer = layerz

        def fieldDefinition(self, field):
            idx = self.layer.fields().indexFromName(field.name())
            editorWidget = self.layer.editorWidgetSetup(idx)
            #print(field.name(), idx, editorWidget.type())
            if editorWidget.type() == 'ValueRelation':
                return QgsField(field.name(), QVariant.String)
            else:
                return self.layer.fields()[idx]

        def convert(self, idx, value):
            eWidget = self.layer.editorWidgetSetup(idx)
            # print(eWidget.type())
            if eWidget.type() == 'ValueRelation':
                config = eWidget.config()
                related_layer = QgsProject.instance().mapLayer(config['Layer'])
                key_field = config['Key']
                display_field = config['Value']
                value_relation_map = {feat[key_field]: feat[display_field] for feat in related_layer.getFeatures()}
                display_value = value_relation_map.get(value, value)
                return display_value
            else:
                #print(value)
                return value
    save_options = QgsVectorFileWriter.SaveVectorOptions()
    #save_options.driverName = 'ESRI Shapefile'
    save_options.driverName = "GPKG"
    save_options.fileEncoding = "UTF-8"
    save_options.onlySelectedFeatures = True
    context = QgsProject.instance().transformContext()
    #-------------------------------------------------------------------
    # define AOI boundary
    project_name = bound
    dbox.append(str(project_name))

    proj_folder= f'{outputfolder}\\QC_{str(project_name)}'
    if not os.path.exists(proj_folder):
            os.mkdir(proj_folder)

    fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
    bound = processing.run("native:extractbyexpression", {'INPUT':fda_boundary, 'EXPRESSION': f'"area_id" LIKE \'%{project_name}%\'','OUTPUT': f'{proj_folder}\\bound.gpkg'})['OUTPUT']
    selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':bound, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
    # bound_gpkg = gpd.read_file(bound, layer = 'bound')
    #If you can only export selected, we may have nothing in boundary layer
    #-------------------------------------------------------------------
    
    #-------------------------------------------------------------------
    
    
    def invalid_geoms():
        print('invalid geoms')
        dbox.append('CHECKING GEOMETRIES')
        dbox.append('____________________________________________________________________________________________')
        invalid = False
        def is_snapped_to_point(point_geom, pointlayers):
            for point_layer in pointlayers:
                if point_layer.name() == 'Site' or point_layer.name() == 'Access_Point':
                    for point_feature in point_layer.getFeatures():
                        if point_geom.intersects(point_feature.geometry()):
                            return True
            return False
        
        # point features, only check for null geom. Inherently valid using 'check validity' tool.
        if geometryChecks is not None:
            if "Null/Missing Geometries And Incorrect Lat/Long" in geometryChecks:
                dbox.append("Checking for null/missing geometries or incorrect Lat/Long...")
                pointlayers = [layer for layer in project.mapLayers().values() if layer.isSpatial() and layer.type() == layer.VectorLayer and layer.wkbType() == QgsWkbTypes.Point]
                # dbox.append(f'{len(pointlayers)} point layers')
                point_layers = len(pointlayers)
                if point_layers == 0:
                    functionProgressBar.setValue(100)
                else:
                    increment = 100 / point_layers
                progress = 0
                functionProgressBar.setValue(0)
                for idx, layer in enumerate(pointlayers, 1):
                    layerInvalid = False
                    check_geom = processing.run("qgis:selectbyexpression", {'INPUT':layer,'EXPRESSION':'@geometry IS NULL','METHOD':0})['OUTPUT'].selectedFeatureCount()
                    check_latLong = processing.run("qgis:selectbyexpression", {'INPUT':layer,'EXPRESSION':'latitude < 0 OR longitude > 0','METHOD':0})['OUTPUT'].selectedFeatureCount()
                    check_list = {"geometry": check_geom, "lat/long": check_latLong}
                    for item in check_list:
                        if check_list[item]>0:
                            dbox.append(f"{check_list[item]} {layer.name()} features with {item} issue. See selected rows.")
                            invalid = True
                            layerInvalid = True
                    if layerInvalid == False:
                        dbox.append(f'{layer.name()} \u2713')
                    else:
                        dbox.append(f'{layer.name()} \u274C')
                    progress = int(idx * increment)
                    functionProgressBar.setValue(progress)
                progressBar.setValue(4)
                #linefeatures, checks for self-intersections
                # Check if the layer is a line layer
                def is_line_layer(layer):
                    return layer.isSpatial() and layer.type() == layer.VectorLayer and layer.wkbType() in [
                        QgsWkbTypes.LineString, 
                        QgsWkbTypes.MultiLineString,
                    ]

                # Filter line layers
                linelayers = [layer for layer in project.mapLayers().values() if is_line_layer(layer) and layer.name() != 'Fiber_Cable' and layer.name() != 'Segments']
                Fiber_Cable_Layer = project.mapLayersByName('Fiber_Cable')[0]
                Fiber_Cable_Name  = Fiber_Cable_Layer.name()
                Segments_Layer = project.mapLayersByName('Segments')[0]
                Segments_Layer_Name  = Segments_Layer.name()
                Fiber_Cable_Geom = processing.run("native:extractbylocation", {'INPUT':QgsProcessingFeatureSourceDefinition(Fiber_Cable_Layer.source(), selectedFeaturesOnly=False, featureLimit=-1, flags=QgsProcessingFeatureSourceDefinition.FlagOverrideDefaultGeometryCheck, geometryCheck=QgsFeatureRequest.GeometrySkipInvalid),'PREDICATE':[0],'INTERSECT':selectedBound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                Segments_Geom = processing.run("native:extractbylocation", {'INPUT':QgsProcessingFeatureSourceDefinition(Segments_Layer.source(), selectedFeaturesOnly=False, featureLimit=-1, flags=QgsProcessingFeatureSourceDefinition.FlagOverrideDefaultGeometryCheck, geometryCheck=QgsFeatureRequest.GeometrySkipInvalid),'PREDICATE':[0],'INTERSECT':selectedBound,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                Fiber_Cable_Geom.setName(Fiber_Cable_Name + "_extracted")
                Segments_Geom.setName(Segments_Layer_Name + "_extracted")
                # dbox.append(f'{len(linelayers)} line layers')
                linelayers = [Fiber_Cable_Geom, Segments_Geom]
                line_layers = len(linelayers)
                if line_layers == 0:
                    functionProgressBar.setValue(100)
                else:
                    increment = 100 / line_layers
                progress = 0
                functionProgressBar.setValue(0)
                
                for idx, layer in enumerate(linelayers, 1):
                    parsedLayer = layer.name().split("_")[0]
                    unsnapped_feature_ids = []
                    lyr_issue = False
                    if "Self Intersecting Features" in geometryChecks:
                        check_validity = processing.run("qgis:checkvalidity", {'INPUT_LAYER': layer,'METHOD':2,'IGNORE_RING_SELF_INTERSECTION':False,'ERROR_OUTPUT':'TEMPORARY_OUTPUT'})['ERROR_OUTPUT']
                        if len(check_validity)>0:
                            processing.run("native:savefeatures", {'INPUT':check_validity,'OUTPUT':f'{outputfolder}\\{parsedLayer}_invalid_features.gpkg','LAYER_NAME':'','DATASOURCE_OPTIONS':'','LAYER_OPTIONS':'','ACTION_ON_EXISTING_FILE':0})
                            dbox.append(f"{len(check_validity)} {parsedLayer} features with invalid geometry. See output file.")
                            lyr_issue = True
                    check_geom = processing.run("qgis:selectbyexpression", {'INPUT':layer,'EXPRESSION':'@geometry IS NULL OR "calculated_length" IS NULL','METHOD':0})['OUTPUT'].selectedFeatureCount()
                    if check_geom > 0:
                        dbox.append(f"{check_geom} {parsedLayer} features with <Null> geometry or calculated_length. Check for '0', Null, or negative 'calculated_length' field. See selected rows.")
                        lyr_issue = True
                    # elif "Floating Lines" in geometryChecks:
                    #     dbox.append("checking floating lines...")
                    #     for line_feature in layer.getFeatures():
                    #         line_geom = line_feature.geometry()
                            
                    #         if not line_geom.isMultipart():  # Ensure it's a single-part line
                    #             vertices = line_geom.asPolyline()  # Get the vertices of the line
                    #         else:
                    #             vertices = line_geom.asMultiPolyline()[0]  # Handle multipart lines

                    #         # Extract start and end points
                    #         start_point = QgsGeometry.fromPointXY(vertices[0])
                    #         end_point = QgsGeometry.fromPointXY(vertices[-1])

                    #         # Check if start and end points are snapped to any point feature
                    #         start_snapped = is_snapped_to_point(start_point, pointlayers)
                    #         end_snapped = is_snapped_to_point(end_point, pointlayers)

                    #         # Log floating lines
                    #         if not start_snapped or not end_snapped:
                    #             unsnapped_feature_ids.append(line_feature.id())
                    #             lyr_issue == True
                    #             if not start_snapped and not end_snapped:
                    #                 dbox.append(f"Floating line detected in layer '{layer.name()}', Feature ID: {line_feature['uuid']}. Both start and end points are not snapped.")
                    #             elif not start_snapped:
                    #                 dbox.append(f"Floating line detected in layer '{layer.name()}', Feature ID: {line_feature['uuid']}. Start point is not snapped.")
                    #             elif not end_snapped:
                    #                 dbox.append(f"Floating line detected in layer '{layer.name()}', Feature ID: {line_feature['uuid']}. End point is not snapped.")

                    #     if len(unsnapped_feature_ids) > 0:
                    #         layer.selectByIds(unsnapped_feature_ids)
                    #         dbox.append(f"{len(unsnapped_feature_ids)} features added to the selection in layer '{layer.name()}'.")
                    #     else:
                    #         dbox.append(f"No floating lines detected in layer '{layer.name()}'.")
                    if lyr_issue == False:
                        dbox.append(f'{parsedLayer} \u2713')
                    else:
                        dbox.append(f'{parsedLayer} \u274C')
                        invalid = True
                    progress = int(idx * increment)
                    functionProgressBar.setValue(progress)
                progressBar.setValue(8)
                # print("Floating lines checked.")
        
                polylayers = [layer for layer in project.mapLayers().values() if layer.isSpatial() and layer.type() == layer.VectorLayer and layer.wkbType() in [QgsWkbTypes.Polygon, QgsWkbTypes.MultiPolygon]]
                # dbox.append(f'{len(polylayers)} polygon layers')
                #polygon features, checks for self intersections

            if "Self Intersecting Features" in geometryChecks:
                dbox.append("Checking for self-intersecting features...")
                poly_layers = len(polylayers)
                if poly_layers == 0:
                    functionProgressBar.setValue(100)
                else:
                    increment = 100 / poly_layers
                progress = 0
                functionProgressBar.setValue(0)
                for idx, layer in enumerate(polylayers, 1):
                    lyr_issue = False
                    check_validity = processing.run("qgis:checkvalidity", {'INPUT_LAYER': layer,'METHOD':2,'IGNORE_RING_SELF_INTERSECTION':False,'ERROR_OUTPUT':'TEMPORARY_OUTPUT'})['ERROR_OUTPUT']
                    if len(check_validity)>0:
                        processing.run("native:savefeatures", {'INPUT':check_validity,'OUTPUT':f'{outputfolder}\\{layer.name()}_invalid_features.gpkg','LAYER_NAME':'','DATASOURCE_OPTIONS':'','LAYER_OPTIONS':'','ACTION_ON_EXISTING_FILE':0})
                        dbox.append(f"{len(check_validity)} {layer.name()} features with invalid geometry. See output file.")
                        lyr_issue = True
                        invalid = True
                    else:
                        check_geom = processing.run("qgis:selectbyexpression", {'INPUT':layer,'EXPRESSION':'@geometry IS NULL','METHOD':0})['OUTPUT'].selectedFeatureCount()
                        if check_geom >0:
                            dbox.append(f"{check_geom} {layer.name()} features with <Null> geometry. See selected rows.")
                            lyr_issue= True
                            invalid = True
                    if lyr_issue == False:
                        dbox.append(f'{layer.name()} \u2713')
                    else:
                        dbox.append(f'{layer.name()} \u274C')
                    progress = int(idx * increment)
                    functionProgressBar.setValue(progress)
            if invalid:
                dbox.append(errorFormat.format(f'Geometry Errors. \u274C'))
            else:
                dbox.append(validFormat.format(f'All geometries valid. \u2713'))
            dbox.append('')
            dbox.append('')
    dbox.append(' ')
    dbox.append(' ')
    print('layer extraction')
    def layerSelectionConverter(searchlayerName, intersectingLayer):
        mapLayer = project.mapLayersByName(searchlayerName)[0]
        # print(f'select layer name: {mapLayer.name()}')
        layerSelection = processing.run("qgis:selectbylocation", {'INPUT': mapLayer, 'PREDICATE': [0], 'INTERSECT': QgsProcessingFeatureSourceDefinition(intersectingLayer, selectedFeaturesOnly=False, featureLimit=-1, flags=QgsProcessingFeatureSourceDefinition.FlagOverrideDefaultGeometryCheck, geometryCheck=QgsFeatureRequest.GeometrySkipInvalid), 'OUTPUT': 'memory:'})['OUTPUT']
        # print('layer selection complete')
        return layerSelection
    def layerExtractionConverter(searchlayerName, intersectingLayer):
        mapLayer = project.mapLayersByName(searchlayerName)[0]
        # print(f'extract layer name: {mapLayer.name()}')
        layerExtraction = processing.run("native:extractbylocation", {'INPUT': QgsProcessingFeatureSourceDefinition(mapLayer.source(), selectedFeaturesOnly=False, featureLimit=-1, flags=QgsProcessingFeatureSourceDefinition.FlagOverrideDefaultGeometryCheck, geometryCheck=QgsFeatureRequest.GeometrySkipInvalid), 'PREDICATE': [0], 'INTERSECT': intersectingLayer, 'OUTPUT': 'memory:'})['OUTPUT']
        # print('layer extraction complete')
        return layerExtraction


    # This can be optimized but for now if any current checks look at new layers or layers that previously were apart of other def/functions this will need to be updated
    if qcCheckButton:
        if "Sites" in qcChecks:
            boundSites = layerExtractionConverter('Site', bound)
            Fiber_Cable = layerExtractionConverter('Fiber_Cable', bound)
            drops = processing.run("qgis:selectbyattribute", {'INPUT': Fiber_Cable, 'FIELD': 'cable_category', 'OPERATOR':0, 'VALUE':2, 'METHOD':3, 'OUTPUT': 'memory:'})['OUTPUT']
        if "Access Points" in qcChecks:
            Access_Point = layerSelectionConverter('Access_Point', bound)
        # Cabinet_Boundary itself isnt needed but the zone names below are used in different layers and this is typically not going to be an expensive variable to create  
        Cabinet_Boundary = processing.run("native:selectbylocation", {'INPUT':fda_boundary,'PREDICATE':[5],'INTERSECT':bound,'OUTPUT': 'memory:'})['OUTPUT']
        # Network_Element = layerExtractionConverter('Network_Element', bound)
        if "Segments" in qcChecks:
            Segments = layerSelectionConverter('Segments', bound)
        if "Poles" in qcChecks:
            permitNames = []
            Poles = layerSelectionConverter('Pole', bound)
            Permits = layerSelectionConverter('Permits', bound)
            for i in Permits.selectedFeatures():
                permitNames.append(i['internal_permit_id'])
        # Splicing = layerExtractionConverter('Splicing', bound)
        # NAP_Boundary = layerExtractionConverter('NAP_Boundary', bound)
        # Pole = layerExtractionConverter('Pole', bound)
        # print('layer extraction complete')
        zone_cab_fda_name = None
        cab_hub_size = None
        f1_cab_fda_name = None
        f0_cab_fda_name = None


        for i in Cabinet_Boundary.selectedFeatures():
            # print(f"Feature ID: {i.id()}, FDA Name: {i['fda_name']}, Area ID: {i['area_id']}")
            if "Z" in i['area_id'] and "ZONE" in i['fda_name']:
                zone_cab_fda_name = i['fda_name']
                cab_hub_size = i['hub_size']
            elif "F1" in i['area_id'] and "F1" in i['fda_name']:
                f1_cab_fda_name = i['fda_name']
            elif "F0" in i['area_id'] and "F0" in i['fda_name']:
                f0_cab_fda_name = i['fda_name']


    def _sites_():
        start_time = datetime.now()
        dbox.append('SITE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        functionProgressBar.setValue(0)
        print('started sites')
        global bens, mdus
        # Initialize variables
        mdus = {}
        site_errors = [] # Collect errors for this layer
        print('Gathering Sites')
        siteNdrops = processing.run("native:extractbylocation", {'INPUT': drops, 'PREDICATE': [0], 'INTERSECT': boundSites, 'OUTPUT': 'memory:'})['OUTPUT']
        print('Joining on Drops')
        result = processing.run("native:joinattributesbylocation", {
            'INPUT': boundSites,
            'JOIN': siteNdrops,
            'PREDICATE': [0],  # Intersects
            'JOIN_FIELDS': ['house_number', 'street_name', 'city', 'state', 'zip_code', 'uuid', 'site_type', 'include_in_build_plan', 'ben_', 'group_1','qc_errors'],  # Fields to bring from siteNdrops
            'METHOD': 0,  # Take attributes of the first matching feature only
            'DISCARD_NONMATCHING': True,  # Exclude features with no intersection
            'PREFIX': 'join_',  # No prefix for the joined fields
            'OUTPUT': 'memory:joined_sites',
            'NON_MATCHING': 'TEMPORARY_OUTPUT'  # Non-matching features
        })
        functionProgressBar.setValue(12)
        # Access the matching and non-matching layers
        joined_sites = result['OUTPUT']  # Matching features
        non_matching_path = result['NON_MATCHING']  # Non-matching features 
        # Load the non-matching features as a QgsVectorLayer
        try:
            non_matching_sites = QgsVectorLayer(non_matching_path, "Non-Matching Sites", "ogr")
        except Exception as e:
            non_matching_sites = non_matching_path
        functionProgressBar.setValue(20)
        #-- Proximity Checks --
        #Every Site is within 410' of an Aerial segment or within 310' of an UG segment
        segments = layerExtractionConverter('Segments', bound)
        seg_ae = processing.run("native:extractbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        seg_ug =  processing.run("native:extractbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'9','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        seg_ae_buff = processing.run("native:buffer", {'INPUT':seg_ae,'DISTANCE':409.99917999999894,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        seg_ug_buff = processing.run("native:buffer", {'INPUT':seg_ug,'DISTANCE':309.9993799999992,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        seg_buff_merged =  processing.run("native:mergevectorlayers", {'LAYERS':[seg_ae_buff, seg_ug_buff],'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        processing.run("native:selectbylocation", {'INPUT': boundSites,'PREDICATE':[0],'INTERSECT':seg_buff_merged,'METHOD':0})
        boundSites.invertSelection()
        count_failed_segment_proximity = boundSites.selectedFeatureCount()
        list_failed_segment_proximity = []
        for feature in boundSites.selectedFeatures():
            list_failed_segment_proximity .append(feature['uuid'])

        #-- Define error variables
        functionProgressBar.setValue(50)
        count_missing_required_fields = 0
        count_fda_name_mismatch = 0
        count_site_type_do_not_serve_with_ben = 0
        count_mdu_with_less_than_1_drops = 0
        count_bp_site_with_no_drop = 0
        count_vacant_site_without_drop = 0
        count_mdu_sites = 0
        count_zero_ben_site_type = 0
        count_missing_site_type = 0
        count_vacant_without_drops = 0
        count_vacant_with_drops = 0
        count_missing_build_plan = 0
        bens = 0
        

        joined_sites.startEditing()
        non_matching_sites.startEditing()
        Sites = project.mapLayersByName('Site')[0]
        if Sites.isEditable():
            Sites.commitChanges()

        functionProgressBar.setValue(100)
        print('Sites for loop begun')
        # for site in joined_sites.getFeatures():
        features = list(joined_sites.getFeatures())
        total = len(features)
        for idx, site in enumerate(features, 1):
            print(f'site {site["uuid"]}')
            site_type = site['site_type']
            uuid_left = site['uuid']
            include_in_build_plan = site['include_in_build_plan']
            uuid_x = site['join_uuid']
            ben_ = site['ben_']
            group_1 = site['group_1']
            house_number = site['house_number']
            street_name = site['street_name']
            city = site['city']
            state = site['state']
            zip_code = site['zip_code']
            nullcollection = {}
            nullChecks = {'house_number': house_number, 'street_name': street_name, 'city': city, 'state': state, 'zip_code': zip_code, 'site_type': site_type, 'include_in_build_plan': include_in_build_plan, 'ben_': ben_, 'group_1': group_1}
            if site['uuid'] in list_failed_segment_proximity:
                site_errors.append("Failed_Segment_Proximity")
            for field, value in nullChecks.items():
                if value is None or value == '' or value == QVariant():
                    if uuid_left not in nullcollection:
                        nullcollection[uuid_left] = [field]
                    else:
                        nullcollection[uuid_left].append(field)
            if len(nullcollection) > 0:
                count_missing_required_fields += 1
                site_errors.append(
                    "Missing_Required_Fields"
                )
            
            if group_1 is not None and group_1 != '' and group_1 != QVariant() and group_1 != project_name:
                count_fda_name_mismatch += 1
                site_errors.append(
                "FDA_Name_Mismatch"
                )
            if site_type is None or site_type == '' or site_type == QVariant():
                count_missing_site_type += 1
            if ben_ is not None and ben_ != QVariant():
                bens += int(site['ben_'])
            # Check if include_in_build_plan is filled out
            if include_in_build_plan is None or include_in_build_plan == '' or include_in_build_plan == QVariant():
                count_missing_build_plan += 1
            if site_type == 14 and ben_ != 0:
                count_zero_ben_site_type += 1
                site_errors.append(
                    "Site_Type_Do_Not_Serve_with_BEN"

                )
                count_zero_ben_site_type += 1

            # Check for MDU sites with up to 32 units
            if (site_type == 10 or site_type == "MDU") and ben_ is not None and ben_ != QVariant() and int(ben_) <= 32 and uuid_x:
                if uuid_left not in mdus:
                    mdus[uuid_left] = 1
                else:
                    mdus[uuid_left] += 1
            if (site_type == 10 or site_type == "MDU") and ben_ is not None and ben_ != QVariant() and int(ben_) < 1:
                count_mdu_with_less_than_1_drops += 1
                site_errors.append(
                    "MDU_with_<_1_drops"
                )
                    
            try:
                if(len(site_errors) > 0):
                    site['qc_errors'] = ', '.join(site_errors)
                else:
                    site['qc_errors'] = 'None'
            except Exception as e:
                print(f"Error updating site feature: {e}")
            joined_sites.updateFeature(site)
            site_errors = []
            progress = int((idx / total) * 100)
            functionProgressBar.setValue(progress)
        # print('joined sites for loop complete')
        for key, count in mdus.items():
            if count > 32:
                count_mdu_sites += 1
        print('non-matching sites for loop begun')
        features = list(non_matching_sites.getFeatures())
        total = len(features)
        for idx, site in enumerate(features, 1):
            if site['ben_'] is not None and site['ben_'] != QVariant():
                bens += int(site['ben_'])
            if include_in_build_plan is not None and include_in_build_plan == 'Yes': 
                count_bp_site_with_no_drop += 1
                site_errors.append(
                    "BP_Site_with_no_drop"
                )


            # If no drop intersects with the site, check if it's vacant
            if site_type == 9:
                count_vacant_without_drops += 1
                site_errors.append(
                    "Vacant_Site_WO_drop"
                )
            if(len(site_errors) > 0):
                site['qc_errors'] = ', '.join(site_errors)
            else:
                site['qc_errors'] = 'Non'  # Add errors to the site layer
            non_matching_sites.updateFeature(site)
            site_errors = []  # Reset errors for the next site
            progress = int((idx / total) * 100)
            functionProgressBar.setValue(progress)
        print('non-matching sites for loop complete')
        QgsProject.instance().addMapLayer(joined_sites)

        jSites = project.mapLayersByName('joined_sites')[0]
        jfield = 'uuid'
        joinObject = QgsVectorLayerJoinInfo()
        
        joinObject.setJoinFieldName(jfield)
        joinObject.setTargetFieldName(jfield)
        joinObject.setJoinLayerId = jSites.id()
        joinObject.setJoinLayer(jSites)
        joinObject.setPrefix('j_')
        joinObject.setUsingMemoryCache(True)
        
        Sites.addJoin(joinObject)

        project.addMapLayer(non_matching_sites)
        nmSites = project.mapLayersByName('Unjoinable features from first layer')[0]

        jfield = 'uuid'
        joinObject1 = QgsVectorLayerJoinInfo()
        
        joinObject1.setJoinFieldName(jfield)
        joinObject1.setTargetFieldName(jfield)
        joinObject1.setJoinLayerId = nmSites.id()
        joinObject1.setJoinLayer(nmSites)
        joinObject1.setPrefix('nm_')
        joinObject1.setUsingMemoryCache(True)

        Sites.addJoin(joinObject1)

        SitesSelectionJ = processing.run("qgis:selectbyexpression", {'INPUT':Sites,'EXPRESSION':'"j_qc_errors" is not NULL OR "nm_qc_errors" is not NULL','METHOD':0})['OUTPUT']
        selection_countJ = SitesSelectionJ.selectedFeatureCount()
        print(f'{selection_countJ} J Joined Features')
        with edit(Sites):
            features = list(Sites.selectedFeatures())
            total = len(features)
            progress = int((idx / total) * 100)
            functionProgressBar.setValue(progress)
            for idx, f in enumerate(features, 1):
                print(f'j_qc_errors: {f["j_qc_errors"]} nm_qc_errors: {f["nm_qc_errors"]} ')
                if f['j_qc_errors'] not in ['Non', None]:
                    f['qc_errors'] = f['j_qc_errors']
                elif f['nm_qc_errors'] not in ['Non', None]:
                    f['qc_errors'] = f['nm_qc_errors']
                else:
                    f['qc_errors'] = None
                # f['qc_errors'] = f['j_qc_errors'] if f['j_qc_errors'] not in ['Non'] else None
                # f['qc_errors'] = f['nm_qc_errors'] if f['nm_qc_errors'] not in ['Non'] else None
                Sites.updateFeature(f)
                progress = int((idx / total) * 100)
                functionProgressBar.setValue(progress)
        
        #Every Site is within 410' of an Aerial segment or within 310' of an UG segment. Buffer each aerial segment to 410 ft. BUffer each UG seg to 310ft. Merge the buffer zones. Check if select for features that do NOT intersect the buffer.

        
        Sites.removeJoin(jSites.id())
        Sites.removeJoin(nmSites.id())
        joined_sites.commitChanges()
        non_matching_sites.commitChanges()
        QgsProject.instance().removeMapLayers([jSites.id()])
        QgsProject.instance().removeMapLayers([nmSites.id()])


        # Log results
        siteErrorDict = {
            "Missing Required Fields": count_missing_required_fields,
            "FDA Name Mismatch": count_fda_name_mismatch,
            "Site Type Do Not Serve with BEN": count_site_type_do_not_serve_with_ben,
            "MDU with < 1 drops": count_mdu_with_less_than_1_drops,
            "BP Site with no drop": count_bp_site_with_no_drop,
            "Vacant Site WO drop": count_vacant_site_without_drop,
            "Vacant Site with drop": count_vacant_with_drops,
            "MDU Sites": count_mdu_sites,
            "Zero BEN Site Type": count_zero_ben_site_type,
            "Missing Site Type": count_missing_site_type,
            "Vacant without drops": count_vacant_without_drops,
            "Vacant with drops": count_vacant_with_drops,
            "Missing Build Plan": count_missing_build_plan,
            "Failed Segment Proximity": count_failed_segment_proximity
        }
        for key, value in siteErrorDict.items():
            if value > 0:
                dbox.append(warningFormat.format(f"{key}: {value}"))
                print(f"{key}: {value}")
                end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Sites check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        print(f"Sites check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        dbox.append(f'')
   
    def _poles_():
        start_time = datetime.now()
        dbox.append('POLE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        # print('started poles')
        count_Pole_Name_To_Pemit_Mismatch = 0
        count_Pole_Node_id_Mismatch = 0
        count_Pole_MR_Mismatch = 0
        count_Pole_Owner_Missing = 0
        if Poles.isEditable():
            Poles.commitChanges()
        with edit(Poles):
            for pole in Poles.getSelectedFeatures():
                pole_errors = []
                poleOwner = pole['pole_owner']
                poleNodeId = pole['node_id']
                poleSource = pole['data_source']
                poleMRT = pole['make_ready_type']
                poleMrState = pole['mr_state']
                
                if poleSource is not None and poleSource != '' and poleSource != QVariant():
                    if poleSource.lower() == 'original':
                        if poleNodeId is not None:
                            count_Pole_Node_id_Mismatch += 1
                            # print(f"Pole Node ID is missing or None.")
                            # dbox.append(errorFormat.format("Pole Node ID is missing or None."))
                            pole_errors.append(
                                "Pole_NodeID_Mismatch"
                            )
                    if 'katapult' in poleSource.lower():
                        if poleNodeId is None:
                            count_Pole_Node_id_Mismatch += 1
                            # print(f"Pole Node ID is missing or None.")
                            # dbox.append(errorFormat.format("Pole Node ID is missing or None."))
                            pole_errors.append(
                                "Pole_NodeID_Mismatch"
                            )
                        elif poleOwner is None:
                            count_Pole_Owner_Missing += 1
                            # print(f"Pole Owner is missing or None.")
                            # dbox.append(errorFormat.format("Pole Owner is missing or None."))
                            pole_errors.append(
                                "Pole_Owner_Missing"
                            )
                if poleMRT is not None:
                    if poleMrState is None:
                        count_Pole_MR_Mismatch += 1
                        # print(f"Pole Make Ready Type is missing or None.")
                        # dbox.append(errorFormat.format("Pole Make Ready Type is missing or None."))
                        pole_errors.append(
                            "Pole_Make_Ready_mismatch"
                        )
                elif poleMRT is None and poleMrState is not None:
                    count_Pole_MR_Mismatch += 1
                    # print(f"Pole Make Ready Type is missing or None.")
                    # dbox.append(errorFormat.format("Pole Make Ready Type is missing or None."))
                    pole_errors.append(
                        "Pole_Make_Ready_mismatch"
                    )
                    
                
                polePermit = pole['permit'] if pole['permit'] is not None and pole['permit'] != '' else None
                if polePermit not in permitNames and polePermit is not None and len(permitNames) > 0:
                    count_Pole_Name_To_Pemit_Mismatch += 1
                    pole_errors.append(
                        "Pole_Name_To_Pemit_Mismatch"
                    )
                    # print(f"Pole Permit Name mismatch: {polePermit}")
                    # dbox.append(errorFormat.format(f"Pole Permit Name mismatch: {polePermit}"))
                    pole["qc_errors"] = ', '.join(pole_errors) if len(pole_errors) > 0 else 'None'
                    Poles.updateFeature(pole)    
                    poleErrors = []
                    # logging errors
        polesErrorsDict = {
            "Pole Permit To Name Mismatch": count_Pole_Name_To_Pemit_Mismatch,
            "Pole Node ID Mismatch": count_Pole_Node_id_Mismatch,
            "Pole Make Ready Mismatch": count_Pole_MR_Mismatch,
            "Pole Owner Missing": count_Pole_Owner_Missing
        }
        for key, value in polesErrorsDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
                # print(f"{key}: {value}")
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Poles check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        print(f"Poles check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        dbox.append(f'')    
            


   
    def _cab_():
        print('started cab')
        start_time = datetime.now()
        dbox.append('CABINET BOUNDARY CHECKS')
        dbox.append('____________________________________________________________________________________________')
        count_Estimated_HHP_Missing = 0
        count_Estimated_HHP_Mismatch = 0
        count_Hub_Size_Invalid = 0
        count_FDA_Area_ID_Invalid = 0
        count_FDA_Name_Invalid = 0
        count_FDA_Name_Area_ID_Null = 0
        count_Wire_Center_Missing = 0
        count_FDA_Name_Incorrect_Format = 0
        count_LLD_Status_Incorrect = 0
        count_Zone_Extraction_Error = 0
        count_FDA_Name_Zone_Mismatch = 0
        if Cabinet_Boundary.isEditable():
            Cabinet_Boundary.commitChanges()
        with edit(Cabinet_Boundary):
            features = list(Cabinet_Boundary.getSelectedFeatures())
            total = len(features)
            for idx, cab in enumerate(features, 1):
                cab_errors = []  # Reset errors for each cabinet
                # if 'F1' in cab['area_id'] and 'F1' in cab['fda_name']:
                #     f1_cab_fda_name = cab['fda_name']
                # elif 'F0' in cab['area_id']and 'F0' in cab['fda_name']:
                #     f0_cab_fda_name = cab['fda_name']
                if "Z" in cab['area_id'] and 'ZONE' in cab['fda_name'] and project_name == cab['area_id']:
                    # Estimated HHP is updated to final HHP count which is derived from the sum of sites and Ben/Living Units (LUs)?
                    estimated_hhp = cab['estimated_hhp']
                    if estimated_hhp is None or estimated_hhp == '' or estimated_hhp == QVariant():
                        count_Estimated_HHP_Missing += 1
                        cab_errors.append(
                            "Estimated_HHP_Missing"
                            # "Error_Description": "Estimated HHP is missing or None.",
                            # "Geometry": cab.geometry()
                        )
                        # print("Estimated HHP is missing or None.")
                        dbox.append(errorFormat.format("                          Estimated HHP is missing or None."))
                    elif estimated_hhp != bens:
                        count_Estimated_HHP_Mismatch += 1
                        cab_errors.append(
                            "Estimated_HHP_Mismatch"
                            # "Error_Description": f"Estimated HHP {estimated_hhp} does not match final HHP: {bens}",
                            # "Geometry": cab.geometry()
                        )
                        # print(f"Estimated HHP {estimated_hhp} not updated to final HHP: {bens}")
                        dbox.append("                          Estimated HHP not updated to final HHP.")
                        # Hub Size attribute is filled in with 576, 432, 288?
                        hub_size_value = cab['hub_size']
                        if hub_size_value not in ['4', '3', '2' , '288', '432', '576', 288, 432, 576]:
                            count_Hub_Size_Invalid += 1
                            cab_errors.append(
                                "Hub_Size_Invalid"
                                # "Error_Description": f"Hub size invalid: {hub_size_value}",
                                # "Geometry": cab.geometry()
                            )
                            # print(f"Hub size invalid: {hub_size_value}")    
                            dbox.append(errorFormat.format(f"-Hub size invalid: {hub_size_value}"))
                        hub_size = hub_size_value
                        
                else:
                    if cab['area_id'] is not None and cab['area_id'] != '' and cab['area_id'] != QVariant():
                        count_FDA_Area_ID_Invalid += 1
                        cab_errors.append(
                            "FDA_Area_ID_Invalid"
                        )
                        # dbox.append(errorFormat.format(f"FDA area ID incorrect format: {cab['area_id']}"))
                        # return
                    elif cab['fda_name'] is not None and cab['fda_name'] != '' and cab['fda_name'] != QVariant():
                        count_FDA_Name_Invalid += 1
                        cab_errors.append(
                            "FDA_Name_Invalid"
                        )
                        # dbox.append(errorFormat.format(f"FDA Name incorrect format: {cab['fda_name']}"))
                        # return
                    else:
                        count_FDA_Name_Area_ID_Null += 1
                        cab_errors.append(
                            "FDA_Name_Area_ID_Null"
                        )
                        # print("FDA Name and/or Area ID is NULL")
                        # dbox.append(errorFormat.format(f"FDA Name and/or Area ID is NULL"))
                        # return

                wire_center = cab['wire_center']
                wire_center_prefix = None  # Initialize wire_center_prefix to avoid undefined variable errors
                if wire_center is not None and wire_center != '' and wire_center != QVariant():
                    wire_center_prefix = wire_center[:3]
                else:  
                    count_Wire_Center_Missing += 1
                    cab_errors.append(
                        "Wire_Center_Missing"
                    )
                    # print("Wire center is missing or None.")
                    # dbox.append(errorFormat.format("Wire center is missing or None."))
                    # return  # Exit the function if wire_center is invalid
                
                # try:
                #     zone = project_name.split('_')[1]
                # except Exception as e:
                #     count_Zone_Extraction_Error += 1
                #     cab_errors.append(
                #         "Zone_Extraction_Error"
                #     )
                    # print(f"Error extracting zone from area_id: {e} missing '_'")
                    # dbox.append(errorFormat.format(f"Error extracting zone from area_id: {e} missing '_'"))
                    # return

                FDA_value = cab['fda_name']
                # if f"{wire_center_prefix}_Z" not in FDA_value and (zone != 'F1' or zone != 'F0'):
                #     count_FDA_Name_Incorrect_Format += 1
                #     cab_errors.append(
                #         "FDA_Name_Incorrect_Format"
                #     )
                #     # print(f"FDA Name incorrect format: {FDA_value}")
                #     # dbox.append(errorFormat.format(f"Zone Cabinet Boundary FDA_value incorrect format: {FDA_value}"))
                # elif zone not in FDA_value:
                #     count_FDA_Name_Zone_Mismatch += 1
                #     cab_errors.append(
                #         "FDA_Name_Zone_Mismatch"
                #     )
                    # print(f"Cabinet Boundary FDA_value zone number does not match area_id: {FDA_value}")
                    # dbox.append(errorFormat.format(f"Cabinet Boundary FDA_value zone number does not match area_id: {FDA_value}"))

                # LLD Status is attributed as Preliminary Designed?
                lld_status = cab['lld_status']
                if lld_status != 'Preliminary Design':
                    count_LLD_Status_Incorrect += 1
                    cab_errors.append(
                        "LLD_Status_Incorrect"
                    )
                    # print(f"LLD Status not 'Preliminary Design': {lld_status}")
                    # dbox.append("LLD Status not 'Preliminary Design'.")

                cab["qc_errors"] = ', '.join(cab_errors) if len(cab_errors) > 0 else 'None'
                Cabinet_Boundary.updateFeature(cab)     
                cab_errors = []  # Reset errors for the next cabinet
                progress = int((idx / total) * 100)
                functionProgressBar.setValue(progress)  
        # Cabinet_Boundary.commitChanges()
        cabErrorDict = {   
            "Estimated HHP Missing": count_Estimated_HHP_Missing,
            "Estimated HHP Mismatch": count_Estimated_HHP_Mismatch,
            "Hub Size Invalid": count_Hub_Size_Invalid,
            "FDA Area ID Invalid": count_FDA_Area_ID_Invalid,
            "FDA Name Invalid": count_FDA_Name_Invalid,
            "FDA Name Area ID Null": count_FDA_Name_Area_ID_Null,
            "Wire Center Missing": count_Wire_Center_Missing,
            "FDA Name Incorrect Format": count_FDA_Name_Incorrect_Format,
            "LLD Status Incorrect": count_LLD_Status_Incorrect,
            "Zone Extraction Error": count_Zone_Extraction_Error,
            "FDA Name Zone Mismatch": count_FDA_Name_Zone_Mismatch
        }

        for key, value in cabErrorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
                # print(f"{key}: {value}")
                # dbox.append(f"{key}: {value}")
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Cabinet boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        print(f"Cabinet boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        dbox.append(f'')
        

    def _segments_(zone_cab_fda_name, f1_cab_fda_name):
        start_time = datetime.now()
        dbox.append('SEGMENT CHECKS')
        dbox.append('____________________________________________________________________________________________')
        # are segment
        # Collect errors for this layer
        segmentFdaNameCount = 0
        segmentTypeEmptyErrorCount = 0
        segmentTypeUdgDiameterErrorCount = 0
        segmentTypeUdgDuctCountErrorCount = 0
        segmentStatusErrorCount = 0
        if Segments.isEditable():
            Segments.commitChanges()
        with edit(Segments):
            features = list(Segments.getSelectedFeatures())
            total = len(features)
            for idx, segment in enumerate(features, 1):
                segmentErrors = []
                # segment_id = segment['segment_id']
                group = segment['group']
                segment_type = segment['segment_type']
                duct_diameter = segment['duct_diameter']
                duct_count = segment['duct_count']
                segment_status = segment['segment_status']
                segment_uuid = segment['uuid']
                hierarchy = segment['hierarchy']
                if hierarchy is None or hierarchy == '' or hierarchy == QVariant():
                    segmentErrors.append(
                        "Hierarchy_Missing"
                        # "Error_Description": f"Hierarchy is missing for segment {segment_uuid}.",
                        # "Geometry": segment.geometry()
                    )
                    # print(f"Hierarchy is missing for segment {segment_uuid}.")
                    # dbox.append(errorFormat.format(f"Hierarchy is missing for segment {segment_uuid}."))
                else:
                    if group != zone_cab_fda_name and hierarchy in ['2', '4', 'F2', 'F0']:
                        segmentFdaNameCount += 1
                        segmentErrors.append(
                            "FDA_Name_Mismatch F2 F0"
                            # "Error_Description": f"Group {group} does not match FDA Name {cab_fda_name} for segment {segment_uuid}.",
                            # "Geometry": segment.geometry()
                        )
                    if group != f1_cab_fda_name and hierarchy in ['1', 'F1']:
                        segmentFdaNameCount += 1
                        segmentErrors.append(
                            "FDA_Name_Mismatch F1"
                            # "Error_Description": f"Group {group} does not match FDA Name {cab_fda_name} for segment {segment_uuid}.",
                            # "Geometry": segment.geometry()
                        )

                # Check 1: Segment ID matches Area ID
                # if segment_id != project_name:
                #     print(f"Segment ID {segment_id} does not match cabinet Area ID {project_name} for segment {segment_uuid}.")
                #     dbox.append(f"Segment ID {segment_id} does not match cabinet Area ID {project_name} for segment {segment_uuid}.")

                # Check 2: Group matches FDA Name
                
                    # print(f"Group {group} does not match FDA Name {cab_fda_name} for segment {segment_uuid}.")
                    # dbox.append(f"Group {group} does not match FDA Name {cab_fda_name} for segment {segment_uuid}.")

                # Check 3: Segment Type is Aerial or Underground
                if segment_type not in [2, 9, 'Aerial', 'Underground','(Aerial)', '(Underground)']:
                    segmentTypeEmptyErrorCount += 1
                    segmentErrors.append(
                        "Invalid_Segment_Type"
                        # "Error_Description": f"Invalid Segment Type {segment_type} for segment {segment_uuid}. Checking for Aerial or Underground.",
                        # "Geometry": segment.geometry()
                    )
                    # print(f"Invalid Segment Type {segment_type} for segment {segment_uuid}.")
                    # dbox.append(f"Invalid Segment Type {segment_type} for segment {segment_uuid}.")

                # Check 4: Duct Diameter is 1.25" if Segment Type is Underground
                if (segment_type in [9, 'Underground']) and duct_diameter not in ['1.25"',2]:
                    segmentTypeUdgDiameterErrorCount += 1
                    segmentErrors.append(
                        "Invalid_Duct_Diameter"
                        # "Error_Description": f"Duct Diameter {duct_diameter} is incorrect for Underground segment {segment_uuid}.",
                        # "Geometry": segment.geometry()
                    )
                    # print(f"Duct Diameter {duct_diameter} is incorrect for Underground segment {segment_uuid}.")
                    # dbox.append(f"Duct Diameter {duct_diameter} is incorrect for Underground segment {segment_uuid}.")

                # Check 5: Duct Count is 1 if Segment Type is Underground
                if (segment_type in [9, 'Underground']) and duct_count != 1:
                    segmentTypeUdgDuctCountErrorCount += 1
                    segmentErrors.append(
                        "Invalid_Duct_Count"
                        # "Error_Description": f"Duct Count {duct_count} is incorrect for Underground segment {segment_uuid}.",
                        # "Geometry": segment.geometry()
                    )
                    # print(f"Duct Count {duct_count} is incorrect for Underground segment {segment_uuid}.")
                    # dbox.append(f"Duct Count {duct_count} is incorrect for Underground segment {segment_uuid}.")

                # Check 6: Segment Status is Not Yet Fielded
                if segment_status in ['Not Yet Fielded', None]:
                    segmentStatusErrorCount += 1
                    segmentErrors.append(
                        "Invalid_Segment_Status"
                        # "Error_Description": f"Segment Status {segment_status} is incorrect for segment {segment_uuid}.",
                        # "Geometry": segment.geometry()
                    )
                    # print(f"Segment Status {segment_status} is incorrect for segment {segment_uuid}.")
                    # dbox.append(f"Segment Status {segment_status} is incorrect for segment {segment_uuid}.")
                segment["qc_errors"] = ', '.join(segmentErrors) if len(segmentErrors) > 0 else 'None'
                Segments.updateFeature(segment)    
                segmentErrors = []
                progress = int((idx / total) * 100)
                functionProgressBar.setValue(progress) 

        # logging errors
        segmentErrorsDict = {
            "FDA Name Mismatch": segmentFdaNameCount,
            "Invalid Segment Type": segmentTypeEmptyErrorCount,
            "Invalid Duct Diameter for Underground": segmentTypeUdgDiameterErrorCount,
            "Invalid Duct Count": segmentTypeUdgDuctCountErrorCount,
            "Invalid Segment Status": segmentStatusErrorCount
        }
        for key, value in segmentErrorsDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
                # print(f"{key}: {value}")
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Segments check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        print(f"Segments check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        dbox.append(f'')
    

    def _access_points_():
        start_time = datetime.now()
        dbox.append('ACCESS POINTS CHECKS')
        dbox.append('____________________________________________________________________________________________')
        groupFdaErrorCount = 0
        accessPointTypeErrorCount = 0
        if Access_Point.isEditable():
            Access_Point.commitChanges()
        with edit(Access_Point):
            features = list(Access_Point.getSelectedFeatures())
            total = len(features)
            for idx, ap in enumerate(features, 1):
                ap_errors = []
                access_point_uuid = ap['UUID']
                group = ap['Group']
                group_2 = ap['Group 2']
                access_point_type = ap['Type']
                # area_id = ap['area_id']  # From Cabinet_Boundary

                # # Check 1: Segment ID matches Area ID
                # if access_point_uuid != area_id:
                #     print(f"Access Point UUID {access_point_uuid} does not match Area ID {area_id} for access point {ap.id()}.")
                #     dbox.append(f"Access Point UUID {access_point_uuid} does not match Area ID {area_id} for access point {ap.id()}.")

                # Check 2: Group matches FDA Name
                if group != zone_cab_fda_name and group_2 != zone_cab_fda_name:
                    print(f"Group {group} or Group 2 {group_2} does not match FDA Name {zone_cab_fda_name} for access point {access_point_uuid}.")
                    groupFdaErrorCount += 1
                    ap_errors.append(
                        "FDA_Name_Mismatch"
                        # "Error_Description": f"Group {group} or Group 2 {group_2} does not match FDA Name {cab_fda_name} for access point {access_point_uuid}.",
                        # "Geometry": ap.geometry()
                    )
                    # print(f"Group {group} or Group 2 {group_2} does not match FDA Name {cab_fda_name} for access point {access_point_uuid}.")
                    # dbox.append(f"Group {group} or Group 2 {group_2} does not match FDA Name {cab_fda_name} for access point {access_point_uuid}.")

                # Check 3: Type is Handhole
                if access_point_type != 'Handhole':
                    accessPointTypeErrorCount += 1
                    ap_errors.append(
                        "Invalid_Access_Point_Type"
                        # "Error_Description": f"Access Point Type {access_point_type} is not Handhole for access point {access_point_uuid}.",
                        # "Geometry": ap.geometry()
                    )
                    # print(f"Access Point Type {access_point_type} is not Handhole for access point {access_point_uuid}.")
                    # dbox.append(f"Access Point Type {access_point_type} is not Handhole for access point {access_point_uuid}.")
                ap["qc_errors"] = ', '.join(ap_errors) if len(ap_errors) > 0 else 'None'
                Access_Point.updateFeature(ap) 
                ap_errors = []   
        # logging errors
        accessPointErrorsDict = {
            "FDA Name Mismatch": groupFdaErrorCount,
            "Invalid Access Point Type": accessPointTypeErrorCount
        }
        for key, value in accessPointErrorsDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
                # print(f"{key}: {value}")
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Access Point check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        print(f"Access Point completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        dbox.append(f'')

    
        

    if len(geom_checks)>0:
        __invalid_geoms__(dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks)
    else:
        print('geometry check box not checked')
    progressBar.setValue(12)
    if qcCheckButton:
        if "Sites" in qcChecks:
            _sites_()
        progressBar.setValue(25)
        if "Poles" in qcChecks:
            _poles_()
        progressBar.setValue(33)
        if "Cabinets" in qcChecks:
            _cab_()
        progressBar.setValue(45)
        if "Segments" in qcChecks:
            _segments_(zone_cab_fda_name, f1_cab_fda_name)
        progressBar.setValue(66)
        if "Access Points" in qcChecks:
            _access_points_()
        dbox.append(f'QC Plugin Complete \u2713')
    full_end_time = datetime.now()
    full_elapsed = full_end_time - full_start_time
    dbox.append(f"Whole program complete time in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
    print(f"Whole program check completed in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
    dbox.append(f'Finished at {datetime.now()}')
    progressBar.setValue(100)

    

def proximity_checks():
        #Every Site is within 410' of an Aerial segment or within 310' of an UG segment
        boundSites = layerExtractionConverter('Site', bound)     
        segments = layerExtractionConverter('Segments', bound)
        seg_ae = processing.run("native:extractbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        seg_ug =  processing.run("native:extractbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'9','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        seg_ae_buff = processing.run("native:buffer", {'INPUT':seg_ae,'DISTANCE':409.99917999999894,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        seg_ug_buff = processing.run("native:buffer", {'INPUT':seg_ug,'DISTANCE':309.9993799999992,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        seg_buff_merged =  processing.run("native:mergevectorlayers", {'LAYERS':[seg_ae_buff, aeg_ug_buff],'CRS':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        processing.run("native:selectbylocation", {'INPUT': boundSites,'PREDICATE':[0],'INTERSECT':seg_buff_merged,'METHOD':0})
        boundSites.invertSelection()
        site_segment_proximity = boundSites.selectedFeatureCount()