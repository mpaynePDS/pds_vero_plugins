# -*- coding: utf-8 -*-
"""
Created on Monday, July 21, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __permit_pole__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat):
    try:
        dbox.append(f'Footage Calculation at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()
        # define AOI boundary + create output folder
        project_name = bound
        dbox.append(str(project_name))
        proj_folder= f'{outputfolder}\\QC_{str(project_name)}'
        if not os.path.exists(proj_folder):
                os.mkdir(proj_folder)
        #layers
        fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
        poles = project.mapLayersByName('Pole')[0]
        segments = project.mapLayersByName('Segments')[0]
        permits = project.mapLayersByName('Permits')[0]

        start_time = datetime.now()
        dbox.append('PERMITTING POLE CHECK')
        dbox.append('____________________________________________________________________________________________')
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':fda_boundary, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        processing.run("native:selectbylocation", {'INPUT':poles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        selectedPoles = processing.run("native:saveselectedfeatures", {'INPUT':poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        
        #AE Segments
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("qgis:selectbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'2','METHOD':3}) #selecting within current selection , value 2 = aerial   
        #remove poles that intersect aerial segments from selection, remaining is poles that do NOT interesct aerial segment, but MAY intersect UG segment
        selectedPoles.selectAll()
        processing.run("native:selectbylocation", {'INPUT':selectedPoles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':3})
        internal_permit_ids = []
        permit_numbers = []
        for f in permits.getFeatures():
            if f['internal_permit_id'] not in [None, '']:
                internal_permit_ids.append(f['internal_permit_id'])
            if f['permit_number'] not in [None, '']:
                permit_numbers.append(f['permit_number'])
        
        poles_not_attached_AE_segment = []
        for f in selectedPoles.selectedFeatures():
            poles_not_attached_AE_segment.append(f['uuid'])
        try:
            errorDict = {
                "Attach Invalid": 0,
                "Attach/Owner/MRE Flag": 0,
                'AE Segment Not Snapped to "Yes" Pole': 0,
                'AE Segment Snapped to "No" Pole':0, 
                'Permit Required':0, 
                'Assigned Permit Not In Permit Layer':0,
                'Pole is "No" with Permit Assigned':0
            }
            total = poles.selectedFeatureCount()
            error_uuids = []
            if poles.isEditable():
                poles.commitChanges()
            
            with edit(poles):
                for idx, f in enumerate(poles.selectedFeatures(), 1):
                    f_errors = []
                    if f['attach'] is [None, '']:
                        errorDict['Attach Invalid'] += 1
                        error_uuids.append(f['uuid'])
                        f_errors.append('Attach_Invalid')
                    else:
                        if f['attach'] in ['Yes', 'yes'] and f['pole_owner'] in ['ATT', 'AT&T', 'att'] and f['make_ready_type'] in ['Power MR', 'Simple Power', 'LightPower', 'Power Rearrangement']:
                            errorDict['Attach/Owner/MRE Flag'] += 1
                            error_uuids.append(f['uuid'])
                            f_errors.append('Attach/Owner/MRE_Flag')
                        if f['attach'] in ['Yes', 'yes'] and f['uuid'] in poles_not_attached_AE_segment:
                            errorDict['AE Segment Not Snapped to "Yes" Pole'] += 1
                            error_uuids.append(f['uuid'])
                            f_errors.append('AE_Segment_Not_Snapped_To_"Yes"_Pole')
                        elif f['attach'] in ['No', 'no'] and f['uuid'] not in poles_not_attached_AE_segment:
                            errorDict['AE Segment Snapped to "No" Pole'] += 1
                            error_uuids.append(f['uuid'])
                            f_errors.append('AE_Segment_Snapped_To_"No"_Pole')
                        if f['attach'] in ['Yes', 'yes'] and f['permit'] in [None, '']:
                            errorDict['Permit Required'] +=1
                            error_uuids.append(f['uuid'])
                            f_errors.append('Permit_Required')
                        elif f['attach'] in ['Yes', 'yes'] and (f['permit'] not in permit_numbers and f['mr_notes'] not in [internal_permit_ids]):
                            errorDict['Assigned Permit Not In Permit Layer'] +=1
                            error_uuids.append(f['uuid'])
                            f_errors.append('Assigned_Permit_Not_In_Permit_Layer')
                        elif f['attach'] in ['No', 'no'] and (f['permit'] not in [None, ''] or f['mr_notes'] not in [None, '']):
                            errorDict['Pole is "No" with Permit Assigned'] += 1
                            error_uuids.append(f['uuid'])
                            f_errors.append('Pole_is_"No"_with_Permit_Assigned')
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    poles.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
            if len(error_uuids)>0:
                processing.run("qgis:selectbyexpression", {'INPUT':poles,'EXPRESSION':f"uuid in {str(tuple(error_uuids))}",'METHOD':0})
                badPoles = processing.run("native:saveselectedfeatures", {'INPUT':poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                QgsProject.instance().addMapLayer(badPoles)
                badPoles.setName("Pole_Permitting_Errors")
            else:
                poles.removeSelection()
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        if len(error_uuids)>0:
            #dbox.append('\n'.join(list(set(error_uuids))))
            dbox.append(warningFormat.format('***See selected features on pole layer.***'))
        else:
            dbox.append(validFormat.format('No errors detected.'))

        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Pole check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  