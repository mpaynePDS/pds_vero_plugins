# -*- coding: utf-8 -*-
"""
Created on Tues July 25, 2025
Vero QC - geometry Checks
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__network_trace__ import __network_trace__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject,QgsSpatialIndex, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsPointXY, QgsVectorLayer, QgsVectorLayerJoinInfo,\
                     edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest, QgsFeature,QgsField, QgsFields,QgsCoordinateReferenceSystem
from qgis import processing
from qgis.utils import iface
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime
canvas = iface.mapCanvas()

def __invalid_geoms__(project_name, dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks):
    print('invalid geoms')
    full_start_time = datetime.now()
    dbox.append('CHECKING GEOMETRIES')
    dbox.append('____________________________________________________________________________________________')
    invalid = False
    dbox.append(str(geom_checks))
        
    def check_and_export_geometry_issues(layer):
        if not layer or not layer.isValid():
            dbox.append(f"Layer '{layer.name()}' is not valid.")
            return

        expected_type = QgsWkbTypes.geometryType(layer.wkbType())
        type_name = QgsWkbTypes.displayString(layer.wkbType())
        dbox.append(f"\n🔍 Checking layer: {layer.name()} ({type_name})")

        null_ids = []
        empty_ids = []
        invalid_ids = []
        type_mismatch_ids = []
        error_features = []

        for feature in layer.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([])):
            fid = feature.id()
            geom = feature.geometry()

            if geom is None or geom.isNull():
                null_ids.append(fid)
                #error_features.append((feature, "Null")) #Automatically Deleted
                continue

            if geom.isEmpty():
                empty_ids.append(fid)
                #error_features.append((feature, "Empty")) #Automatically Deleted

            if not geom.isGeosValid():
                invalid_ids.append(fid)
                error_features.append((feature, "Invalid"))

            if QgsWkbTypes.geometryType(geom.wkbType()) != expected_type:
                type_mismatch_ids.append(fid)
                error_features.append((feature, "TypeMismatch"))
        
        #delete Null and Empty Geometries
        delete_ids = list(set(null_ids + empty_ids))
        
        if delete_ids:
            if not layer.isEditable():
                layer.startEditing()
            res = layer.deleteFeatures(delete_ids)
            layer.commitChanges()
        dbox.append(f"🗑️ Deleted {len(delete_ids)} features with Null or Empty geometries.")

        # Select problematic features
        all_problem_ids = list(set(invalid_ids + type_mismatch_ids))
        layer.selectByIds(all_problem_ids)
        dbox.append(f"  Invalid geometries: {len(invalid_ids)}")
        dbox.append(f"  Type mismatches: {len(type_mismatch_ids)}")
        dbox.append(f"  Total selected: {len(all_problem_ids)}")

        # Optional: Export to memory layer
        if error_features:
            export_errors_to_memory_layer(layer, error_features)

    def export_errors_to_memory_layer(source_layer, error_features):
        crs = source_layer.crs()
        geom_type = QgsWkbTypes.displayString(source_layer.wkbType())
        mem_layer = QgsVectorLayer(f"{geom_type}?crs={crs.authid()}", f"{source_layer.name()}_GeometryErrors", "memory")
        mem_provider = mem_layer.dataProvider()

        # Copy fields + add error type field
        fields = source_layer.fields()
        fields.append(QgsField("ErrorType", QVariant.String))
        mem_provider.addAttributes(fields)
        mem_layer.updateFields()

        new_features = []
        for feature, error_type in error_features:
            new_feat = QgsFeature()
            new_feat.setGeometry(feature.geometry())
            attrs = feature.attributes() + [error_type]
            new_feat.setAttributes(attrs)
            new_features.append(new_feat)

        mem_provider.addFeatures(new_features)
        QgsProject.instance().addMapLayer(mem_layer)
        print(f"✅ Exported {len(new_features)} error features to memory layer: {mem_layer.name()}")

    def feature_snapping_direction_overlaps(project_name):
        # Parameters
        SNAP_TOLERANCE = 0  # feet

        # Layers
        fiber_layer = QgsProject.instance().mapLayersByName("Fiber_Cable")[0]
        segment_layer = QgsProject.instance().mapLayersByName("Segments")[0]
        splicing_layer = QgsProject.instance().mapLayersByName("Splicing")[0]
        network_element_layer = QgsProject.instance().mapLayersByName("Network_Element")[0]
        pole_layer = QgsProject.instance().mapLayersByName("Pole")[0]
        access_layer = QgsProject.instance().mapLayersByName("Access_Point")[0]
        site_layer = QgsProject.instance().mapLayersByName("Site")[0]
        cabinet_layer = QgsProject.instance().mapLayersByName("Cabinet_Boundary")[0]
        nap_layer = QgsProject.instance().mapLayersByName("NAP_Boundary")[0]
        permit_layer = QgsProject.instance().mapLayersByName("Permits")[0]
        try:
            unfielded_pole_layer =  QgsProject.instance().mapLayersByName("Unfielded_Pole")[0]
        except:
            unfielded_pole_layer = None
        #Selected Boundary
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':cabinet_layer, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        
         # Build spatial indexes
        pole_redux = processing.run("native:extractbylocation", {'INPUT':pole_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        if unfielded_pole_layer:
            unfielded_pole_redux = processing.run("native:extractbylocation", {'INPUT':unfielded_pole_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        access_redux = processing.run("native:extractbylocation", {'INPUT':access_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        site_redux = processing.run("native:extractbylocation", {'INPUT':site_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        pole_index = QgsSpatialIndex(pole_redux.getFeatures())
        unfielded_pole_index  = QgsSpatialIndex(unfielded_pole_redux.getFeatures()) if unfielded_pole_layer is not None else None
        site_index = QgsSpatialIndex(site_redux.getFeatures())
        access_index = QgsSpatialIndex(access_redux.getFeatures())
        # Build spatial indexes
        # pole_index = QgsSpatialIndex(pole_layer.getFeatures())
        #unfielded_pole_index  = QgsSpatialIndex(unfielded_pole_redux.getFeatures()) if unfielded_pole_layer is not None else None
        #access_index = QgsSpatialIndex(access_layer.getFeatures())
        #site_index = QgsSpatialIndex(site_layer.getFeatures())
        borePit_index = QgsSpatialIndex()
        for f in network_element_layer.getFeatures():
            if f["element_type"] == 3 and f.hasGeometry():
                borePit_index.insertFeature(f)


        # Helper: check if point is snapped to pole or access_point
        def is_snapped(point_geom, type = None):
            #buffer = point_geom.buffer(SNAP_TOLERANCE, 5)
            buffer = point_geom
            pole_ids = pole_index.intersects(buffer.boundingBox())
            access_ids = access_index.intersects(buffer.boundingBox())
            unfielded_pole_ids = unfielded_pole_index.intersects(buffer.boundingBox()) if unfielded_pole_index is not None else None

            if type == 'Drop': #originally this was drop end but realistically, they're not even directionally correct. Either start or end point could be on address.
                site_ids = site_index.intersects(buffer.boundingBox())
                if unfielded_pole_ids is not None:
                    return pole_ids or access_ids or site_ids or unfielded_pole_ids
                else:
                    return pole_ids or access_ids or site_ids
            elif type == 'Line':
               
                borePit_ids = borePit_index.intersects(buffer.boundingBox())
                return pole_ids or access_ids or borePit_ids

            else:
                return pole_ids or access_ids
        
        def snap_point_to_nearest(point_geom, type = None):
            buffer = point_geom.buffer(5, 5)
            nearest = None
            min_dist = float("inf")
            if type == 'Drop':
                if unfielded_pole_layer:
                    valid_endpoints = [(pole_redux, pole_index), (unfielded_pole_redux, unfielded_pole_index), (access_redux, access_index), (site_redux, site_index)]
                else:
                    valid_endpoints = [(pole_redux, pole_index), (access_redux, access_index), (site_redux, site_index)]
            else:
                valid_endpoints = [(pole_redux, pole_index), (access_redux, access_index)]
            for layer, index in valid_endpoints:
                ids = index.intersects(buffer.boundingBox())
                for fid in ids:
                    feat = next(layer.getFeatures(QgsFeatureRequest(fid)))
                    candidate_geom = feat.geometry()
                    dist = point_geom.distance(candidate_geom)
                    if dist < min_dist:
                        min_dist = dist
                        nearest = candidate_geom

            return nearest if nearest else point_geom  # fallback to original

        def validate_and_snap_line_endpoints(layer, layer_name):
            selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':cabinet_layer, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            if any("Fix Snapping" in x for x in geom_checks):
                layer.startEditing()
                unsnapped_layer_name = f"unsnapped_{layer_name}"
                existing_layer = QgsProject.instance().mapLayersByName(unsnapped_layer_name)
                if not existing_layer:
                    unsnapped_layer = QgsVectorLayer("LineString?crs={source_crs}", f"unsnapped_{layer_name}", "memory")
                    unsnapped_layer.dataProvider().addAttributes(layer.fields())
                    unsnapped_layer.updateFields()
                    QgsProject.instance().addMapLayer(unsnapped_layer)
                else:
                   unsnapped_layer = existing_layer[0] 
                unsnapped_layer.startEditing()


            if any("Snapping" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
                total = layer.selectedFeatureCount()
            else:
                features = layer.getFeatures()
                total = layer.featureCount()
            
            for idx, feature in enumerate(features):

                geom = feature.geometry()
                uuid = feature["uuid"]
                name = feature['cable_name'] if layer_name == 'Fiber_Cable' else None

                if not geom or geom.isEmpty() or geom.type() != QgsWkbTypes.LineGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {uuid} has invalid geometry.")
                    continue

                line = geom.constGet()
                start_pt = QgsGeometry.fromPointXY(QgsPointXY(line.startPoint()))
                end_pt = QgsGeometry.fromPointXY(QgsPointXY(line.endPoint()))

                snapped_start = start_pt
                snapped_end = end_pt
                changed = False
                if layer.name() == 'Fiber_Cable':
                    feature['tags'] == 5 # Drop
                    type = 'Drop'
                else:
                    type = "Line"
                not_snapped = False
                if not is_snapped(start_pt, type):
                    if any("Fix Snapping" in x for x in geom_checks):
                        snapped_start = snap_point_to_nearest(start_pt, type)
                        if snapped_start != start_pt:
                            changed = True
                            dbox.append(f"[FIXED] {layer_name} Feature {uuid} start point snapped.")
                            start_pt = snapped_start
                        else:
                            dbox.append(f"[ERROR] {layer_name} Feature {uuid} start point not snapped, nearest valid point not found within 5 feet.")
                            not_snapped = True
                    else:
                        dbox.append(f"[ERROR] {layer_name} Feature {uuid} start point not snapped.")
                if not is_snapped(end_pt, type):
                    if any("Fix Snapping" in x for x in geom_checks):
                        snapped_end = snap_point_to_nearest(end_pt, type)
                        if snapped_end != end_pt:
                            changed = True
                            dbox.append(f"[FIXED] {layer_name} Feature {uuid} end point snapped.")
                            end_pt = snapped_end
                        else:
                            dbox.append(f"[ERROR] {layer_name} Feature {uuid} end point not snapped, nearest valid point not found within 5 feet.")
                            not_snapped = True
                    else:
                         dbox.append(f"[ERROR] {layer_name} Feature {uuid} end point not snapped.")
                if any("Fix Snapping" in x for x in geom_checks):
                    if changed:
                        '''new_geom = QgsGeometry.fromPolylineXY([
                            QgsPointXY(snapped_start.asPoint()),
                            QgsPointXY(snapped_end.asPoint())
                        ])'''#This changed the whole geometry to just the start and endpoint, eliminating everything in between.
                        points = geom.asPolyline()
                        points[0] = snapped_start.asPoint()
                        points[-1] = snapped_end.asPoint()
                        new_geom = QgsGeometry.fromPolylineXY(points)
                        layer.changeGeometry(feature.id(), new_geom)
                    
                    if not_snapped:
                        #new_feat = QgsFeature()
                        #new_feat.setGeometry(feature.geometry())
                        #new_feat.setAttributes(feature.attributes())
                        #unsnapped_layer.addFeature(new_feat)
                        new_feat = QgsFeature(feature)
                        unsnapped_layer.addFeature(new_feat)


                if idx % 10 == 0:
                    progress = int((idx / total) * 100)
                    QCoreApplication.processEvents()
                    functionProgressBar.setValue(progress)


            if any("Fix Snapping" in x for x in geom_checks):
                unsnapped_layer.commitChanges()
                layer.commitChanges()
                dbox.append('Changes Committed')
                if unsnapped_layer.featureCount() == 0:
                    QgsProject.instance().removeMapLayer(unsnapped_layer)


             #"Fix Directionality Errors"    
            if layer_name == 'Fiber_Cable':
                
                if any("Fix Directionality" in x for x in geom_checks):
                    __network_trace__(dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks)
                else:
                    start_points_by_name = {}
                    end_points_by_name = {}
                    if name not in [None, ''] and feature['cable_category'] != 2: #if not not drop...
                        if name in start_points_by_name:
                            if start_pt.equals(start_points_by_name[name]):
                                layer, uuid = get_snapped_uuid(start_pt)
                                dbox.append(f"[ERROR] fiber_cable '{name}' duplicate start/start at {layer} UUID {uuid}")
                        else:
                            start_points_by_name[name] = start_pt

                        if name in end_points_by_name:
                            if end_pt.equals(end_points_by_name[name]):
                                layer, uuid = get_snapped_uuid(end_pt)
                                dbox.append(f"[ERROR] fiber_cable '{name}' duplicate end/end at {layer} UUID {uuid}")
                        else:
                            end_points_by_name[name] = end_pt
                    elif name not in [None, ''] and feature['cable_category'] == 2: #is drop, but with a name
                        dbox.append(f"[ERROR] fiber_cable '{name}' has 'drop' category.")
                    elif name in [None, ''] and feature['cable_category'] == 2:
                        pass     

            # Helper: get UUID of snapped point
            def get_snapped_uuid(point_geom):
                buffer = point_geom.buffer(SNAP_TOLERANCE, 5)
                for layer, index in [(pole_redux, pole_index), (access_redux, access_index), (site_redux, site_index)]:
                    ids = index.intersects(buffer.boundingBox())
                    for fid in ids:
                        feat = next(layer.getFeatures(QgsFeatureRequest(fid)))
                        if feat.geometry().intersects(buffer):
                            return layer.name(), feat["uuid"]
                return None, None

        # Helper: validate point snapping
        def validate_point_layer(layer, layer_name):
            selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':cabinet_layer, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']

            if any("Fix Snapping" in x for x in geom_checks):
                if layer.isEditable():
                    layer.commitChanges()
                layer.startEditing()
                unsnapped_layer_name = f"unsnapped_{layer_name}"
                existing_layer = QgsProject.instance().mapLayersByName(unsnapped_layer_name)
                if not existing_layer:
                    unsnapped_layer = QgsVectorLayer("Point?crs={source_crs}", f"unsnapped_{layer_name}", "memory")
                    unsnapped_layer.dataProvider().addAttributes(layer.fields())
                    unsnapped_layer.updateFields()
                    QgsProject.instance().addMapLayer(unsnapped_layer)
                else:
                   unsnapped_layer = existing_layer[0] 
                unsnapped_layer.startEditing()

            if any("Snapping" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
            else:
                features = layer.getFeatures()
            

            for feature in features:
                if layer.name() == 'Network_Element':
                    if feature['element_type'] in [1,2,4]: #1: Anchor, 2: Riser, 3: Slack , 4: Bore Pit
                        continue #if anchor or bore pit, skip it, they should not be snapped.
                geom = feature.geometry()
                uuid = feature['uuid']

                if not geom or geom.isEmpty() or geom.type() != QgsWkbTypes.PointGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {uuid} has invalid geometry.")
                    continue
                not_snapped = False
                if not is_snapped(geom):
                    if any("Fix Snapping" in x for x in geom_checks):
                        snapped_start = snap_point_to_nearest(geom)
                        if snapped_start != geom:
                            changed = True
                            dbox.append(f"[FIXED] {layer_name} Feature {uuid} point snapped.")
                            success = layer.changeGeometry(feature.id(), snapped_start)
                            if not success:
                                print(f"[ERROR] Failed to update geometry for feature {feature['uuid']}")

                        else:
                            changed= False
                            dbox.append(f"[ERROR] {layer_name} Feature {uuid} point not snapped, nearest valid point not found within 5 feet.")
                            new_feat = QgsFeature(feature)
                            unsnapped_layer.addFeature(new_feat)
                    else:
                        dbox.append(f"[ERROR] {layer_name} Feature {uuid} point not snapped.")
            
            if any("Fix Snapping" in x for x in geom_checks):
                layer.commitChanges() 
                unsnapped_layer.commitChanges()  
                dbox.append('Changes Comittted')  
                if unsnapped_layer.featureCount() == 0:
                    QgsProject.instance().removeMapLayer(unsnapped_layer)
           
            
        def validate_polygon_layer(layer, layer_name):
            if any("Snapping" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = list(layer.getSelectedFeatures())
            else:
                features = list(layer.getFeatures())

            id_to_uuid = {f.id(): f["uuid"] for f in features}
            uuid_to_feature = {f["uuid"]: f for f in features}

            #feature_dict = {f['uuid']: f for f in features}
            index = QgsSpatialIndex(layer.getFeatures())  # Build index for fast overlap checks

            for feat in features:
                uuid = feat['uuid']
                geom = feat.geometry()
                if not geom or geom.isEmpty() or geom.type() != QgsWkbTypes.PolygonGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {uuid} has invalid geometry.")
                    continue
                # Check single-part
                if geom.isMultipart():
                    dbox.append(f"[ERROR] {layer_name} Feature {uuid} is multipart.")
                # Check for interior overlaps
                if layer.name() == 'Cabinet_Boundary':
                    if not feat['fda_name'] or not feat['area_id']:
                        raise ValueError('Error! Cabinet without Area_ID or FDA_Name. Cannot determine Hierarchy or overlap permission.')
                    elif any(x in feat['area_id'] for x in ['F0', 'F1']):
                        continue #skip if not F2. F1 and F0 can overlap.
                bbox = geom.boundingBox()
                candidate_ids = index.intersects(bbox)

                for cid in candidate_ids:
                    other_uuid = id_to_uuid.get(cid)
                    if other_uuid == uuid:
                        continue  # Skip self

                    other_feat = uuid_to_feature.get(other_uuid)
                    if not other_feat:
                        continue

                    other_geom = other_feat.geometry()

                    if not other_geom or other_geom.isEmpty():
                        continue

                    # Check if interiors intersect (not just touching)
                    if geom.intersects(other_geom) and not geom.touches(other_geom):
                        dbox.append(f"[ERROR] {layer_name} Feature {uuid} overlaps with Feature {other_feat['uuid']}")


        def validate_no_overlaps(layer, layer_name):
            selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':cabinet_layer, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']

            if any("Overlaps" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
                total = layer.selectedFeatureCount()
            else:
                features = layer.getFeatures()
                total = layer.featureCount()
            index = QgsSpatialIndex(features)

            id_to_uuid = {f.id(): f["uuid"] for f in layer.getSelectedFeatures()}
            uuid_to_feature = {f["uuid"]: f for f in layer.getSelectedFeatures()}
            id_to_geom = {f.id(): f.geometry() for f in layer.getSelectedFeatures()}

            errors = []
            dbox.append(str(total))
            dbox.append(layer.name())
            for idx, feature in enumerate(layer.getSelectedFeatures(), 1):
                geom = feature.geometry()
                uuid = feature["uuid"]
                if not geom or geom.isEmpty():# or geom.type() != QgsWkbTypes.PolygonGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {uuid} has invalid geometry.")
                    continue
                # Check single-part
                if geom.isMultipart():
                    dbox.append(f"[ERROR] {layer_name} Feature {uuid} is multipart.")

                # Check for interior overlaps
                if layer.name() == 'Cabinet_Boundary':
                    if any(x in feature['fda_name'] for x in ['F0', 'F1']):
                        continue #skip if not F2. F1 and F0 can overlap.

                bbox = geom.boundingBox()
                candidate_ids = index.intersects(bbox)
                
                for cid in candidate_ids:
                    if cid == feature.id():
                        continue  # Skip self

                    other_geom = id_to_geom[cid]
                
                    if not other_geom or other_geom.isEmpty():
                        dbox.append('not other geom')
                        continue

                    if layer.name() != 'Permits':
                        # Disallow any intersection that isn't just touching
                        if (geom.intersects(other_geom) and not geom.touches(other_geom)) or geom.equals(other_geom):
                            dbox.append(f"[ERROR] {layer_name} Feature {uuid} overlaps with Feature {id_to_uuid[cid]}")
                    else:
                        #Permits may overlap, but cannot be the same geometry
                        if geom.equals(other_geom):
                            dbox.append(f"[ERROR] {layer_name} Feature {uuid} geometry is same as Feature {id_to_uuid[cid]}")


        # Validate other layers, #we do not validate pole or access_point features since those are considered to be the backbone structure of the network. Proximity is checked in attributes.
        try:
            if any("Snapping" in x for x in geom_checks) or any("Fix" in x for x in geom_checks):
                progressBar.setValue(5)
                dbox.append('-Segments-')
                validate_and_snap_line_endpoints(segment_layer, "Segments")
                QCoreApplication.processEvents()
                progressBar.setValue(10)
                dbox.append('-Fiber Cable')
                validate_and_snap_line_endpoints(fiber_layer, "Fiber_Cable")
                QCoreApplication.processEvents()
                progressBar.setValue(15)
                dbox.append('-Splicing-')
                validate_point_layer(splicing_layer, "Splicing")
                QCoreApplication.processEvents()
                progressBar.setValue(20)
                dbox.append('-Network Element-')
                validate_point_layer(network_element_layer, "Network_Element")
                QCoreApplication.processEvents()
                progressBar.setValue(25)
                dbox.append('-Cabinet Boundary-')
                validate_polygon_layer(cabinet_layer, "Cabinet_Boundary")
                QCoreApplication.processEvents()
                progressBar.setValue(30)
                dbox.append('-NAP Boundary-')
                validate_polygon_layer(nap_layer, "NAP_Boundary")
                QCoreApplication.processEvents()
                progressBar.setValue(35)
                
            #Overlaps & Stacked Features
            if any("Overlaps" in x for x in geom_checks):
                dbox.append(' \nChecking Overlaps\n ')
                validate_no_overlaps(segment_layer, "Segments")
                QCoreApplication.processEvents()
                progressBar.setValue(55)
                validate_no_overlaps(pole_layer, "Pole")
                QCoreApplication.processEvents()
                progressBar.setValue(65)
                validate_no_overlaps(access_layer, "Access_Point")
                QCoreApplication.processEvents()
                progressBar.setValue(75)
                validate_no_overlaps(permit_layer, "Permits")
                QCoreApplication.processEvents()
                progressBar.setValue(85)
                validate_no_overlaps(site_layer, "Site")
                QCoreApplication.processEvents()
        except Exception as e:
            dbox.append(errorFormat.format(str(e)))
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
            
    
    # 🔁 Run on all vector layers
    '''geom_checks = [
        geometriesListWidget.item(i).text()
        for i in range(geometriesListWidget.count())
        if geometriesListWidget.item(i).checkState() == Qt.Checked
    ]'''
    try:
        canvas.setRenderFlag(False)
        if any("Invalid" in x for x in geom_checks):
            dbox.append("Checking for null/missing geometries in Engineering Layers...") 
            #Remove any existing "GeometryErrors" layers to remove clutter
            for layer in QgsProject.instance().mapLayers().values(): 
                if 'GeometryErrors' in layer.name():
                    QgsProject.instance().removeMapLayer(layer.id())
            #process Engineering Layers
            for layer in QgsProject.instance().mapLayers().values(): 
                if layer.type() == layer.VectorLayer and layer.name() in \
                    ['Access_Point', 'Cabinet_Boundary', 'Fiber_Cable', 'NAP_Boundary',\
                    'Network_Element', 'Pole', 'Segments', 'Permits','Site', 'Splicing']:
                    check_and_export_geometry_issues(layer)
        if any("Snapping" in x for x in geom_checks) or any("Fix" in x for x in geom_checks) or any("Overlaps" in x for x in geom_checks):
            dbox.append('Checking Snapping Errors...')
            feature_snapping_direction_overlaps(project_name)
        full_end_time = datetime.now()
        full_elapsed = full_end_time - full_start_time
        dbox.append(f"Whole program complete time in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
        print(f"Whole program check completed in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
        dbox.append(f'Finished at {datetime.now()}')
        progressBar.setValue(100)
        functionProgressBar.setValue(100)
    except Exception as e:
        dbox.append(errorFormat.format(str(e)))
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

    finally:
        canvas.setRenderFlag(True)       











