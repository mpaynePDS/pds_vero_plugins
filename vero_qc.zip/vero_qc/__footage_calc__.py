# -*- coding: utf-8 -*-
"""
Created on Monday, July 21, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __footage_calc__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat):
    try:
        dbox.append(f'Footage Calculation at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()
        # define AOI boundary + create output folder
        project_name = bound
        dbox.append(str(project_name))
        proj_folder= f'{outputfolder}\\QC_{str(project_name)}'
        if not os.path.exists(proj_folder):
                os.mkdir(proj_folder)
        #layers
        fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
        segments = project.mapLayersByName('Segments')[0]

        #--------------------------------------
        
        #bound = processing.run("native:extractbyexpression", {'INPUT':fda_boundary, 'EXPRESSION': f'"area_id" LIKE \'%{project_name}%\'','OUTPUT': f'{proj_folder}\\bound.gpkg'})['OUTPUT']
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':fda_boundary, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        segment_id = None
        for f in fda_boundary.selectedFeatures():
            if f['segment_id'] not in [None, ''] and '-' in f['segment_id']:
                segment_id = f['segment_id']
            break
        if segment_id in [None, '']:
            dbox.append(errorFormat.format('The Segment ID for the selected Boundary is NULL or BLANK. Add a Segment ID to continue.'))
            return
        intersecting_bounds = processing.run("native:extractbylocation", {'INPUT':fda_boundary,'PREDICATE':[5],'INTERSECT':QgsProcessingFeatureSourceDefinition(fda_boundary.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        f0_dict = {}
        f1_dict = {}
        f1_f0_geoms = []
        for f in intersecting_bounds.getFeatures():
            if 'F0' in f['fda_name'] or 'F0' in f['area_id']:
                f0_dict[f['area_id']] = [f['segment_id'], f.geometry()]
                f1_f0_geoms.append(f.geometry())
            elif 'F1' in f['fda_name'] or 'F1' in f['area_id']:
                f1_dict[f['area_id']] = [f['segment_id'], f.geometry()]
                f1_f0_geoms.append(f.geometry())
        merged_f1f0 = QgsGeometry.unaryUnion(f1_f0_geoms)
        #segments "are within" = predicate 6
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[6],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        missing_segment_id = 0
        invalid_placement = 0
        ae_footage_total = 0
        ug_footage_total = 0
        unassigned_footage_total = 0
        invalid_segment_id = 0
        total = segments.selectedFeatureCount()
        for idx, f in enumerate(segments.selectedFeatures(), 1):
            if f['segment_id'] in [None, '']:
                missing_segment_id += 1
                unassigned_footage_total += f['calculated_length']
            elif f['segment_id'] != segment_id:
                geom = f.geometry()
                f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][-1])), None)
                if f0_segment_id is None:
                    f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][-1])), None)
                    if f1_segment_id is None:
                        if f['segment_id'] != segment_id: #f2
                            invalid_segment_id += 1
                            unassigned_footage_total += f['calculated_length']
                    elif f['segment_id'] != f1_segment_id:
                        dbox.append(f"{f['segment_id']} not {f1_segment_id}")
                        invalid_segment_id += 1
                        unassigned_footage_total += f['calculated_length']
                elif f['segment_id'] != f0_segment_id:
                    dbox.append(f"{f['segment_id']} not {f0_segment_id}")
                    invalid_segment_id += 1
                    unassigned_footage_total += f['calculated_length']
            elif f['segment_type'] not in [2,9]:
                invalid_placement += 1
                unassigned_footage_total += f['calculated_length']
            elif f['segment_type'] == 2:
                ae_footage_total += f['calculated_length']
            elif f['segment_type'] == 9:
                ug_footage_total += f['calculated_length']
            progress = int((idx / total) * 100)
            functionProgressBar.setValue(progress)
        if invalid_segment_id > 0:
            dbox.append(warningFormat.format(f'{str(invalid_segment_id)}/{str(total)} Segment Features with incorrect "segment_id" identifier. Calculation will be inaccurate.'))
        if missing_segment_id > 0:
            dbox.append(warningFormat.format(f'{str(missing_segment_id)}/{str(total)} Segment Features missing "segment_id" identifier. Calculation will be inaccurate.'))
        if invalid_placement > 0:
            dbox.append(warningFormat.format(f'{str(invalid_placement)}/{str(total)} Segment Features with invalid "type" that is not "Aerial" or "Underground". Calculation will be inaccurate.'))
        dbox.append(warningFormat.format(f'Unassigned Segment Footage: {unassigned_footage_total:,.2f} ft'))
        dbox.append(f'Aerial Segment Footage Total: {ae_footage_total:,.2f} ft')
        dbox.append(f'Underground Segment Footage Total: {ug_footage_total:,.2f} ft')
        dbox.append(f'Combined Segment Footage Total (AE+UG): {ae_footage_total + ug_footage_total:,.2f} ft')
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
    

                 

