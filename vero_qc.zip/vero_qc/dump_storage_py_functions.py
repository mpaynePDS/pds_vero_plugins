# finds invalid geoms and save to memory layer

# for feature in layr.getFeatures():
#     geom = feature.geometry()
#     if geom is None or geom.isEmpty() or not geom.isGeosValid():  # Check for null or invalid geometries
#         invalid_features.append(feature)
# if invalid_features:
#     # Create a memory layer for invalid features
#     temp_layer = QgsVectorLayer(
#         "Point?crs=" + layr.crs().authid(),  # Adjust geometry type if needed
#         f"bad_geometry_{lyr.lower()}",
#         "memory"
#     )
#     temp_provider = temp_layer.dataProvider()
    
#     # Add UUID field to the temporary layer
#     temp_provider.addAttributes([QgsField("UUID", QVariant.String)])
#     temp_layer.updateFields()
    
#     # Add invalid features to the temporary layer
#     for invalid_feature in invalid_features:
#         temp_feature = QgsFeature()
#         temp_feature.setGeometry(invalid_feature.geometry())
#         temp_feature.setAttributes([invalid_feature["uuid"]])
#         temp_provider.addFeature(temp_feature)
#     # Add the temporary layer to the project
#     QgsProject.instance().addMapLayer(temp_layer)
#     print(f"Invalid features saved to: bad_geometry_{lyr}")
# else:
#     print(f"No invalid geometries found in layer: {lyr}")



        # progressBar.setValue(5)


#  this function and for loop is used to get the key value pairs for ValueRelation or "Domain" and then count the amount of times that value comes up in a layer

# def value_counts(layer, field_name):
#     from collections import Counter
#     values = [feature[field_name] for feature in layer.getFeatures()]
#     field_index = layer.fields().indexFromName(field_name)
#     editor_widget = layer.editorWidgetSetup(field_index)
#     text_value = {}
#     if editor_widget.type() == "ValueRelation":
#             # Get the configuration of the Value Relation
#             config = editor_widget.config()
#             related_layer = QgsProject.instance().mapLayer(config["Layer"])  # Related layer
#             key_field = config["Key"]  # Key field in the related layer
#             value_field = config["Value"]  # Display field in the related layer

#             # Create a mapping of key to value
#             value_relation_map = {
#                 feature[key_field]: feature[value_field]
#                 for feature in related_layer.getFeatures()
#             }

#             # Iterate through features in the main layer and get the text version
#             for feature in layer.getFeatures():
#                 key = feature[field_name]
#                 text_value[key] = value_relation_map.get(key, "Unknown")
#     counterValues = Counter(values)
#     for key, count in counterValues.items():
#         if key in text_value:
#             print(f"{text_value[key]}: {count}")
#         else:
#             print(f"{key}: {count}")
#     else:
#         print(f"The value for the field '{field_name}' does not use a Value Relation.")
    
# for layer in pointlayers:
#     if layer.name() == 'Site':
#         value_counts(layer, 'site_type')