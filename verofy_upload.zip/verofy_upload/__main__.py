# -*- coding: utf-8 -*-
"""
Created on Tues Jan 28, 2025
Vero QC
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
# import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsField, QgsVectorLayer, QgsCoordinateTransformContext, QgsCoordinateReferenceSystem, QgsCoordinateTransform, Qgis, QgsFeature,QgsProcessingFeatureSourceDefinition,QgsFeatureRequest
from PyQt5.QtCore import QVariant
from datetime import datetime
from qgis import processing
import inspect
print([name for name, _ in inspect.getmembers(QgsVectorFileWriter) if name.startswith('Err') or name == 'NoError' or name == 'Canceled'])

def __main__(taskName, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, checked_permits, area_id):
    
    print(f'Processing {taskName}...')
    print(area_id)
    print(checked_permits)
    project = QgsProject.instance()
    existing_layer = QgsProject.instance().mapLayer('memory.gpkg')
    if existing_layer:
        QgsProject.instance().removeMapLayer(existing_layer)
    progressBar.setValue(1)
    class CustomFieldValueConverter(QgsVectorFileWriter.FieldValueConverter):
        def __init__(self, layerz):
            QgsVectorFileWriter.FieldValueConverter.__init__(self)
            self.layer = layerz

        def fieldDefinition(self, field):
            idx = self.layer.fields().indexFromName(field.name())
            editorWidget = self.layer.editorWidgetSetup(idx)
            #print(field.name(), idx, editorWidget.type())
            if editorWidget.type() == 'ValueRelation':
                return QgsField(field.name(), QVariant.String)
            else:
                return self.layer.fields()[idx]

        def convert(self, idx, value):
            eWidget = self.layer.editorWidgetSetup(idx)
            # print(eWidget.type())
            if eWidget.type() == 'ValueRelation':
                config = eWidget.config()
                related_layer = QgsProject.instance().mapLayer(config['Layer'])
                key_field = config['Key']
                display_field = config['Value']
                value_relation_map = {feat[key_field]: feat[display_field] for feat in related_layer.getFeatures()}
                display_value = value_relation_map.get(value, value)
                return display_value
            else:
                #print(value)
                return value
    save_options = QgsVectorFileWriter.SaveVectorOptions()
    #save_options.driverName = 'ESRI Shapefile'
    save_options.driverName = "GPKG"
    save_options.fileEncoding = "UTF-8"
    save_options.onlySelectedFeatures = True
    context = QgsProject.instance().transformContext()
    #-------------------------------------------------------------------
    # Create main output folder
    # Determine folder name based on selection
    today_str = datetime.now().strftime("%Y%m%d_%H%M%S")

    folder_name = str(area_id)

    main_folder = os.path.join(outputfolder, f"{taskName}-{folder_name}-{today_str}")
    if not os.path.exists(main_folder):
        os.makedirs(main_folder)

    # define AOI boundary
    project_name = folder_name
    proj_folder = os.path.join(outputfolder, f"QC_{project_name}")
    if not os.path.exists(proj_folder):
        os.mkdir(proj_folder)

    permits_layer = project.mapLayersByName("Permits")[0]
    poles_layer = project.mapLayersByName("Pole")[0]

    cab_layer = project.mapLayersByName("Cabinet_Boundary")[0]


    def filter_and_rename_fields(src_layer, field_map):
        """
        src_layer: QgsVectorLayer
        field_map: dict of {original_field_name: new_field_name}
        Returns: QgsVectorLayer (memory) with only the selected fields, renamed
        """
        # Create new fields
        def wkbtype_to_geomstr(wkbtype):
            mapping = {
                1: "Point",
                4: "MultiPoint",
                2: "LineString",
                5: "MultiLineString",
                3: "Polygon",
                6: "MultiPolygon"
            }
            return mapping.get(wkbtype, "Unknown")
        new_fields = []
        orig_names = []
        for orig_name, new_name in field_map.items():
            idx = src_layer.fields().indexFromName(orig_name)
            if idx == -1:
                print(f"Warning: Field '{orig_name}' not found in {src_layer.name()}!")
                continue
            field_type = src_layer.fields()[idx].type()
            new_fields.append(QgsField(new_name, field_type))
            orig_names.append(orig_name)  # Keep the order

        geom_str = wkbtype_to_geomstr(src_layer.wkbType())
        mem_layer = QgsVectorLayer(f"{geom_str}?crs={src_layer.crs().authid()}", "filtered", "memory")
        mem_layer.dataProvider().addAttributes(new_fields)
        mem_layer.updateFields()
        # Copy features
        features_to_add = []
        for feat in src_layer.getSelectedFeatures():
            attrs = []
            for orig_name in orig_names:
                    attrs.append(feat[orig_name] if orig_name in feat.fields().names() else None)
            if len(attrs) != len(mem_layer.fields()):
                print(f"Attribute length mismatch for feature {feat.id()}: {len(attrs)} vs {len(mem_layer.fields())}")
            new_feat = QgsFeature()
            new_feat.setFields(mem_layer.fields())
            new_feat.setAttributes(attrs)
            geom = feat.geometry()
            if geom is None or not geom.isGeosValid():
                # print(f"Skipping feature {feat.id()} due to invalid geometry")
                continue
            new_feat.setGeometry(geom)
            features_to_add.append(new_feat)
        # print(f"Number of features to add: {len(features_to_add)}")
        mem_layer.dataProvider().addFeatures(features_to_add)
        # print(f"mem_layer feature count after add: {mem_layer.featureCount()}")
        mem_layer.updateExtents()
        # print(f"mem Filtered layer created with {mem_layer.featureCount()} features and {len(mem_layer.fields())} fields.")
        return mem_layer

    def qgs_writer_error_message(error_code):
        error_map = {
            QgsVectorFileWriter.NoError: "No error (success).",
            QgsVectorFileWriter.ErrDriverNotFound: "Driver not found.",
            QgsVectorFileWriter.ErrCreateDataSource: "Could not create data source.",
            QgsVectorFileWriter.ErrCreateLayer: "Could not create layer.",
            QgsVectorFileWriter.ErrAttributeTypeUnsupported: "Attribute type unsupported.",
            QgsVectorFileWriter.ErrAttributeCreationFailed: "Attribute creation failed.",
            QgsVectorFileWriter.ErrProjection: "Projection error.",
            QgsVectorFileWriter.ErrFeatureWriteFailed: "Feature write failed.",
            QgsVectorFileWriter.ErrInvalidLayer: "Invalid layer.",
            QgsVectorFileWriter.Canceled: "Operation canceled.",
            QgsVectorFileWriter.ErrSavingMetadata: "Error saving metadata."
        }
        return error_map.get(error_code, f"Unknown error code: {error_code}")

    def permitProcessing():
        functionProgressBar.setValue(1)
        if permits_layer.featureCount() == 0:
            dbox.append(errorFormat.format("Permits layer is empty!"))
            if hasattr(dbox, 'parent') and hasattr(dbox.parent(), 'button_box'):
                ok_button = dbox.parent().button_box.button(dbox.parent().button_box.Ok)
                ok_button.setEnabled(False)
            return

        if poles_layer.featureCount() == 0:
            dbox.append(errorFormat.format("Poles layer is empty!"))
            if hasattr(dbox, 'parent') and hasattr(dbox.parent(), 'button_box'):
                ok_button = dbox.parent().button_box.button(dbox.parent().button_box.Ok)
                ok_button.setEnabled(False)
            return
        permit_ids_expr = ", ".join([f"'{p}'" for p in checked_permits])
        print(f"Permit IDs: {permit_ids_expr}")
        today_str = datetime.now().strftime("%Y%m%d_%H%M%S")

        if len(checked_permits) > 1:
            permit_folder_name = f"multi_selected_{today_str}"
        elif len(checked_permits) == 1:
            # Remove any invalid path characters from permit name
            permit_folder_name = "".join(c for c in checked_permits[0] if c.isalnum() or c in (' ', '_', '-')).rstrip()
        else:
            permit_folder_name = "no_permit_selected"

        permit_folder = os.path.join(main_folder, permit_folder_name)
        if not os.path.exists(permit_folder):
            os.makedirs(permit_folder)

        permit_kml = os.path.join(permit_folder, f"permits_{permit_folder_name}.csv")
        poles_kml = os.path.join(permit_folder, f"poles_{permit_folder_name}.csv")
        
        expression = f'({permit_ids_expr})'
        print(f"Expression: {expression}")

        pole_field_map = {
            "":"",
            "pole_tag": "Pole Tag",
            "pole_group": "Group 1",
            "group_2": "Group 2",
            "pole_owner": "Owner",
            "mr_state": "MR State",
            "comms_mr": "Comms MR",
            "power_mr": "Power MR",
            "latitude": "Latitude",
            "longitude": "Longitude",
            "pole_height": "Pole Height",
            "attachment_height": "Att. Height",
            "mr_notes": "MR Note"
        }
        permit_field_map = {
            "internal_permit_id": "Name",
            "status": "Status",
            "group":"Group 1",
            "zone_hub":"Group 1",
            "group_2":"Group 2",
            "tags":"Tags",
            "footage":"Footages",
            "submit_a":"Submitted",
            "Submitted":"Submitted",
            "received_a":"Received",
            "url_type":"URL Type",
            "owner":"Owner",
            "permit_number":"Number",
            "entity_meet":"Entity Meet",
            "requirements":"Requirements"
        }

        print(f"area_id: {area_id}")

        cabinet_extration = processing.run(
            "qgis:extractbyexpression",
            {'INPUT': cab_layer, 'EXPRESSION': f'"area_id" = \'{area_id}\'', 'OUTPUT': 'memory:'}
        )['OUTPUT']

        print(f"Cabinet extraction feature count: {cabinet_extration.featureCount()}")
        if cabinet_extration.featureCount() == 0:
            dbox.append(errorFormat.format("No features found in Cabinet extraction!"))
            return
        permit_selection = processing.run(
            "qgis:selectbylocation",
            {'INPUT': permits_layer, 'PREDICATE': [0], 'INTERSECT': cabinet_extration, 'METHOD': 0, 'OUTPUT': 'memory:'}
        )['OUTPUT']
        print(f"Permit selection feature count: {permit_selection.selectedFeatureCount()}")
        if permit_selection.featureCount() == 0:
            dbox.append(errorFormat.format("No permits found in selected area!"))
            return

        permit_ids_expr = ", ".join([f"'{p}'" for p in checked_permits])
        print(f"Permit IDs expression: {permit_ids_expr}")
        expression = f'({permit_ids_expr})'
        permit_extration = processing.run(
            "qgis:extractbyexpression",
            {
                'INPUT': QgsProcessingFeatureSourceDefinition(permits_layer.source(), selectedFeaturesOnly=True, featureLimit=-1, flags=QgsProcessingFeatureSourceDefinition.FlagOverrideDefaultGeometryCheck, geometryCheck=QgsFeatureRequest.GeometrySkipInvalid),
                'EXPRESSION': f'"internal_permit_id" IN {expression}',
                'OUTPUT': 'memory:'
            }
        )['OUTPUT']
        permit_selection = processing.run(
            "qgis:selectbyexpression",
            {'INPUT': permit_extration, 'EXPRESSION': f'"internal_permit_id" IN {expression}', 'METHOD': 0, 'OUTPUT': 'memory:'}
        )['OUTPUT']

        print(f"Permit extraction feature count: {permit_extration.featureCount()}")
        print(f"Extracted {permit_extration.featureCount()} permits matching the selected IDs.")
        if permit_extration.featureCount() == 0:
            dbox.append(errorFormat.format("No permits match the selected permit IDs!"))
            return

        pole_selection = processing.run("qgis:selectbylocation", {'INPUT': poles_layer, 'PREDICATE': [0], 'INTERSECT': permit_extration, 'METHOD': 0, 'OUTPUT': 'memory:'})['OUTPUT']
        print(f"Pole selection feature count: {pole_selection.selectedFeatureCount()}")
        if pole_selection.featureCount() == 0:
            dbox.append(errorFormat.format("No poles found for selected permits!"))
            return
        
        pole_selection = processing.run("qgis:selectbyexpression", {'INPUT': poles_layer, 'EXPRESSION': '"attach" = \'Yes\'', 'METHOD': 3, 'OUTPUT': 'memory:'})['OUTPUT']
        print(f"Pole selection after attachment filter feature count: {pole_selection.selectedFeatureCount()}")
        if pole_selection.featureCount() == 0:
            dbox.append(errorFormat.format("No attached poles found!"))
            if hasattr(dbox, 'parent') and hasattr(dbox.parent(), 'button_box'):
                ok_button = dbox.parent().button_box.button(dbox.parent().button_box.Ok)
                ok_button.setEnabled(False)
            return

        print(f"selection Processing {permit_selection.selectedFeatureCount()} permits")
        print(f"selection Processing {pole_selection.selectedFeatureCount()} poles")
        functionProgressBar.setValue(33)
        filtered_permit_layer = filter_and_rename_fields(permit_selection, permit_field_map)
        filtered_pole_layer = filter_and_rename_fields(pole_selection, pole_field_map)
        print(f"Filter Processing {filtered_permit_layer.featureCount()} permits")
        print(f"Filter Processing {filtered_pole_layer.featureCount()} poles")
        functionProgressBar.setValue(66)
        driver_name = "CSV"
        # permit_temp_layer = QgsVectorLayer("Polygon?crs=EPSG:3857", "permit", "memory")
        permit_options = QgsVectorFileWriter.SaveVectorOptions()
        permit_options.driverName = driver_name
        permit_options.ct = QgsCoordinateTransform(filtered_permit_layer.crs(), QgsCoordinateReferenceSystem("EPSG:3857"), QgsCoordinateTransformContext()) # Example: reproject to WGS 84
        permit_options.overrideGeometryType = Qgis.WkbType.MultiPolygon # Example: force MultiPolygon geometry type
        permit_options.includeZ = False # Example: include Z dimension if overrideGeometryType is set
        permit_options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile # Example: Overwrite if file exists
        permit_options.onlySelectedFeatures = False # Example: Save only selected features

        poles_options = QgsVectorFileWriter.SaveVectorOptions()
        poles_options.driverName = driver_name
        poles_options.ct = QgsCoordinateTransform(filtered_pole_layer.crs(), QgsCoordinateReferenceSystem("EPSG:3857"), QgsCoordinateTransformContext()) # Example: reproject to WGS 84
        poles_options.overrideGeometryType = Qgis.WkbType.Point # Example: force point geometry type
        poles_options.includeZ = False # Example: include Z dimension if overrideGeometryType is set
        poles_options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile # Example: Overwrite if file exists
        poles_options.onlySelectedFeatures = False # Example: Save only selected features
        functionProgressBar.setValue(99)
        poles_temp_layer_result = QgsVectorFileWriter.writeAsVectorFormatV3(filtered_pole_layer, poles_kml, QgsCoordinateTransformContext(), poles_options)

        if isinstance(poles_temp_layer_result, tuple):
                    poles_error_code, poles_error_message, _, _ = poles_temp_layer_result
        else:
            poles_error_code = poles_temp_layer_result
            poles_error_message = ""
        if poles_error_code == QgsVectorFileWriter.NoError:
            print("Layer saved successfully!")
        else:
            print(f"Error saving poles layer: {qgs_writer_error_message(poles_error_code)}")
            if poles_error_message:
                print(f"Writer error message: {poles_error_message}")
            print(f"Error saving layer: {poles_error_code}")

        permit_result = QgsVectorFileWriter.writeAsVectorFormatV3(filtered_permit_layer, permit_kml, QgsCoordinateTransformContext(), permit_options)
        if isinstance(permit_result, tuple):
            permit_error_code, permit_error_message, _, _ = permit_result
        else:
            permit_error_code = permit_result
            permit_error_message = ""
        if permit_error_code == QgsVectorFileWriter.NoError:
            print("Layer saved successfully!")
        else:
            print(f"Error saving permit layer: {qgs_writer_error_message(permit_error_code)}")
            if permit_error_message:
                print(f"Writer error message: {permit_error_message}")
            print(f"Error saving layer: {permit_error_code}")
        functionProgressBar.setValue(100)
        functionProgressBar.setValue(100)
        
    def everythingElse():
        print(f"Processing {taskName} for area {area_id}...")
        

    permitProcessing()
    print(f"Finished processing {taskName} for area {area_id}.")
    progressBar.setValue(100)